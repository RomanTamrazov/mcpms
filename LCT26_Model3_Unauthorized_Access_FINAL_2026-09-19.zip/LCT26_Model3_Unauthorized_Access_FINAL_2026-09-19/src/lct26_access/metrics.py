"""Metrics aligned with dispatcher workload and temporal validation."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    f1_score,
    log_loss,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)


def site_metrics(
    target: Sequence[int],
    probability: Sequence[float],
    target_dates: Sequence[object],
    *,
    threshold: float = 0.5,
) -> dict[str, float | int]:
    """Binary quality plus top-k alert-budget metrics per forecast date."""

    y = np.asarray(target, dtype=np.int8)
    p = np.clip(np.asarray(probability, dtype=float), 1e-8, 1 - 1e-8)
    predicted = p >= threshold
    result: dict[str, float | int] = {
        "rows": int(y.size),
        "prevalence": float(y.mean()),
        "roc_auc": float(roc_auc_score(y, p)),
        "pr_auc": float(average_precision_score(y, p)),
        "logloss": float(log_loss(y, p)),
        "brier": float(brier_score_loss(y, p)),
        "threshold": float(threshold),
        "f1": float(f1_score(y, predicted)),
        "precision": float(precision_score(y, predicted, zero_division=0)),
        "recall": float(recall_score(y, predicted, zero_division=0)),
    }
    ranked = pd.DataFrame({"date": target_dates, "target": y, "score": p}).sort_values(
        ["date", "score"], ascending=[True, False]
    )
    for budget in (3, 5, 10):
        top = ranked.groupby("date", sort=False).head(budget)
        result[f"precision_at_{budget}"] = float(top["target"].mean())
        result[f"recall_at_{budget}"] = float(top["target"].sum() / y.sum())
    return result


def zone_rank_metrics(
    frame: pd.DataFrame,
    score: Sequence[float],
) -> dict[str, float | int]:
    """Conditional localisation metrics within positive site/day groups."""

    ranked = frame[["target_date", "site_raw", "target"]].copy()
    ranked["score"] = np.asarray(score, dtype=float)
    ranked = ranked.sort_values(
        ["target_date", "site_raw", "score"], ascending=[True, True, False]
    )
    keys = ["target_date", "site_raw"]
    ranked["rank"] = ranked.groupby(keys, sort=False).cumcount() + 1
    positives = ranked[ranked["target"] == 1]
    first_ranks = positives.groupby(keys, sort=False)["rank"].min()
    result: dict[str, float | int] = {
        "rows": int(ranked.shape[0]),
        "groups": int(first_ranks.shape[0]),
        "positive_zones": int(positives.shape[0]),
        "roc_auc": float(roc_auc_score(ranked["target"], ranked["score"])),
        "pr_auc": float(average_precision_score(ranked["target"], ranked["score"])),
        "mrr": float((1.0 / first_ranks).mean()),
        "mean_first_positive_rank": float(first_ranks.mean()),
    }
    for budget in (1, 3, 5, 10):
        top = ranked[ranked["rank"] <= budget]
        result[f"precision_at_{budget}"] = float(top["target"].mean())
        result[f"recall_at_{budget}"] = float(
            top["target"].sum() / max(1, positives.shape[0])
        )
        result[f"hit_rate_at_{budget}"] = float(
            top.groupby(keys, sort=False)["target"].max().mean()
        )
    return result


def best_f1_threshold(target: Sequence[int], probability: Sequence[float]) -> float:
    """Deterministic threshold grid used only on past validation predictions."""

    y = np.asarray(target, dtype=np.int8)
    p = np.asarray(probability, dtype=float)
    grid = np.unique(np.quantile(p, np.linspace(0.02, 0.98, 500)))
    return float(max(grid, key=lambda threshold: f1_score(y, p >= threshold)))


def robust_f1_threshold(
    target: Sequence[int],
    probability: Sequence[float],
    groups: Sequence[object],
) -> tuple[float, dict[str, object]]:
    """Select a threshold that maximises the weakest development-window F1.

    The threshold grid is derived only from the supplied development scores.
    Ties prefer the better mean and pooled F1, then the higher threshold to
    avoid creating extra dispatcher work without a measured quality benefit.
    """

    y = np.asarray(target, dtype=np.int8)
    p = np.asarray(probability, dtype=float)
    group_values = np.asarray(groups)
    if not (y.size == p.size == group_values.size):
        raise ValueError("target, probability, and groups must have equal length")
    unique_groups = pd.unique(group_values)
    if unique_groups.size < 2:
        raise ValueError("robust threshold selection requires at least two groups")

    grid = np.unique(np.quantile(p, np.linspace(0.02, 0.98, 500)))
    best_key: tuple[float, float, float, float] | None = None
    best_threshold: float | None = None
    best_scores: dict[str, float] | None = None
    for threshold in grid:
        scores = {
            str(group): float(
                f1_score(
                    y[group_values == group],
                    p[group_values == group] >= threshold,
                )
            )
            for group in unique_groups
        }
        key = (
            min(scores.values()),
            float(np.mean(list(scores.values()))),
            float(f1_score(y, p >= threshold)),
            float(threshold),
        )
        if best_key is None or key > best_key:
            best_key = key
            best_threshold = float(threshold)
            best_scores = scores

    if best_threshold is None or best_scores is None:
        raise RuntimeError("No threshold candidate was evaluated")
    return best_threshold, {
        "strategy": "maximise minimum F1 across development windows",
        "grid_quantiles": 500,
        "fold_scores": best_scores,
        "minimum_f1": float(min(best_scores.values())),
        "mean_f1": float(np.mean(list(best_scores.values()))),
        "pooled_f1": float(f1_score(y, p >= best_threshold)),
        "tie_break": "mean F1, pooled F1, then higher threshold",
    }


def threshold_for_min_group_recall(
    target: Sequence[int],
    probability: Sequence[float],
    groups: Sequence[object],
    minimum_recall: float,
) -> tuple[float, dict[str, object]]:
    """Maximise robust precision while meeting recall in every development window."""

    y = np.asarray(target, dtype=np.int8)
    p = np.asarray(probability, dtype=float)
    group_values = np.asarray(groups)
    if not (y.size == p.size == group_values.size):
        raise ValueError("target, probability, and groups must have equal length")
    if not 0 <= minimum_recall <= 1:
        raise ValueError("minimum_recall must be inside [0, 1]")
    unique_groups = pd.unique(group_values)
    if unique_groups.size < 2:
        raise ValueError("group-constrained selection requires at least two groups")

    grid = np.unique(np.quantile(p, np.linspace(0.02, 0.98, 500)))
    best_key: tuple[float, float, float, float] | None = None
    best_threshold: float | None = None
    best_scores: dict[str, dict[str, float]] | None = None
    for threshold in grid:
        scores: dict[str, dict[str, float]] = {}
        for group in unique_groups:
            mask = group_values == group
            predicted = p[mask] >= threshold
            scores[str(group)] = {
                "precision": float(precision_score(y[mask], predicted, zero_division=0)),
                "recall": float(recall_score(y[mask], predicted, zero_division=0)),
                "f1": float(f1_score(y[mask], predicted, zero_division=0)),
            }
        if min(score["recall"] for score in scores.values()) < minimum_recall:
            continue
        key = (
            min(score["precision"] for score in scores.values()),
            float(np.mean([score["precision"] for score in scores.values()])),
            min(score["f1"] for score in scores.values()),
            float(threshold),
        )
        if best_key is None or key > best_key:
            best_key = key
            best_threshold = float(threshold)
            best_scores = scores

    if best_threshold is None or best_scores is None:
        raise ValueError(
            f"No threshold satisfies recall >= {minimum_recall} in every group"
        )
    return best_threshold, {
        "strategy": "maximise minimum precision subject to per-window recall floor",
        "minimum_recall_per_window": float(minimum_recall),
        "grid_quantiles": 500,
        "fold_scores": best_scores,
        "minimum_precision": float(
            min(score["precision"] for score in best_scores.values())
        ),
        "minimum_recall": float(min(score["recall"] for score in best_scores.values())),
        "tie_break": "mean precision, minimum F1, then higher threshold",
    }


def threshold_for_min_precision(
    target: Sequence[int], probability: Sequence[float], minimum: float
) -> float:
    """Highest-recall threshold satisfying a requested validation precision."""

    y = np.asarray(target, dtype=np.int8)
    p = np.asarray(probability, dtype=float)
    precision, recall, thresholds = precision_recall_curve(y, p)
    candidates = np.flatnonzero(precision[:-1] >= minimum)
    if candidates.size == 0:
        return float(np.nextafter(p.max(), np.inf))
    best = max(candidates, key=lambda index: (recall[index], precision[index]))
    return float(thresholds[best])


def threshold_for_min_recall(
    target: Sequence[int], probability: Sequence[float], minimum: float
) -> float:
    """Highest-precision threshold satisfying a requested validation recall."""

    y = np.asarray(target, dtype=np.int8)
    p = np.asarray(probability, dtype=float)
    precision, recall, thresholds = precision_recall_curve(y, p)
    candidates = np.flatnonzero(recall[:-1] >= minimum)
    if candidates.size == 0:
        return float(np.nextafter(p.min(), -np.inf))
    best = max(candidates, key=lambda index: (precision[index], recall[index]))
    return float(thresholds[best])
