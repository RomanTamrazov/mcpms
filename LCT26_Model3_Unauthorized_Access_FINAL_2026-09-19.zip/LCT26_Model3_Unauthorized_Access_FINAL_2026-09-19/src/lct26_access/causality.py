"""Static causality checks for Model 3 feature manifests.

The production forecast is made after calendar day ``D`` has closed and predicts
the proxy target on ``D + 1``.  A feature is therefore causal when its raw input
is available no later than the end of ``D`` or when it is deterministic calendar
information known in advance.

This module is deliberately conservative.  Features backed by the single
current catalog snapshot are marked ``review`` rather than silently called
leakage-free: the files contain no historical catalog versions with which to
prove that the attribute was known at every old forecast timestamp.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import asdict, dataclass

KNOWN_TARGET_CALENDAR = {
    "target_dow",
    "target_month",
    "target_doy",
    "target_weekday",
    "target_weekend",
    "target_doy_sin",
    "target_doy_cos",
    "target_dow_sin",
    "target_dow_cos",
    "target_holiday",
    "target_preholiday",
    "target_postholiday",
    "target_workday",
}

FORBIDDEN_EXACT = {
    "target",
    "target_date",
    "target_next_events",
    "target_next_zones",
    "target_next_zone_events",
    "site_target",
    "next_date_check",
}

FORBIDDEN_PATTERN = re.compile(
    r"(?:^|_)(?:lead|future|label|next_target|t_plus|d_plus_1)(?:_|\d|$)",
    flags=re.IGNORECASE,
)
LAG_PATTERN = re.compile(r"_lag(\d+)$")
WINDOW_PATTERN = re.compile(r"_(sum|mean)(\d+)$")
RATE_WINDOW_PATTERN = re.compile(r"(?:rate|share|trend|events|logevents)_?(\d+)(?:d|w)?$")


@dataclass(frozen=True)
class FeatureCausality:
    """Machine-readable lineage assessment for one model feature."""

    feature: str
    source_table: str
    granularity: str
    aggregation_window: str
    shift: str
    prediction_timestamp: str
    max_allowed_timestamp: str
    actual_max_source_timestamp: str
    availability_at_prediction: str
    causal_status: str
    reason: str

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


def _result(
    feature: str,
    *,
    source: str,
    granularity: str,
    window: str,
    shift: str,
    actual: str,
    availability: str,
    status: str,
    reason: str,
) -> FeatureCausality:
    return FeatureCausality(
        feature=feature,
        source_table=source,
        granularity=granularity,
        aggregation_window=window,
        shift=shift,
        prediction_timestamp="end of calendar day D, after daily ingestion completes",
        max_allowed_timestamp="<= end of calendar day D",
        actual_max_source_timestamp=actual,
        availability_at_prediction=availability,
        causal_status=status,
        reason=reason,
    )


def classify_feature_causality(feature: str, *, model_level: str) -> FeatureCausality:
    """Classify one site or zone feature using the audited naming contract."""

    if model_level not in {"site", "zone"}:
        raise ValueError("model_level must be 'site' or 'zone'")

    lowered = feature.lower()
    if (
        feature in FORBIDDEN_EXACT
        or (lowered.startswith("target_") and feature not in KNOWN_TARGET_CALENDAR)
        or FORBIDDEN_PATTERN.search(feature)
    ):
        return _result(
            feature,
            source="label/future namespace",
            granularity="unknown",
            window="not applicable",
            shift="future or target-derived",
            actual="> end of D or identical to label",
            availability="not available",
            status="fail",
            reason="Feature name belongs to a forbidden label/future namespace.",
        )

    if feature in KNOWN_TARGET_CALENDAR:
        return _result(
            feature,
            source="deterministic calendar",
            granularity="site-day" if model_level == "site" else "site-zone-day",
            window="target calendar day D+1",
            shift="known in advance",
            actual="calendar only; no future observation",
            availability="available before D closes",
            status="pass",
            reason="Calendar attributes of D+1 are deterministic and known at forecast time.",
        )

    catalog_prefixes = (
        "site_static_",
        "static_",
        "zone_primary_",
        "site_parent_id",
    )
    if feature.startswith(catalog_prefixes):
        return _result(
            feature,
            source="current channel/object catalog snapshot",
            granularity="site" if model_level == "site" else "zone",
            window="snapshot",
            shift="none",
            actual="catalog snapshot timestamp is not versioned in source data",
            availability="available now; historical availability is unproven",
            status="review",
            reason=(
                "No versioned catalog history exists. Safe for current inference, but applying the "
                "latest static state to old folds requires a stability assumption."
            ),
        )

    if feature in {"site_raw", "site_family", "zone_key"}:
        return _result(
            feature,
            source="engineering tag carried by events/catalog",
            granularity="identifier",
            window="current entity identity",
            shift="none",
            actual="known entity key at or before D",
            availability="available by end of D",
            status="pass",
            reason="Entity identity is required for grouping and exists on historical events.",
        )

    lag_match = LAG_PATTERN.search(feature)
    if lag_match:
        days = int(lag_match.group(1))
        return _result(
            feature,
            source="daily feature history",
            granularity="site-day" if model_level == "site" else "site-zone-day",
            window="single historical day",
            shift=f"lag {days} day(s)",
            actual=f"end of D-{days}",
            availability="available by end of D",
            status="pass",
            reason="Explicit positive lag cannot read D+1.",
        )

    window_match = WINDOW_PATTERN.search(feature)
    if window_match:
        days = int(window_match.group(2))
        return _result(
            feature,
            source="daily feature history",
            granularity="site-day" if model_level == "site" else "site-zone-day",
            window=f"trailing {days} rows/days through D",
            shift="window includes D; excludes D+1",
            actual="end of D",
            availability="available after daily ingestion for D",
            status="pass",
            reason="Trailing aggregation is causal under the declared end-of-day cutoff.",
        )

    if feature.startswith(("same_target_weekday_", "same_weekday_rate_trend_")):
        match = RATE_WINDOW_PATTERN.search(feature)
        period = match.group(1) if match else "multiple"
        return _result(
            feature,
            source="daily site history",
            granularity="site-day",
            window=f"same-weekday history, up to {period} weeks",
            shift="nearest observation is D-6",
            actual="end of D-6 or earlier",
            availability="available before end of D",
            status="pass",
            reason="Same target-weekday values are built only from prior calendar weeks.",
        )

    if feature.startswith("ctx_"):
        return _result(
            feature,
            source="daily_family_context",
            granularity="site-family-day",
            window="current D or causal trailing window",
            shift="none or explicit positive lag",
            actual="end of D",
            availability="available after all engineering journals for D are ingested",
            status="pass",
            reason="Context joins on date D and never on target_date D+1.",
        )

    if feature.startswith(("history_", "past_", "days_since_")):
        return _result(
            feature,
            source="expanding daily history",
            granularity="site-day" if model_level == "site" else "site-zone-day",
            window="expanding history through D",
            shift="excludes D+1",
            actual="end of D",
            availability="available after daily ingestion for D",
            status="pass",
            reason="Expanding statistic is calculated only from rows dated no later than D.",
        )

    # All remaining manifest features are raw day-D aggregates or deterministic
    # transformations of them.  Unknown external fields should not reach a
    # frozen manifest without first being added to this classifier.
    return _result(
        feature,
        source="daily_site_features" if model_level == "site" else "daily_zone_features",
        granularity="site-day" if model_level == "site" else "site-zone-day",
        window="day D or causal transformation through D",
        shift="none",
        actual="end of D",
        availability="available after daily ingestion for D",
        status="pass",
        reason="Frozen manifest field is a day-D aggregate; D+1 label columns are excluded.",
    )


def audit_feature_manifest(features: Iterable[str], *, model_level: str) -> list[FeatureCausality]:
    """Return unique, sorted lineage rows for a feature manifest."""

    return [
        classify_feature_causality(feature, model_level=model_level)
        for feature in sorted(set(features))
    ]


def assert_no_failed_features(features: Iterable[str], *, model_level: str) -> None:
    """Raise when a manifest contains a target or future-looking feature."""

    failed = [
        item.feature
        for item in audit_feature_manifest(features, model_level=model_level)
        if item.causal_status == "fail"
    ]
    if failed:
        raise ValueError(f"Non-causal or label-derived features detected: {failed}")
