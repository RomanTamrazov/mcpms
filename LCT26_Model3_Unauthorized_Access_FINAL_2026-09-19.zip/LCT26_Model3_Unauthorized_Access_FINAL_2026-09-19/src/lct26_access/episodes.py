"""Explainable grouping of raw alarm rows into dispatcher-facing episodes."""

from __future__ import annotations

import polars as pl

from .constants import INTRUSION_VALUES, SECURITY_SYSTEM


def build_intrusion_episodes(events: pl.DataFrame, gap_minutes: int = 30) -> pl.DataFrame:
    """Cluster physical security alarms by site and time gap.

    The resulting ``evidence_score`` is intentionally not called a probability:
    without dispatcher-confirmed true/false outcomes it is an explainable evidence
    index only. A supervised verifier can replace it when feedback labels arrive.
    """

    alarms = (
        events.filter(
            (pl.col("тип_инж_системы") == SECURITY_SYSTEM)
            & (pl.col("alarm") == 1)
            & pl.col("значение_датчика").is_in(INTRUSION_VALUES)
        )
        .with_columns(
            [
                pl.col("тег_инженерной_системы")
                .str.strip_suffix(".")
                .str.replace(r"\.[^.]+$", "")
                .alias("zone_key"),
                pl.col("ts").dt.hour().alias("hour"),
                pl.col("ts").dt.weekday().alias("weekday"),
            ]
        )
        .sort(["site_raw", "ts"])
    )
    if alarms.is_empty():
        return pl.DataFrame()
    alarms = alarms.with_columns(
        (
            pl.col("ts").diff().over("site_raw").dt.total_minutes().fill_null(gap_minutes + 1)
            > gap_minutes
        )
        .cast(pl.Int64)
        .cum_sum()
        .over("site_raw")
        .alias("episode_local_id")
    )
    episodes = alarms.group_by(["site_raw", "episode_local_id"]).agg(
        [
            pl.col("ts").min().alias("started_at"),
            pl.col("ts").max().alias("ended_at"),
            pl.len().alias("event_count"),
            pl.col("zone_key").n_unique().alias("zone_count"),
            pl.col("ид_канала_данных").n_unique().alias("channel_count"),
            pl.col("тип_датчика").n_unique().alias("sensor_type_count"),
            (pl.col("тип_датчика") == "Датчик движения").any().alias("has_motion"),
            pl.col("тип_датчика")
            .is_in(["КД АВ", "КД Дверь", "КД Люк", "Стекло", "9-секционный люк"])
            .any()
            .alias("has_contact"),
            (
                (pl.col("hour") < 8) | (pl.col("hour") >= 19) | (pl.col("weekday") >= 6)
            )
            .any()
            .alias("offhours"),
        ]
    )
    # Monotonic, bounded evidence index; it is not fitted to fabricated labels.
    return (
        episodes.with_columns(
            (
                15
                + pl.col("event_count").clip(0, 10) * 3
                + pl.col("zone_count").clip(0, 5) * 5
                + pl.col("sensor_type_count").clip(0, 4) * 7
                + pl.col("has_motion").cast(pl.Int8) * 10
                + pl.col("has_contact").cast(pl.Int8) * 10
                + (pl.col("has_motion") & pl.col("has_contact")).cast(pl.Int8) * 15
                + pl.col("offhours").cast(pl.Int8) * 8
            )
            .clip(0, 100)
            .alias("evidence_score")
        )
        .with_columns(
            pl.when(pl.col("evidence_score") >= 75)
            .then(pl.lit("high"))
            .when(pl.col("evidence_score") >= 50)
            .then(pl.lit("medium"))
            .otherwise(pl.lit("low"))
            .alias("evidence_level")
        )
        .sort("started_at")
    )

