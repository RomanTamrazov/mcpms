"""Deterministic response policy layered after the predictive model.

The model forecasts a next-day SCADA proxy event.  It never confirms a real
intrusion.  Escalation above preventive priority P4 requires evidence that is
independent of the forecast probability.
"""

from __future__ import annotations

from dataclasses import dataclass

FEEDBACK_OUTCOMES = frozenset(
    {
        "confirmed_intrusion",
        "authorized_activity",
        "sensor_fault",
        "false_alarm",
        "unknown",
    }
)


@dataclass(frozen=True)
class IncidentEvidence:
    """Independent evidence available to the response workflow."""

    forecast_risk: bool = False
    security_alarm: bool = False
    cctv_intrusion: bool = False
    access_mismatch: bool = False
    neighbouring_sensor_alarm: bool = False
    human_confirmed_intrusion: bool = False
    authorized_activity_confirmed: bool = False
    sensor_fault_confirmed: bool = False
    safety_threat: bool = False


def classify_response(evidence: IncidentEvidence) -> dict[str, object]:
    """Map evidence to an auditable state and priority.

    This function is deliberately rule-based.  A learned policy is unsafe until
    confirmed incident outcomes and operational cost labels exist.
    """

    if evidence.human_confirmed_intrusion or evidence.safety_threat:
        return {
            "state": "CONFIRMED_INTRUSION",
            "priority": "P1",
            "independent_signal_count": _independent_signal_count(evidence),
            "action": (
                "Execute the approved emergency playbook; preserve operator safety "
                "and the incident audit trail."
            ),
            "suggested_outcome": None,
        }
    if evidence.authorized_activity_confirmed:
        return {
            "state": "CLOSED",
            "priority": "P4",
            "independent_signal_count": _independent_signal_count(evidence),
            "action": "Record the authorization source and close the case.",
            "suggested_outcome": "authorized_activity",
        }
    if evidence.sensor_fault_confirmed:
        return {
            "state": "CLOSED",
            "priority": "P3",
            "independent_signal_count": _independent_signal_count(evidence),
            "action": "Create a maintenance task and close the security case.",
            "suggested_outcome": "sensor_fault",
        }

    signal_count = _independent_signal_count(evidence)
    if signal_count >= 2:
        return {
            "state": "PROBABLE_INTRUSION",
            "priority": "P2",
            "independent_signal_count": signal_count,
            "action": (
                "Notify the responsible operator and verify through the approved "
                "access/video/field channel."
            ),
            "suggested_outcome": None,
        }
    if signal_count == 1:
        return {
            "state": "SUSPECTED_INTRUSION",
            "priority": "P3",
            "independent_signal_count": signal_count,
            "action": "Request an independent verification signal before escalation.",
            "suggested_outcome": None,
        }
    if evidence.forecast_risk:
        return {
            "state": "FORECAST_RISK",
            "priority": "P4",
            "independent_signal_count": 0,
            "action": (
                "Create a preventive review task; do not dispatch or confirm an incident."
            ),
            "suggested_outcome": None,
        }
    return {
        "state": "NO_ACTIVE_CASE",
        "priority": "NONE",
        "independent_signal_count": 0,
        "action": "Continue background monitoring.",
        "suggested_outcome": None,
    }


def validate_feedback_outcome(outcome: str) -> str:
    """Validate the closed-loop label vocabulary used for future retraining."""

    normalized = outcome.strip().lower()
    if normalized not in FEEDBACK_OUTCOMES:
        raise ValueError(
            f"Unknown incident outcome {outcome!r}; expected one of "
            f"{sorted(FEEDBACK_OUTCOMES)}"
        )
    return normalized


def _independent_signal_count(evidence: IncidentEvidence) -> int:
    return sum(
        (
            evidence.security_alarm,
            evidence.cctv_intrusion,
            evidence.access_mismatch,
            evidence.neighbouring_sensor_alarm,
        )
    )
