from __future__ import annotations

from datetime import UTC, date, datetime
from pathlib import Path

import pandas as pd
import polars as pl
import pytest

from lct26_access.constants import INTRUSION_VALUES, TECHNICAL_ALARM_VALUES
from lct26_access.data import alarm_flag_expression, read_channel_catalog
from lct26_access.episodes import build_intrusion_episodes
from lct26_access.features import _daily_intrusion_episode_features
from lct26_access.inference import _risk_band, _validate_site_runtime_weights
from lct26_access.metrics import (
    robust_f1_threshold,
    threshold_for_min_group_recall,
    threshold_for_min_precision,
    threshold_for_min_recall,
)
from lct26_access.models import SITE_EXCLUDE, feature_columns


def test_physical_and_technical_alarm_vocabularies_do_not_overlap() -> None:
    assert INTRUSION_VALUES
    assert TECHNICAL_ALARM_VALUES
    assert INTRUSION_VALUES.isdisjoint(TECHNICAL_ALARM_VALUES)


def test_alarm_parser_supports_historical_and_example_encodings() -> None:
    frame = pl.DataFrame(
        {"тревожное": ["t", "f", "true", "false", "TRUE", "1", "0", None]}
    ).select(alarm_flag_expression().alias("alarm"))
    assert frame["alarm"].to_list() == [1, 0, 1, 0, 1, 1, 0, 0]


def test_updated_channel_catalog_joins_dispatcher_objects(tmp_path: Path) -> None:
    pl.DataFrame(
        {
            "ид_канала_данных": [11, 12],
            "тип_инж_системы": ["Охранная подсистема"] * 2,
            "тип_датчика": ["Датчик движения", "КД Дверь"],
            "тег_инженерной_системы": ["10-1.1.7.1.", "10-1.1.7.2."],
            "название_датчика": ["Движение", "Дверь"],
            "ид_объект": [501, 502],
        }
    ).write_csv(tmp_path / "справочник_каналов_датчиков.csv")
    pl.DataFrame(
        {
            "ид_объект": [501, 502],
            "иерархия_уровень": [3, 3],
            "родитель": [5, 5],
            "вид_объекта": ["guardObject", "controlHouse"],
            "диспетчерское_название_объекта": ["Пост Альфа", "ДУ Альфа"],
        }
    ).write_csv(tmp_path / "справочник_объектов_диспетчер.csv")

    catalog = read_channel_catalog(tmp_path).sort("ид_канала_данных")

    assert catalog["dispatcher_object_name"].to_list() == ["Пост Альфа", "ДУ Альфа"]
    assert catalog["object_level"].to_list() == [3, 3]
    assert catalog["zone_key"].to_list() == ["10-1.1.7", "10-1.1.7"]


def test_unknown_object_id_is_rejected(tmp_path: Path) -> None:
    pl.DataFrame(
        {
            "ид_канала_данных": [11],
            "тип_инж_системы": ["Охранная подсистема"],
            "тип_датчика": ["Датчик движения"],
            "тег_инженерной_системы": ["10-1.1.7.1."],
            "название_датчика": ["Движение"],
            "ид_объект": [999],
        }
    ).write_csv(tmp_path / "справочник_каналов_датчиков.csv")
    pl.DataFrame(
        {
            "ид_объект": [501],
            "иерархия_уровень": [3],
            "родитель": [5],
            "вид_объекта": ["guardObject"],
            "диспетчерское_название_объекта": ["Пост Альфа"],
        }
    ).write_csv(tmp_path / "справочник_объектов_диспетчер.csv")

    with pytest.raises(ValueError, match="absent from object catalog"):
        read_channel_catalog(tmp_path)


def test_future_label_columns_are_not_features() -> None:
    frame = pd.DataFrame(
        {
            "site_raw": ["a", "b"],
            "date": pd.to_datetime(["2025-01-01", "2025-01-01"]),
            "target_date": pd.to_datetime(["2025-01-02", "2025-01-02"]),
            "safe_history": [1.0, 2.0],
            "target": [0, 1],
            "target_next_events": [0, 4],
            "target_next_zones": [0, 2],
        }
    )
    assert feature_columns(frame, exclude=SITE_EXCLUDE) == ["site_raw", "safe_history"]


def test_episode_clustering_respects_site_and_time_gap() -> None:
    events = pl.DataFrame(
        {
            "тип_инж_системы": ["Охранная подсистема"] * 4,
            "alarm": [1, 1, 1, 0],
            "значение_датчика": [
                "Не замкнут",
                "Обнаружено движение",
                "Не замкнут",
                "Не замкнут",
            ],
            "тег_инженерной_системы": [
                "10-1.1.7.1.",
                "10-1.1.7.2.",
                "10-1.1.8.1.",
                "10-1.1.8.2.",
            ],
            "ts": [
                datetime(2025, 1, 1, 22, 0, tzinfo=UTC),
                datetime(2025, 1, 1, 22, 10, tzinfo=UTC),
                datetime(2025, 1, 1, 23, 0, tzinfo=UTC),
                datetime(2025, 1, 1, 23, 2, tzinfo=UTC),
            ],
            "site_raw": ["10-1"] * 4,
            "ид_канала_данных": [1, 2, 3, 4],
            "тип_датчика": ["КД Дверь", "Датчик движения", "КД Дверь", "КД Дверь"],
        }
    )
    episodes = build_intrusion_episodes(events, gap_minutes=30)
    assert episodes.height == 2
    first = episodes.sort("started_at").row(0, named=True)
    assert first["event_count"] == 2
    assert first["has_motion"] is True
    assert first["has_contact"] is True
    assert first["evidence_score"] > 50


def test_operating_thresholds_respect_constraints() -> None:
    target = [0, 0, 1, 1]
    probability = [0.1, 0.4, 0.6, 0.9]
    assert threshold_for_min_precision(target, probability, 1.0) == 0.6
    assert threshold_for_min_recall(target, probability, 1.0) == 0.6


def test_robust_threshold_optimises_the_weaker_time_window() -> None:
    target = [0, 0, 1, 1, 0, 0, 1, 1]
    probability = [0.1, 0.2, 0.8, 0.9, 0.1, 0.6, 0.7, 0.8]
    groups = ["2024"] * 4 + ["2025"] * 4
    threshold, details = robust_f1_threshold(target, probability, groups)
    assert 0.6 < threshold <= 0.7
    assert details["minimum_f1"] == 1.0
    assert details["fold_scores"] == {"2024": 1.0, "2025": 1.0}


def test_group_recall_floor_is_satisfied_in_every_time_window() -> None:
    target = [0, 0, 1, 1, 0, 0, 1, 1]
    probability = [0.1, 0.3, 0.7, 0.9, 0.1, 0.6, 0.65, 0.8]
    groups = ["2024"] * 4 + ["2025"] * 4
    threshold, details = threshold_for_min_group_recall(
        target, probability, groups, 1.0
    )
    assert 0.6 < threshold <= 0.65
    assert details["minimum_recall"] == 1.0
    assert all(
        score["recall"] == 1.0 for score in details["fold_scores"].values()
    )


def test_daily_episode_features_never_cross_forecast_boundary() -> None:
    events = pl.DataFrame(
        {
            "site_raw": ["10-1"] * 4,
            "site_family": ["10"] * 4,
            "date": [
                date(2025, 1, 1),
                date(2025, 1, 1),
                date(2025, 1, 2),
                date(2025, 1, 2),
            ],
            "ts": [
                datetime(2025, 1, 1, 23, 55, tzinfo=UTC),
                datetime(2025, 1, 1, 23, 58, tzinfo=UTC),
                datetime(2025, 1, 2, 0, 5, tzinfo=UTC),
                datetime(2025, 1, 2, 0, 8, tzinfo=UTC),
            ],
            "intrusion": [1, 1, 1, 1],
            "zone_key": ["10-1.1.1"] * 4,
            "ид_канала_данных": [1, 2, 1, 2],
            "тип_датчика": [
                "КД Дверь",
                "Датчик движения",
                "КД Дверь",
                "Датчик движения",
            ],
        }
    )
    daily = _daily_intrusion_episode_features(events).sort("date")
    assert daily.height == 2
    assert daily["intrusion_episode_count"].to_list() == [1, 1]
    assert daily["intrusion_episode_max_events"].to_list() == [2, 2]
    assert daily["intrusion_motion_contact_episodes"].to_list() == [1, 1]


def test_forecast_risk_bands_do_not_use_incident_severity_wording() -> None:
    thresholds = {
        "high_precision_75": 0.8,
        "balanced_f1": 0.5,
        "high_recall_90": 0.2,
    }
    assert _risk_band(0.9, thresholds) == "very_high"
    assert _risk_band(0.9, thresholds) != "critical"


def test_production_runtime_rejects_nonzero_legacy_component_weight() -> None:
    _validate_site_runtime_weights(
        {
            "lgb_base": 0.35,
            "lgb_weekly_tuned": 0.45,
            "lgb_context": 0.20,
            "cat_base": 0.0,
        }
    )
    with pytest.raises(ValueError, match="non-zero unsupported weights"):
        _validate_site_runtime_weights(
            {
                "lgb_base": 0.30,
                "lgb_weekly_tuned": 0.40,
                "lgb_context": 0.20,
                "cat_base": 0.10,
            }
        )
