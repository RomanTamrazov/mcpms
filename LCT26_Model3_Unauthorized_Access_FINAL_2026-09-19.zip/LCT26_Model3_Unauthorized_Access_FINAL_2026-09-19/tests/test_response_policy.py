from __future__ import annotations

import json
from pathlib import Path

import pytest

from lct26_access.response import (
    IncidentEvidence,
    classify_response,
    validate_feedback_outcome,
)


def test_forecast_alone_never_escalates_above_p4() -> None:
    decision = classify_response(IncidentEvidence(forecast_risk=True))
    assert decision["state"] == "FORECAST_RISK"
    assert decision["priority"] == "P4"
    assert decision["independent_signal_count"] == 0


def test_one_current_signal_is_only_suspected() -> None:
    decision = classify_response(
        IncidentEvidence(forecast_risk=True, security_alarm=True)
    )
    assert decision["state"] == "SUSPECTED_INTRUSION"
    assert decision["priority"] == "P3"


def test_two_independent_signals_are_probable() -> None:
    decision = classify_response(
        IncidentEvidence(security_alarm=True, access_mismatch=True)
    )
    assert decision["state"] == "PROBABLE_INTRUSION"
    assert decision["priority"] == "P2"


def test_human_confirmation_is_p1() -> None:
    decision = classify_response(
        IncidentEvidence(security_alarm=True, human_confirmed_intrusion=True)
    )
    assert decision["state"] == "CONFIRMED_INTRUSION"
    assert decision["priority"] == "P1"


def test_closed_outcome_vocabulary() -> None:
    assert validate_feedback_outcome(" Sensor_Fault ") == "sensor_fault"
    with pytest.raises(ValueError, match="Unknown incident outcome"):
        validate_feedback_outcome("model_says_intrusion")


def test_incident_schema_is_valid_json() -> None:
    path = Path(__file__).parents[1] / "schemas" / "incident_card.schema.json"
    schema = json.loads(path.read_text(encoding="utf-8"))
    assert schema["properties"]["priority"]["enum"] == [
        "NONE",
        "P4",
        "P3",
        "P2",
        "P1",
    ]
