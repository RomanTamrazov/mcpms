from __future__ import annotations

import pytest

from lct26_access.causality import (
    assert_no_failed_features,
    classify_feature_causality,
)


@pytest.mark.parametrize(
    "feature",
    [
        "target",
        "target_next_events",
        "intrusion_events_lead1",
        "future_alarm_count",
        "label_proxy",
    ],
)
def test_future_and_label_features_fail_closed(feature: str) -> None:
    result = classify_feature_causality(feature, model_level="site")
    assert result.causal_status == "fail"
    with pytest.raises(ValueError, match="Non-causal"):
        assert_no_failed_features(["intrusion_events_sum7", feature], model_level="site")


def test_day_d_rollups_are_causal_only_under_end_of_day_cutoff() -> None:
    result = classify_feature_causality("intrusion_events_sum28", model_level="site")
    assert result.causal_status == "pass"
    assert result.actual_max_source_timestamp == "end of D"
    assert "after daily ingestion" in result.availability_at_prediction


def test_target_calendar_is_known_in_advance() -> None:
    result = classify_feature_causality("target_holiday", model_level="site")
    assert result.causal_status == "pass"
    assert result.actual_max_source_timestamp == "calendar only; no future observation"


def test_unversioned_catalog_features_remain_explicit_review_items() -> None:
    result = classify_feature_causality("site_static_channels", model_level="site")
    assert result.causal_status == "review"
    assert "historical availability is unproven" in result.availability_at_prediction
