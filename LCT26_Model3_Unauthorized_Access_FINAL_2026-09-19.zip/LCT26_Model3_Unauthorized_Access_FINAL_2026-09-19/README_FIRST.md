# ЛЦТ 2026 — финальный пакет Модели 3

## С чего начать

Это автономный пакет модели «Несанкционированный доступ» для прогноза риска
охранной SCADA-тревоги на следующие календарные 24 часа и ранжирования наиболее
вероятных зон объекта.

Сначала прочитайте:

1. `reports/FINAL_MODEL3_REPORT.md` — итог, метрики и честная оценка;
2. `reports/MODEL_CARD.md` — назначение, ограничения и запрещённые трактовки;
3. `docs/INTEGRATION_CONTRACT.md` — входы и выходы;
4. `docs/RESPONSE_PLAYBOOK.md` — что делать с прогнозом.

## Важная семантика

Датасет не содержит подтверждённых человеком проникновений. Target — наличие на
следующий день охранного SCADA-события `Обнаружено движение` или `Не замкнут`.
Интерфейс должен называть результат «риском физической охранной тревоги», а не
«подтверждённым вторжением». Прогноз создаёт только превентивную задачу
`FORECAST_RISK / P4` и всегда требует независимой проверки.

## Финальные версии

- site: `model3-site-v2.1-updated-catalog`;
- zone: `model3-zone-v1.1-updated-catalog`;
- режим: `operational_recall_80`;
- порог: `0.35187665923163414`;
- production models: `models/site/` и `models/zone/`;
- CatBoost в runtime не нужен и в production models не включён.

## Быстрый запуск готовых моделей

Требуется Python 3.11+.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-runtime.txt
```

Если подготовленные Parquet-витрины уже есть:

```bash
PYTHONPATH=src python scripts/predict_model3.py \
  --site-features /path/to/daily_site_features.parquet \
  --context-features /path/to/daily_family_context.parquet \
  --zone-features /path/to/daily_zone_features.parquet \
  --site-model-dir models/site \
  --zone-model-dir models/zone \
  --output-dir predictions \
  --threshold-mode operational_recall_80 \
  --top-zones 5
```

Будут созданы:

- `predictions/site_risk_forecast.csv`;
- `predictions/zone_ranking_forecast.csv`;
- `predictions/prediction_run.json`.

Проверка выходного контракта:

```bash
PYTHONPATH=src python scripts/validate_predictions.py \
  --site predictions/site_risk_forecast.csv \
  --zone predictions/zone_ranking_forecast.csv \
  --max-zone-rank 5
```

## Полный путь от архива организаторов

Исходный `dataset (1).zip` в пакет намеренно не дублируется. Для построения
витрин установите полный набор зависимостей и укажите путь к архиву:

```bash
python -m pip install -r requirements.txt
PYTHONPATH=src python scripts/prepare_model3.py \
  --dataset-zip "/path/to/dataset (1).zip" \
  --work-dir work/model3
```

После этого используйте три файла из `work/model3/features/` в команде
инференса выше. Команды полного переобучения описаны в основном `README.md`.

## Честные финальные метрики

На замороженном report-only периоде 2026H1:

| Метрика | Значение |
|---|---:|
| Site PR-AUC | 0.7490 |
| Site ROC-AUC | 0.8461 |
| Site F1 | 0.6952 |
| Site Precision | 0.6092 |
| Site Recall | 0.8096 |
| Zone MRR | 0.6749 |
| Zone Hit@5 | 0.8366 |
| Zone Hit@10 | 0.9337 |
| End-to-end Hit@5 | 0.6963 |

## Структура финального пакета

```text
models/                 минимальные принятые production-модели
src/                    библиотека подготовки и inference
scripts/                запуск, обучение, аудит и эксперименты
configs/                конфигурации
docs/                   контракт и кодекс реагирования
schemas/                JSON Schema карточки инцидента
examples/               шаблон feedback
example_predictions/    проверенный пример результата
reports/                метрики, аудиты и итоговый отчёт
research_evidence/      компактные JSON/MD/CSV результаты экспериментов
tests/                  проверки семантики и безопасности
MANIFEST.sha256         контрольные суммы файлов пакета
```

Большие raw-данные, временные Parquet-витрины и OOF-таблицы не включены: они
воспроизводятся скриптами и только раздули бы передачу. Исторический CatBoost с
нулевым весом также не является частью production runtime; доказательство его
проверки сохранено в отчётах и метаданных.

## Проверка кода

```bash
PYTHONPATH=src python -m pytest -q
ruff check src scripts tests
```

Результаты финального чистого smoke-test зафиксированы в
`reports/FINAL_PACKAGE_QA.md`.

