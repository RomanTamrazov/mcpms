# QA обновлённой Модели 3

Дата: 2026-09-16.

| Проверка | Результат |
|---|---|
| `pytest` | PASS, 17 тестов |
| `ruff check src scripts tests` | PASS |
| `compileall` | PASS |
| Независимый пересчёт метрик | PASS, max delta `0.0` |
| Валидация latest CSV | PASS, ошибок `0` |
| SHA-256 manifest | PASS, 13 файлов |
| Инференс с намеренно заблокированным CatBoost | PASS |
| Повторный inference benchmark | PASS, 7 из 7 выходов идентичны |
| Object mapping в site output | 30 из 30 строк |
| Object mapping в zone output | 130 из 130 строк |

CatBoost имеет нулевой вес в site-ансамбле и не загружается в минимальном
runtime. Latest prediction содержит 30 site-строк, 18 P4-сигналов и 130 строк
zone top-5. Проверка охватывает model-layer; она не заменяет нагрузочный тест
всего веб-сервиса, базы данных, авторизации и 20 одновременных пользователей.
