# Paired bootstrap: strict updated zone model vs previous zone model

Сравнение попарное по тем же site-day. 2025 — development-период; 2026H1 приведён только как report-only holdout.

## 2025

| Bootstrap | Metric | Point delta | 95% CI | P(current better) |
|---|---|---:|---:|---:|
| calendar_day | mrr | -0.00101634 | [-0.00364741, 0.00172547] | 0.2404 |
| calendar_day | hit_rate_at_1 | -0.00131096 | [-0.00600534, 0.00345027] | 0.2858 |
| calendar_day | hit_rate_at_3 | 0.00052438 | [-0.00369108, 0.00473323] | 0.5660 |
| calendar_day | hit_rate_at_5 | -0.00157315 | [-0.00509024, 0.00177084] | 0.1580 |
| calendar_day | hit_rate_at_10 | -0.00104877 | [-0.00314056, 0.00105126] | 0.1276 |
| moving_block_7d | mrr | -0.00101634 | [-0.00369306, 0.00175744] | 0.2320 |
| moving_block_7d | hit_rate_at_1 | -0.00131096 | [-0.00595123, 0.00337680] | 0.2696 |
| moving_block_7d | hit_rate_at_3 | 0.00052438 | [-0.00346166, 0.00466107] | 0.5732 |
| moving_block_7d | hit_rate_at_5 | -0.00157315 | [-0.00465358, 0.00156461] | 0.1362 |
| moving_block_7d | hit_rate_at_10 | -0.00104877 | [-0.00327880, 0.00102782] | 0.1312 |

## 2026H1

| Bootstrap | Metric | Point delta | 95% CI | P(current better) |
|---|---|---:|---:|---:|
| calendar_day | mrr | -0.00350846 | [-0.00698690, -0.00021902] | 0.0194 |
| calendar_day | hit_rate_at_1 | -0.00701187 | [-0.01278509, -0.00157210] | 0.0044 |
| calendar_day | hit_rate_at_3 | 0.00161812 | [-0.00450916, 0.00760467] | 0.6690 |
| calendar_day | hit_rate_at_5 | -0.00431499 | [-0.00978328, 0.00110624] | 0.0520 |
| calendar_day | hit_rate_at_10 | 0.00107875 | [-0.00268962, 0.00519023] | 0.6540 |
| moving_block_7d | mrr | -0.00350846 | [-0.00750762, 0.00052887] | 0.0424 |
| moving_block_7d | hit_rate_at_1 | -0.00701187 | [-0.01378281, -0.00048946] | 0.0174 |
| moving_block_7d | hit_rate_at_3 | 0.00161812 | [-0.00414540, 0.00729167] | 0.6850 |
| moving_block_7d | hit_rate_at_5 | -0.00431499 | [-0.01074099, 0.00208344] | 0.0742 |
| moving_block_7d | hit_rate_at_10 | 0.00107875 | [-0.00219061, 0.00437427] | 0.6756 |

## Verdict

На development-периоде нет статистически подтверждённой материальной деградации более 1 п.п.; строгую fold-local кодировку можно принять как исправление причинности, но не как улучшение ranking-качества.
