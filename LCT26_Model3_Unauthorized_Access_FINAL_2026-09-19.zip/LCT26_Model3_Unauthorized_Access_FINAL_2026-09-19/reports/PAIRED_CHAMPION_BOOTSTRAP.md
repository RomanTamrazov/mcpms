# Paired bootstrap: current champion vs previous champion

Одинаковые site-day строки ресемплируются попарно. Положительная delta 
для PR-AUC/F1/Precision/Recall означает преимущество current; для Brier 
улучшением является отрицательная delta.

2026H1 приведён только как финальный post-hoc report и не участвует в решении.

## 2024

| Bootstrap | Metric | Point delta | 95% CI | P(current better) |
|---|---|---:|---:|---:|
| calendar_day | pr_auc | 0.00410754 | [0.00095253, 0.00741049] | 0.9940 |
| calendar_day | brier | -0.00074256 | [-0.00143458, -0.00004121] | 0.9820 |
| calendar_day | f1 | -0.00046925 | [-0.00405553, 0.00277564] | 0.3965 |
| calendar_day | precision | 0.00132079 | [-0.00228626, 0.00474623] | 0.7680 |
| calendar_day | recall | -0.00320342 | [-0.00852661, 0.00186933] | 0.0955 |
| moving_block_7d | pr_auc | 0.00410754 | [0.00080042, 0.00734646] | 0.9945 |
| moving_block_7d | brier | -0.00074256 | [-0.00142542, -0.00003599] | 0.9805 |
| moving_block_7d | f1 | -0.00046925 | [-0.00382175, 0.00286670] | 0.3915 |
| moving_block_7d | precision | 0.00132079 | [-0.00192709, 0.00487727] | 0.7720 |
| moving_block_7d | recall | -0.00320342 | [-0.00838098, 0.00202897] | 0.0940 |

## 2025

| Bootstrap | Metric | Point delta | 95% CI | P(current better) |
|---|---|---:|---:|---:|
| calendar_day | pr_auc | 0.00354702 | [0.00049148, 0.00661966] | 0.9900 |
| calendar_day | brier | -0.00094935 | [-0.00161865, -0.00028446] | 0.9980 |
| calendar_day | f1 | -0.00201652 | [-0.00548899, 0.00116203] | 0.1175 |
| calendar_day | precision | 0.00112349 | [-0.00257958, 0.00457478] | 0.7215 |
| calendar_day | recall | -0.00707918 | [-0.01205173, -0.00260759] | 0.0020 |
| moving_block_7d | pr_auc | 0.00354702 | [0.00076180, 0.00652007] | 0.9925 |
| moving_block_7d | brier | -0.00094935 | [-0.00158315, -0.00031154] | 0.9980 |
| moving_block_7d | f1 | -0.00201652 | [-0.00529065, 0.00122372] | 0.1125 |
| moving_block_7d | precision | 0.00112349 | [-0.00237916, 0.00465870] | 0.7205 |
| moving_block_7d | recall | -0.00707918 | [-0.01188590, -0.00237514] | 0.0015 |

## 2026H1

| Bootstrap | Metric | Point delta | 95% CI | P(current better) |
|---|---|---:|---:|---:|
| calendar_day | pr_auc | 0.00836731 | [0.00403395, 0.01248150] | 1.0000 |
| calendar_day | brier | -0.00166932 | [-0.00257027, -0.00079714] | 1.0000 |
| calendar_day | f1 | 0.00128568 | [-0.00304341, 0.00538071] | 0.7260 |
| calendar_day | precision | 0.00197143 | [-0.00201227, 0.00605081] | 0.8225 |
| calendar_day | recall | 0.00000000 | [-0.00607311, 0.00601784] | 0.4475 |
| moving_block_7d | pr_auc | 0.00836731 | [0.00401285, 0.01254368] | 1.0000 |
| moving_block_7d | brier | -0.00166932 | [-0.00264071, -0.00065769] | 0.9985 |
| moving_block_7d | f1 | 0.00128568 | [-0.00328198, 0.00584376] | 0.7090 |
| moving_block_7d | precision | 0.00197143 | [-0.00254039, 0.00626954] | 0.8170 |
| moving_block_7d | recall | 0.00000000 | [-0.00664195, 0.00648300] | 0.4680 |

## Development-only verdict

Преимущество current по PR-AUC статистически подтверждено во всех development folds и обеих схемах bootstrap.
