# Checkpoint 004 — final site search and stop decision

Date: 2026-09-19

## Decision

The model search is complete. Experiments `EXP_021`–`EXP_024` did not pass the
predeclared temporal confirmation gates, so none of them is promoted. The
frozen 2026H1 holdout was not used for model selection, acceptance, or stopping.

The production champion therefore remains:

- site risk: `model3-site-v2.1-updated-catalog`;
- zone ranking: `model3-zone-v1.1-updated-catalog`;
- operational threshold: `0.35187665923163414`;
- accepted runtime simplification: `EXP_015_minimal_runtime_no_catboost`.

## Final four experiments

| Experiment | Confirmation evidence | Decision |
|---|---|---|
| `EXP_021_long_horizon_weekly` | PR-AUC delta 2024/2025: `+0.000059 / +0.000004` | Rejected: negligible gain |
| `EXP_022_cross_fitted_logistic_stacker` | PR-AUC delta 2024/2025: `+0.000036 / +0.000028` | Rejected: negligible gain and extra complexity |
| `EXP_023_multi_gap_episodes` | PR-AUC delta 2024/2025: `+0.000667 / -0.000101` | Rejected: not stable across years |
| `EXP_024_single_gap_ablation` | PR-AUC delta 2024/2025: `-0.000021 / -0.000015` | Rejected: compact candidate still lost quality |

## Why the search stops here

- Twenty-four registered experiments now cover leakage controls, temporal
  robustness, target sensitivity, threshold workload, feature pruning,
  alternative blends, longer seasonal history, stacking, episode windows, and
  zone-ranking changes.
- The most recent candidates either add complexity for an immaterial gain or
  fail on one of the two untouched confirmation years.
- Continuing to optimise against the same development years would increase the
  risk of validation overfitting.
- A materially better next iteration needs new confirmed incident outcomes,
  access-control/video context, or a later time period—not more tuning on the
  same proxy labels.

## Simplification outcome

Feature-pruning experiments were deliberately not promoted because the strict
no-loss condition was not met. Runtime simplification was promoted because it
is exact: removing the zero-weight CatBoost branch reduced the model payload by
`31.41%`, removed the CatBoost runtime dependency, and produced byte-identical
site and zone CSV files.

