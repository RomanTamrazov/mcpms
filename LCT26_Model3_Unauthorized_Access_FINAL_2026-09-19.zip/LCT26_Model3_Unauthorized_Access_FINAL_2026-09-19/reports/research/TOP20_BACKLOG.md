# Model 3 — ranked research backlog

Ranking criterion: expected robust development gain or risk reduction divided by
engineering cost, with leakage and operational risk used as penalties. The
frozen 2026H1 holdout is excluded from every selection decision.

| Rank | Priority | Work item | Expected value | Cost | Main risk / gate |
|---:|---|---|---|---|---|
| 1 | P0 | Four-window walk-forward (2022–2025) | High risk reduction | M | Retrospective evidence only; no holdout selection |
| 2 | P0 | Feature-level causality and availability manifest | High risk reduction | S | Latest catalog snapshot may backfill history |
| 3 | P0 | Negative controls and leakage sentinel | High risk reduction | M | Any shuffled-label lift outside sampling noise blocks promotion |
| 4 | P0 | Target sensitivity: motion/contact/count/episode/multi-sensor/burst | High semantic value | S | No proxy may be renamed “real intrusion” |
| 5 | P1.1 | Development-only threshold and workload stability | High operational value | S | Needs explicit business capacity before policy change |
| 6 | P1.2 | Burstiness + recency/hazard features | Medium-high model gain | M | Must remain causal at end-of-day cutoff |
| 7 | P1.3 | Zone hierarchical empirical-Bayes shrinkage | Medium-high ranking gain | M | Fit priors on fold-train only |
| 8 | P1.4 | Constrained OOF blending / regularized stacker | Medium gain | S | Meta-model must be cross-fitted; no same-row fitting |
| 9 | P1.5 | Pseudo-cold-start with ID masking and object mapping | High robustness value | M | Synthetic shift must match plausible deployment |
| 10 | P1.6 | Remove zero-weight CatBoost from production artifact/dependencies | High MLOps value | S | Preserve training evidence and old champion |
| 11 | P1.7 | Recover strict zone Hit@1/Hit@5/MRR | High integrated value | L | Optimise only on development ranking groups |
| 12 | P1 | Episode windows 5/10/15/30/60/120 minutes | Medium gain | M | Multiple testing; predeclare robust gate |
| 13 | P1 | Time-since-last-event hazard buckets and decay curves | Medium gain | M | No event after D cutoff |
| 14 | P1 | Hurdle/count auxiliary target trained by cross-fitting | Medium gain | L | Auxiliary predictions must be OOF |
| 15 | P1 | Fold/season calibration diagnostics | Medium operational value | S | Reject if Brier/logloss worsens on either fold |
| 16 | P1 | Past-only hierarchical target/statistical encodings | Medium gain | M | Strict fold and row-time causality required |
| 17 | P1 | Zone listwise objective and group weighting | Medium gain | M | Guard against large-zone groups dominating |
| 18 | P2 | Stability-selected feature pruning | Low-medium MLOps value | M | Must not trade worst-fold quality for size alone |
| 19 | P2 | Earlier intraday cutoffs (18:00/20:00/22:00) | High product insight | L | Requires rebuilding features with timestamp cutoffs |
| 20 | P2 | Missing-source and drift stress simulations | High resilience value | M | Scenarios must be operationally plausible |

Budget rule: complete mandatory P0, then at most 15 P1 experiments before a
formal review; at most 8 P2 experiments before review. Only 2–3 candidates may
advance to expensive full training, and only after robust development evidence.
