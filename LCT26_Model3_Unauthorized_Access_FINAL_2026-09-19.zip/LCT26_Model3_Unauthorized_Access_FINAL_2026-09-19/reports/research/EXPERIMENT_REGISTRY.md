# Model 3 — canonical experiment registry

Last updated: 2026-09-19

## Frozen champion and protocol

- Site: `model3-site-v2.1-updated-catalog`
- Zone: `model3-zone-v1.1-updated-catalog`
- Site weights: `{"cat_base": 0.0, "lgb_base": 0.35, "lgb_context": 0.2, "lgb_weekly_tuned": 0.45}`
- Zone weights: `{"classifier_rank": 0.35, "ranker_rank": 0.65}`
- Operational threshold: `0.35187665923163414`
- Frozen holdout: `2026H1` — report-only; never used for feature, target, hyperparameter, blend, threshold, acceptance, or stopping decisions

## Experiments

| ID | Priority | Hypothesis | Decision | Development evidence | Holdout used for selection |
|---|---|---|---|---|---|
| `EXP_001_site_episode_features` | historical | Causal within-day alarm episodes improve next-day site ranking. | accepted | PR-AUC gain +0.00458 on 2024 and +0.00344 on 2025 versus the pre-episode champion. | no |
| `EXP_002_zone_episode_features` | historical | Episode features improve conditional zone localisation. | rejected | 2025 Hit@3 0.77976 versus 0.78448 for the then-current zone model. | no |
| `EXP_003_robust_site_variants` | historical | ID-free, recency-weighted, or balanced variants add robust ensemble diversity. | rejected | Best 35% balanced blend improved worst-fold PR-AUC by only 0.0000335, below the predeclared 0.0005 gate. | no |
| `EXP_004_updated_catalog_site_hierarchy` | historical | New object hierarchy fields improve site risk prediction. | rejected | PR-AUC delta -0.000312 on 2024 and +0.000422 on 2025; Brier worsened on both. | no |
| `EXP_005_updated_catalog_zone_hierarchy` | historical | New object hierarchy fields improve zone ranking. | rejected | 2025 deltas: MRR -0.002379, Hit@1 -0.003408, Hit@3 -0.002098, Hit@5 0.000000. | no |
| `EXP_006_expanded_walk_forward` | P0 | The frozen site recipe remains robust across 2022, 2023, 2024, and 2025. | diagnostic | PR-AUC 0.80508/0.79972/0.78177/0.76408 on 2022/2023/2024/2025; worst recall at frozen threshold 0.80059; PR-AUC trend -0.01410 per year. | no |
| `EXP_007_feature_causality_audit` | P0 | Every frozen champion feature is available by the declared end-of-day D cutoff. | diagnostic | 931 unique manifest fields audited: 923 pass, 8 review, 0 fail; deliberate future-feature sentinels fail closed. | no |
| `EXP_008_negative_controls` | P0 | Shuffled labels and random features cannot create robust predictive performance, and future-feature sentinels are rejected. | diagnostic | Reference reproduced exactly; random feature deltas -0.000597/-0.000491; shuffled-label ROC-AUC 0.4946/0.5316 with PR collapse >0.25; future sentinel rejected. | no |
| `EXP_009_target_sensitivity` | P0 | The accepted broad physical-alarm proxy is interpretable relative to narrower event, episode, and multi-sensor definitions. | diagnostic | Primary prevalence 0.36568; contact-open covers 92.96% of primary positives, motion-only 19.84%; narrow variants materially change prevalence and are not promoted. | no |
| `EXP_010_threshold_workload` | P1.1 | The operating threshold is reproducible and its recall/workload trade-off is stable on development data. | diagnostic | Threshold 0.3518766592 reproduced; worst precision 0.63749, worst recall 0.80059, max 13.30 alerts/day; bootstrap threshold 95% interval 0.33013-0.36763. | no |
| `EXP_011_burst_recency` | P1.2 | Additional causal exponential-decay, burst, streak, and recency features improve robust site PR-AUC. | rejected | The best 5% blend changed PR-AUC by +0.000028/+0.000088/+0.000096/+0.000001 on 2022/2023/2024/2025, below the 0.0005 materiality gate. | no |
| `EXP_012_stability_feature_pruning` | P2 | Stable early-fold gain importance can remove at least 20% of feature references without reducing later-fold PR-AUC. | rejected | The selected 40% retention candidate removed 59.92% of feature references but changed 2024/2025 PR-AUC by -0.000086/-0.001341 and worsened Brier. | no |
| `EXP_013_constrained_site_blend` | P1.4 | A nonnegative simplex reweighting selected on 2022/2023 improves both 2024 and 2025. | rejected | Weights 0.275/0.275/0.45 for base/weekly/context changed confirmation PR-AUC by -0.000400 in 2024 and -0.000224 in 2025; Brier worsened. | no |
| `EXP_014_conservative_feature_pruning` | P2 follow-up | The conservative 85% retention candidate improves both early folds and preserves both later folds. | rejected | It removed 14.91% of feature references and changed PR-AUC by +0.000276 on 2024 but -0.000099 on 2025, so the literal no-loss gate failed. | no |
| `EXP_015_minimal_runtime_no_catboost` | P1.6 | The frozen zero-weight CatBoost component can be removed from production runtime with exact output equivalence. | accepted | Site and zone CSVs are byte-identical (maximum probability and rank-score delta 0.0); runtime model payload fell 31.41% from 4,716,900 to 3,235,161 bytes. | no |
| `EXP_016_expanded_zone_walk_forward` | P1.7 diagnostic | The frozen conditional zone-localisation recipe remains stable across several development years. | diagnostic | Blend MRR was 0.69981/0.68533/0.68188 and Hit@5 was 0.85464/0.84971/0.85186 on 2023/2024/2025. | no |
| `EXP_017_zone_hierarchical_shrinkage` | P1.3 | Past-only empirical-Bayes shrinkage improves rare-zone ordering. | rejected | All tested global/family/site priors hurt early folds; the least harmful candidate reduced 2025 MRR by 0.00199 and Hit@3 by 0.00446. | no |
| `EXP_018_zone_group_weighting` | P1.7 | Equalising the influence of site/day groups improves the classifier contribution to zone ranking. | rejected | Sqrt group weighting was best early but changed 2025 MRR by -0.00097, Hit@1 by -0.00184, and Hit@3 by -0.00131. | no |
| `EXP_019_zone_blend_stability` | P1.7 | A blend weight selected on 2023/2024 generalises better than the frozen 0.65 ranker weight. | rejected | A 0.50 ranker weight improved both early folds but reduced 2025 MRR by 0.00172, Hit@3 by 0.00341, and Hit@5 by 0.00157. | no |
| `EXP_020_exclude_2021_training` | P1 data regime | Removing transition-year 2021 training rows improves later site generalisation. | rejected | PR-AUC deltas were -0.00393/-0.00038/-0.00035/-0.00126 on 2022/2023/2024/2025 and Brier worsened in every fold. | no |
| `EXP_021_long_horizon_weekly` | P1 seasonal | Two-to-five-year same-weekday histories add robust seasonal signal beyond the frozen 52-week features. | rejected | A 2.5% candidate blend changed 2024/2025 PR-AUC by +0.000059/+0.000004, far below the materiality gate. | no |
| `EXP_022_cross_fitted_logistic_stacker` | P1 stacker | A lightweight past-OOF logistic stacker improves the three-component site ensemble. | rejected | A 5% stacker blend changed 2024/2025 PR-AUC by +0.000036/+0.000028, below the 0.0005 gate. | no |
| `EXP_023_multi_gap_episodes` | P1 episode windows | Episode summaries at 5/10/15/60/120 minutes add robust information beyond the accepted 30-minute features. | rejected | The selected blend changed PR-AUC by +0.000667 on 2024 but -0.000101 on 2025; Brier improved on 2024 and slightly worsened on 2025. | no |
| `EXP_024_single_gap_ablation` | P1 episode windows follow-up | One compact alternative episode gap can retain the early gain without multi-gap overfitting. | rejected | The early-fold-selected 60-minute candidate reduced PR-AUC by 0.000021/0.000015 on 2024/2025, despite slightly better Brier. | no |

The JSON file is the source of truth. `diagnostic` means evidence/audit only; it does not change the champion. 2026H1 may appear only as an already frozen, report-only result after a decision has been made on development data.
