# Checkpoint 002 — site improvement and inference simplification

Date: 2026-09-19

## Decision

The predictive champion remains unchanged. The production runtime candidate is
accepted without CatBoost because the frozen CatBoost weight is exactly zero and
both final forecast CSV files are byte-identical to the champion outputs.

## Five completed experiments

| Experiment | Result | Decision |
|---|---|---|
| `EXP_011_burst_recency` | 67 causal features; best 5% blend produced only microscopic PR-AUC gains | Rejected below materiality gate |
| `EXP_012_stability_feature_pruning` | 59.92% fewer feature references; PR-AUC −0.000086/−0.001341 on 2024/2025 | Rejected |
| `EXP_013_constrained_site_blend` | Earlier-fold weights degraded both confirmation folds | Rejected |
| `EXP_014_conservative_feature_pruning` | 14.91% fewer feature references; +0.000276/−0.000099 on 2024/2025 | Rejected by literal no-loss gate |
| `EXP_015_minimal_runtime_no_catboost` | Exact outputs; runtime payload −31.41% | Accepted |

## Accepted runtime change

- Shipped site models: three active LightGBM components only.
- Removed from runtime: `cat_base.cbm`, CatBoost-only feature metadata, and the
  optional CatBoost inference branch.
- Runtime dependencies already contained no CatBoost package.
- Site output SHA-256:
  `2a68128a6765d1851fdc754b8ba2f43db9fd861de3b984536b0af7ebedde392f`.
- Zone output SHA-256:
  `26a935d730824b08d3b64e6b382081990a2e250e3e81f37262a2554e2eb1a3de`.
- Maximum probability delta: `0.0`.
- Maximum zone-rank-score delta: `0.0`.
- Runtime payload: `4,716,900 -> 3,235,161` bytes.
- Tests: `26 passed`; Ruff clean.

## Metric interpretation

The honest site ranking metric remains above the requested 0.70 level in every
development year: PR-AUC `0.8051`, `0.7997`, `0.7818`, `0.7641` for 2022–2025.
The frozen report-only 2026H1 PR-AUC remains `0.7490`. The operating-threshold
2026H1 F1 is `0.6952`, slightly below 0.70, while recall is `0.8096`. No threshold
or candidate was selected using 2026H1.

## Guardrails retained

- Target remains a next-day physical SCADA-alarm proxy, not a
  dispatcher-confirmed unauthorized-entry label.
- No 2026H1 holdout row was used for feature, blend, threshold, acceptance, or
  stopping decisions.
- Small apparent gains are not promoted when a predeclared robust/no-loss gate
  fails.
- Full training artifacts are retained for audit; only the deployable runtime is
  simplified.
