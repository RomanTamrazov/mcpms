# Checkpoint 001 — P0 and threshold baseline

Date: 2026-09-16. Frozen champion remains unchanged. The 2026H1 holdout was
not used by any experiment in this checkpoint.

## WHAT I TESTED

1. `EXP_006`: expanded walk-forward for 2022, 2023, 2024, and 2025 using the
   frozen site feature schemas and weights.
2. `EXP_007`: row-level feature lineage/availability audit plus fail-closed
   future-feature tests.
3. `EXP_008`: shuffled labels, an independent random feature, destroyed entity
   identity, top-feature permutation, and a deliberate leakage sentinel.
4. `EXP_009`: target sensitivity for motion, contact, joint evidence, counts,
   multiple zones/sensors, episodes, persistence, and bursts.
5. `EXP_010`: development-only threshold/workload curve and calendar-day
   bootstrap stability.

## WHAT HAPPENED

- Site PR-AUC across the four walk-forward windows is `0.80508`, `0.79972`,
  `0.78177`, and `0.76408`. The four-window mean is `0.78766`; the worst window
  is 2025. The frozen operating threshold keeps recall at or above `0.80059` in
  all four windows.
- Quality has a real downward temporal trend: PR-AUC approximately `-0.01410`
  per year and Brier approximately `+0.00684` per year. This is not a reason to
  tune on the holdout; it is a monitoring and drift-research requirement.
- All 931 unique frozen manifest features were inspected: 923 pass, 8 are
  explicit review items, and 0 fail. The eight review items are static zone
  catalog counts whose historical values cannot be proven without catalog
  version history.
- The weekly component reproduces stored OOF predictions with max absolute
  difference `0.0`. A random feature slightly hurts both folds. Shuffled labels
  collapse ROC-AUC to `0.4946/0.5316`, far below the real component; the future
  sentinel is rejected automatically.
- The first draft of the shuffled-label control was itself invalid because it
  early-stopped on the true validation labels. That result was discarded and
  the final control fixes tree count before scoring five independent label
  permutations. This correction is recorded in the machine report.
- `contact_open_only` covers `92.96%` of accepted proxy-positive days;
  `motion_only` covers `19.84%`. Narrow episode/severity targets range from
  `2.30%` to `28.79%` prevalence and cannot replace the primary target without
  outcome labels.
- The current threshold `0.3518766592` is reproduced exactly. On 2024/2025 it
  gives worst precision `0.63749`, worst recall `0.80059`, and at most `13.30`
  alerts/day. Its calendar-day bootstrap 95% interval is
  `[0.33013, 0.36763]`.

## OLD → NEW

- Validation evidence: 2 development years → 4 development years.
- Leakage statement: aggregate “0 forbidden columns” → 931-field source/window/
  shift/availability manifest with an executable fail-closed gate.
- Threshold evidence: a single selected value → full development curve,
  workload accounting, and bootstrap stability.
- Target semantics: one proxy definition → quantified sensitivity against ten
  narrower, auditable definitions.
- Negative controls: none in the canonical registry → five controls with exact
  reference reproduction.

## ACCEPT / REJECT

- Accept the P0 evidence and automated audit gates.
- Reject changing the target to a narrower proxy: that would be target-shopping
  without dispatcher outcomes.
- Reject changing the operating threshold without a dispatcher capacity or
  false-negative/false-positive cost contract.
- Do not change the champion yet. No P0 experiment is a candidate model.

## WHY

The champion remains strong and reproducible, but the four-year trend and
unversioned catalog fields are genuine risks. The next model experiments should
therefore target robust recency/burst structure, OOF-only blending, cold-start,
and zone shrinkage—not broad blind hyperparameter search.

## NEXT

Proceed through the predeclared P1 backlog in this order:

1. burstiness + recency;
2. zone hierarchical shrinkage;
3. constrained OOF blending/stacking;
4. pseudo-cold-start with identity masking;
5. remove zero-weight CatBoost from the production artifact contract;
6. recover strict zone Hit@1/Hit@5/MRR.

After five additional meaningful experiments, issue Checkpoint 002 before any
deep candidate is allowed to touch the report-only holdout.
