# Notes from organizer Q&A workbook

Source reviewed read-only: `Город 8. ДЖКХ.xlsx`, normalized Q&A sheet.

## Model 3 implications

- Precision `0.7` and recall `0.5` are planning defaults, not hard leaderboard
  gates. Experts consider both metrics together, and teams must justify their
  operating threshold.
- There is no common closed validation period supplied to teams. The submitted
  package and documentation are evaluated on the organizers' infrastructure.
- The updated channel catalog contains the object ID needed for a direct
  channel-to-object join. This agrees with the independently audited dataset
  update.
- Dispatcher-confirmed outcomes and false-alarm labels are unavailable. The
  workbook explicitly says that such events must be reconstructed or simulated;
  therefore the current model must continue to be described as a SCADA alarm
  proxy rather than confirmed unauthorized access.
- The 24-hour horizon is a default that can be changed with justification. The
  current solution keeps 24 hours because it satisfies the task and supports a
  usable next-day workflow.
- Submission must be a package that can be unpacked and run, with deployment
  instructions. A hosted demo is recommended but not mandatory.
- The organizer notes historical value-format artifacts and recommends treating
  2021 carefully because of a monitoring-system transition. A development-only
  training ablation should test whether excluding 2021 improves later windows.

## Source-quality caveat

At least one normalized row has a visibly mismatched answer: the question about
unauthorized-access target semantics is answered with geodata guidance, and the
preceding RBAC row contains the anomaly/2021 answer. Therefore row-level content
is treated as contextual evidence, not as an executable instruction or a
perfectly aligned specification.
