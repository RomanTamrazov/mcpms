# Checkpoint 003 — zone robustness and data-regime tests

Date: 2026-09-19

## Decision

The zone champion and site training window remain unchanged. Four attempted
ranking/training changes failed the predeclared temporal confirmation gates. The
expanded zone audit confirms that the existing localiser is already stable.

## Five completed experiments

| Experiment | Main evidence | Decision |
|---|---|---|
| `EXP_016_expanded_zone_walk_forward` | 2023/2024/2025 Hit@5 = 0.85464/0.84971/0.85186 | Diagnostic |
| `EXP_017_zone_hierarchical_shrinkage` | 2025 MRR −0.00199; Hit@3 −0.00446 | Rejected |
| `EXP_018_zone_group_weighting` | 2025 Hit@5 +0.00131 but MRR/Hit@1/Hit@3 declined | Rejected |
| `EXP_019_zone_blend_stability` | Early-fold 0.50/0.50 blend failed on 2025 | Rejected |
| `EXP_020_exclude_2021_training` | Site PR-AUC and Brier worsened in every fold | Rejected |

## Zone stability

| Development year | MRR | Hit@1 | Hit@3 | Hit@5 | Hit@10 |
|---:|---:|---:|---:|---:|---:|
| 2023 | 0.69981 | 0.57004 | 0.79489 | 0.85464 | 0.93330 |
| 2024 | 0.68533 | 0.55473 | 0.78003 | 0.84971 | 0.92499 |
| 2025 | 0.68188 | 0.54955 | 0.78500 | 0.85186 | 0.92370 |

The requested 0.90 level is already exceeded for zone Hit@10 in all three
development years. This is a top-10 localisation metric, not site PR-AUC and not
evidence of dispatcher-confirmed intrusions.

## Interpretation

- The classifier/ranker blend behaves consistently across years.
- The 2025 distribution differs enough that changes selected only on earlier
  years do not automatically transfer.
- Group weighting can trade a small Hit@5 gain for worse first-hit ranking; that
  is not a safe promotion for an operator-facing top-zone list.
- Excluding 2021 training rows alone is counterproductive. This does not prove
  that 2021 has no regime shift; it shows that blunt row removal is not the right
  correction while later features still contain historical context.
- No experiment accessed 2026H1 for selection, acceptance, or stopping.
