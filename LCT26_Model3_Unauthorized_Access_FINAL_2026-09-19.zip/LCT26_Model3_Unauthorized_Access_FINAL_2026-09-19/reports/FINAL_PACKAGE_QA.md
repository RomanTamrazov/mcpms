# Final package QA

Date: 2026-09-19.

## Release decision

Status: **PASS** for the checked model release candidate. The final archive is
built only from this candidate and the accepted minimal runtime artifacts.

## Checks completed before packaging

| Check | Result |
|---|---:|
| Experiment registry validation | 24 experiments, PASS |
| Full Pytest suite | 26 passed |
| Ruff on `src`, `scripts`, `tests` | PASS |
| Minimal runtime prediction | PASS |
| Output schema/semantic validation | PASS |
| Site output rows / alerts | 30 / 18 |
| Zone output rows / sites | 130 / 30 |
| Maximum zone rank | 5 |
| Site CSV equality with accepted reference | byte-identical |
| Zone CSV equality with accepted reference | byte-identical |

The checked batch used `as_of=2026-06-30`, forecast date `2026-07-01`, the
`operational_recall_80` threshold and top-5 zones. Total cold-process runtime on
the local QA machine was `3.8042` seconds for 30 sites and 1,031 candidate
zones. This is a machine-specific smoke measurement, not a universal latency
guarantee.

## Accepted output checksums

```text
2a68128a6765d1851fdc754b8ba2f43db9fd861de3b984536b0af7ebedde392f  site_risk_forecast.csv
26a935d730824b08d3b64e6b382081990a2e250e3e81f37262a2554e2eb1a3de  zone_ranking_forecast.csv
```

## Package safeguards

- production `models/` contains only the three positively weighted site
  LightGBM components and two zone LightGBM components;
- CatBoost and its runtime dependency are absent from the accepted serving
  payload;
- raw organizer data, prepared feature Parquets and OOF Parquets are excluded;
- reports and compact JSON/Markdown/CSV experiment evidence are included;
- every packaged file is covered by `MANIFEST.sha256`;
- the archive build refuses to overwrite an existing final delivery.

After packaging, delivery requires three external release checks: ZIP integrity,
manifest verification after clean extraction, and inference from the extracted
`models/` and `src/`. These checks do not modify model selection or metrics.

