# EXP_010 — threshold and workload (development only)

No 2026H1 row is used. The current operating threshold is reproduced from 2024/2025 OOF.

| Policy | Threshold | Worst precision | Worst recall | Max alerts/day | Max FP/day |
|---|---:|---:|---:|---:|---:|
| balanced_f1 | 0.325486 | 0.6246 | 0.8243 | 14.01 | 5.26 |
| recall_floor_0.75 | 0.405427 | 0.6627 | 0.7512 | 12.07 | 4.07 |
| recall_floor_0.80 | 0.351877 | 0.6375 | 0.8006 | 13.30 | 4.82 |
| recall_floor_0.85 | 0.287710 | 0.6030 | 0.8508 | 14.93 | 5.93 |
| recall_floor_0.90 | 0.208040 | 0.5605 | 0.9002 | 16.95 | 7.45 |

Calendar-day bootstrap threshold median: 0.349924; 95% interval: [0.330129, 0.367629].

No threshold change is accepted without an explicit dispatcher cost or capacity target.
