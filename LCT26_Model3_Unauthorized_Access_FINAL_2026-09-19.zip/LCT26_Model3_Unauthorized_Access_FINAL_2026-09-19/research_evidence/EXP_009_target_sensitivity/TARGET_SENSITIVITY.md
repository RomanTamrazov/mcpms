# EXP_009 — target sensitivity (development only)

The table uses the frozen champion OOF score. No model was selected or retrained, and 2026H1 was not accessed.

| Target | Prevalence | PR-AUC | PR lift | Jaccard vs primary |
|---|---:|---:|---:|---:|
| primary_any_physical_alarm | 0.3657 | 0.7725 | 2.11 | 1.0000 |
| motion_only | 0.0726 | 0.1407 | 1.94 | 0.1984 |
| contact_open_only | 0.3399 | 0.7573 | 2.23 | 0.9296 |
| motion_and_contact | 0.0468 | 0.1281 | 2.74 | 0.1280 |
| event_count_ge_2 | 0.2879 | 0.7137 | 2.48 | 0.7873 |
| multi_zone | 0.2022 | 0.5422 | 2.68 | 0.5530 |
| multiple_sensor_families | 0.0785 | 0.2521 | 3.21 | 0.2147 |
| multi_event_episode | 0.2499 | 0.6441 | 2.58 | 0.6833 |
| multi_episode_day | 0.2169 | 0.6691 | 3.08 | 0.5933 |
| burst_ge_3_events | 0.1730 | 0.5480 | 3.17 | 0.4730 |
| motion_contact_same_episode | 0.0230 | 0.0528 | 2.30 | 0.0628 |

These are proxy variants, not verified unauthorized-entry outcomes. The broad primary label stays canonical until dispatcher-confirmed incident outcomes exist.
