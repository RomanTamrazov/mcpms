# EXP_007 — feature-level causality audit

Forecast cutoff: after ingestion of calendar day D; target: calendar day D+1.

- Unique manifest features: 931
- Pass: 923
- Review: 8
- Fail: 0
- Automatic gate: PASS

`review` is not a hidden pass: it records unversioned static catalog attributes. They are usable now, but their historical state cannot be reconstructed from the archive.

Full row-level lineage is in `feature_causality_audit.csv` and JSON.
