"""Build the compact, machine-readable validation summary from model artifacts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import pandas as pd
from sklearn.metrics import f1_score, precision_score, recall_score


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-metadata", type=Path, required=True)
    parser.add_argument("--zone-metadata", type=Path, required=True)
    parser.add_argument("--site-oof", type=Path, required=True)
    parser.add_argument("--robustness-audit", type=Path, required=True)
    parser.add_argument("--metric-uncertainty", type=Path, required=True)
    parser.add_argument("--prediction-run", type=Path, required=True)
    parser.add_argument("--acceptance-check", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _fold(rows: list[dict[str, Any]], name: str) -> dict[str, Any]:
    return next(row for row in rows if row["fold"] == name)


def _threshold_metrics(
    frame: pd.DataFrame,
    threshold: float,
) -> dict[str, float | int]:
    predicted = frame["ensemble_probability"] >= threshold
    return {
        "threshold": threshold,
        "f1": float(f1_score(frame["target"], predicted)),
        "precision": float(precision_score(frame["target"], predicted, zero_division=0)),
        "recall": float(recall_score(frame["target"], predicted, zero_division=0)),
        "alerts": int(predicted.sum()),
        "alerts_per_day": float(predicted.sum() / frame["target_date"].nunique()),
        "proxy_false_alerts": int(((frame["target"] == 0) & predicted).sum()),
    }


def main() -> None:
    args = parse_args()
    site = _read_json(args.site_metadata)
    zone = _read_json(args.zone_metadata)
    robustness = _read_json(args.robustness_audit)
    uncertainty = _read_json(args.metric_uncertainty)
    prediction = _read_json(args.prediction_run)
    acceptance = _read_json(args.acceptance_check)
    oof = pd.read_parquet(args.site_oof)
    holdout_oof = oof[oof["fold"] == "2026H1"]
    site_holdout = _fold(site["validation"]["ensemble"], "2026H1")
    thresholds = site["decision_thresholds_from_2024_2025"]
    zone_holdout = _fold(zone["validation"]["blend"], "2026H1")
    zone_baseline = _fold(zone["baseline_90day_rate"], "2026H1")
    previous_day = _fold(
        site["validation"]["baselines"]["previous_day_state"], "2026H1"
    )
    rate_28 = _fold(
        site["validation"]["baselines"]["positive_day_rate_28d"], "2026H1"
    )
    report = {
        "validation_design": {
            "development_folds": [
                "train < 2024-01-01, validate 2024",
                "train < 2025-01-01, validate 2025",
            ],
            "final_holdout": (
                "train < 2026-01-01, test 2026-01-01..2026-06-30"
            ),
            "holdout_rule": (
                "No feature, weight, threshold, calibration-family, or iteration "
                "tuning on 2026H1."
            ),
        },
        "site_ensemble": {
            "model_version": site["model_version"],
            "default_threshold_mode": site["default_threshold_mode"],
            "weights": site["ensemble_weights"],
            "thresholds_selected_on_2024_2025": thresholds,
            "balanced_threshold_selection": site["balanced_threshold_selection"],
            "operational_threshold_selection": site[
                "operational_threshold_selection"
            ],
            "uncertainty": site["uncertainty"],
            "fold_pr_auc": {
                row["fold"]: row["pr_auc"]
                for row in site["validation"]["ensemble"]
            },
            "holdout_2026H1": {
                key: site_holdout[key]
                for key in ("rows", "prevalence", "roc_auc", "pr_auc", "logloss", "brier")
            }
            | {
                "default_operational": _threshold_metrics(
                    holdout_oof, thresholds[site["default_threshold_mode"]]
                )
                | {"mode": site["default_threshold_mode"]},
                "balanced": _threshold_metrics(
                    holdout_oof, thresholds["balanced_f1"]
                ),
                "high_precision_target": _threshold_metrics(
                    holdout_oof, thresholds["high_precision_75"]
                )
                | {
                    "note": (
                        "75% was the development-fold target, not a holdout guarantee."
                    )
                },
                "high_recall_target": _threshold_metrics(
                    holdout_oof, thresholds["high_recall_90"]
                ),
                "precision_at_3_per_day": site_holdout["precision_at_3"],
                "precision_at_5_per_day": site_holdout["precision_at_5"],
                "precision_at_10_per_day": site_holdout["precision_at_10"],
            },
            "holdout_baselines": {
                "previous_day_state": previous_day,
                "positive_day_rate_28d": rate_28,
            },
        },
        "zone_localisation": {
            "model_version": zone["model_version"],
            "conditioning": (
                "Evaluated only inside site-days containing at least one positive zone."
            ),
            "weights": zone["blend_weights"],
            "holdout_2026H1": zone_holdout,
            "holdout_90day_rate_baseline": zone_baseline,
        },
        "robustness": {
            "target_episode_audit": robustness["target_episode_audit"],
            "feature_availability": robustness["feature_availability"],
            "natural_cold_start": robustness["natural_cold_start"],
            "calibration": robustness["calibration"],
            "ensemble_uncertainty": robustness["ensemble_uncertainty"],
            "temporal_drift": robustness["temporal_drift"],
            "dispatcher_workload": robustness["dispatcher_workload"],
            "end_to_end_localisation": robustness["end_to_end_localisation"],
        },
        "metric_uncertainty": uncertainty,
        "tail_inference_smoke_test": {
            key: prediction[key]
            for key in (
                "as_of_date",
                "forecast_date",
                "site_model_version",
                "zone_model_version",
                "site_rows",
                "alert_rows",
                "zone_candidate_rows",
                "zone_output_rows",
                "zone_sites_with_candidates",
                "zone_sites_with_fewer_than_top_k",
                "total_prediction_seconds",
            )
        },
        "acceptance": acceptance,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
