"""Validate and render the canonical Model 3 experiment registry."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

ID_PATTERN = re.compile(r"^EXP_(\d{3})_[a-z0-9_]+$")
ALLOWED_DECISIONS = {"accepted", "rejected", "diagnostic", "planned", "running"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--registry", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    registry = json.loads(args.registry.read_text(encoding="utf-8"))
    experiments = registry["experiments"]
    numbers: list[int] = []
    seen: set[str] = set()
    for experiment in experiments:
        experiment_id = experiment["id"]
        match = ID_PATTERN.fullmatch(experiment_id)
        if not match:
            raise ValueError(f"Invalid experiment id: {experiment_id}")
        if experiment_id in seen:
            raise ValueError(f"Duplicate experiment id: {experiment_id}")
        if experiment["decision"] not in ALLOWED_DECISIONS:
            raise ValueError(f"Invalid decision for {experiment_id}: {experiment['decision']}")
        seen.add(experiment_id)
        numbers.append(int(match.group(1)))
    if numbers != sorted(numbers):
        raise ValueError("Experiment registry must be ordered by numeric id")

    champion = registry["champion"]
    lines = [
        "# Model 3 — canonical experiment registry",
        "",
        f"Last updated: {registry['last_updated']}",
        "",
        "## Frozen champion and protocol",
        "",
        f"- Site: `{champion['site_version']}`",
        f"- Zone: `{champion['zone_version']}`",
        f"- Site weights: `{json.dumps(champion['site_weights'], sort_keys=True)}`",
        f"- Zone weights: `{json.dumps(champion['zone_weights'], sort_keys=True)}`",
        f"- Operational threshold: `{champion['operational_threshold']}`",
        (
            f"- Frozen holdout: `{registry['holdout_policy']['fold']}` — "
            f"{registry['holdout_policy']['rule']}"
        ),
        "",
        "## Experiments",
        "",
        "| ID | Priority | Hypothesis | Decision | Development evidence | Holdout used for selection |",
        "|---|---|---|---|---|---|",
    ]
    for experiment in experiments:
        evidence = str(experiment.get("development_evidence", "")).replace("|", "/")
        hypothesis = str(experiment["hypothesis"]).replace("|", "/")
        lines.append(
            f"| `{experiment['id']}` | {experiment['priority']} | {hypothesis} | "
            f"{experiment['decision']} | {evidence} | "
            f"{'yes' if experiment['holdout_used_for_selection'] else 'no'} |"
        )
    lines.extend(
        [
            "",
            (
                "The JSON file is the source of truth. `diagnostic` means evidence/audit only; it "
                "does not change the champion. 2026H1 may appear only as an already frozen, "
                "report-only result after a decision has been made on development data."
            ),
        ]
    )
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"validated {len(experiments)} experiments -> {args.output}")


if __name__ == "__main__":
    main()
