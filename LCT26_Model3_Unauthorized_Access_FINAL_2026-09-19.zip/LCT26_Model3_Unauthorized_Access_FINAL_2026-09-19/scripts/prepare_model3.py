"""Extract the supplied archive and build compact causal feature tables."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from lct26_access.data import extract_dataset, materialize_security_events
from lct26_access.features import (
    build_context_daily,
    build_site_feature_table,
    build_zone_feature_table,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset-zip", type=Path, required=True)
    parser.add_argument("--work-dir", type=Path, required=True)
    parser.add_argument("--years", nargs="+", type=int, default=list(range(2019, 2027)))
    parser.add_argument("--skip-zone-features", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    work_dir = args.work_dir.expanduser().resolve()
    cache_dir = work_dir / "cache"
    feature_dir = work_dir / "features"
    cache_dir.mkdir(parents=True, exist_ok=True)
    feature_dir.mkdir(parents=True, exist_ok=True)

    catalog_dir, csv_dir = extract_dataset(args.dataset_zip, work_dir)
    audit = materialize_security_events(
        catalog_dir, csv_dir, cache_dir, years=args.years
    )
    site_path = feature_dir / "daily_site_features.parquet"
    context_path = feature_dir / "daily_family_context.parquet"
    zone_path = feature_dir / "daily_zone_features.parquet"
    site = build_site_feature_table(cache_dir / "security_events", catalog_dir, site_path)
    context = build_context_daily(csv_dir, catalog_dir, args.years, context_path)
    zone_shape = None
    if not args.skip_zone_features:
        zone = build_zone_feature_table(
            cache_dir / "security_events", catalog_dir, site_path, zone_path
        )
        zone_shape = zone.shape

    summary = {
        "audit": audit,
        "site_feature_path": str(site_path),
        "site_shape": site.shape,
        "context_feature_path": str(context_path),
        "context_shape": context.shape,
        "zone_feature_path": str(zone_path) if zone_shape else None,
        "zone_shape": zone_shape,
    }
    (work_dir / "prepare_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
