"""Development-only threshold, workload, and stability analysis.

All policy candidates are derived from 2024/2025 OOF predictions.  The frozen
2026H1 holdout is filtered before any computation and is never loaded into a
selection frame.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, precision_score, recall_score

from lct26_access.metrics import robust_f1_threshold, threshold_for_min_group_recall

DEVELOPMENT_FOLDS = ("2024", "2025")
RECALL_FLOORS = (0.75, 0.80, 0.85, 0.90)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--champion-oof", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--bootstrap-draws", type=int, default=500)
    return parser.parse_args()


def evaluate_threshold(frame: pd.DataFrame, threshold: float) -> dict[str, Any]:
    result: dict[str, Any] = {"threshold": float(threshold), "folds": {}}
    fold_values: list[dict[str, float]] = []
    for fold, group in frame.groupby("fold", sort=True):
        y = group["target"].to_numpy(dtype="int8")
        predicted = group["ensemble_probability"].to_numpy(dtype=float) >= threshold
        days = group["target_date"].nunique()
        values = {
            "precision": float(precision_score(y, predicted, zero_division=0)),
            "recall": float(recall_score(y, predicted, zero_division=0)),
            "f1": float(f1_score(y, predicted, zero_division=0)),
            "alerts": int(predicted.sum()),
            "alerts_per_day": float(predicted.sum() / days),
            "false_positives_per_day": float(((predicted == 1) & (y == 0)).sum() / days),
            "false_negatives_per_day": float(((predicted == 0) & (y == 1)).sum() / days),
            "review_share": float(predicted.mean()),
        }
        result["folds"][str(fold)] = values
        fold_values.append(values)
    result["robust"] = {
        "minimum_precision": min(item["precision"] for item in fold_values),
        "minimum_recall": min(item["recall"] for item in fold_values),
        "minimum_f1": min(item["f1"] for item in fold_values),
        "maximum_alerts_per_day": max(item["alerts_per_day"] for item in fold_values),
        "maximum_false_positives_per_day": max(
            item["false_positives_per_day"] for item in fold_values
        ),
        "maximum_false_negatives_per_day": max(
            item["false_negatives_per_day"] for item in fold_values
        ),
    }
    return result


def threshold_curve(frame: pd.DataFrame) -> list[dict[str, Any]]:
    score = frame["ensemble_probability"].to_numpy(dtype=float)
    grid = np.unique(np.quantile(score, np.linspace(0.01, 0.99, 199)))
    return [evaluate_threshold(frame, float(threshold)) for threshold in grid]


def _bootstrap_selection(
    frame: pd.DataFrame,
    *,
    minimum_recall: float,
    draws: int,
    seed: int = 2603,
) -> dict[str, Any]:
    """Calendar-day bootstrap with vectorised robust threshold selection."""

    rng = np.random.default_rng(seed)
    grid = np.unique(
        np.quantile(
            frame["ensemble_probability"].to_numpy(dtype=float), np.linspace(0.02, 0.98, 500)
        )
    )
    fold_days = {
        fold: np.asarray(sorted(group["target_date"].dt.normalize().unique()))
        for fold, group in frame.groupby("fold", sort=True)
    }
    by_fold_day = {
        fold: {
            day: day_frame.index.to_numpy()
            for day, day_frame in group.groupby(group["target_date"].dt.normalize())
        }
        for fold, group in frame.groupby("fold", sort=True)
    }
    thresholds: list[float] = []
    minimum_precisions: list[float] = []
    alerts_per_day: list[float] = []
    for _ in range(draws):
        fold_stats: list[dict[str, np.ndarray]] = []
        total_days = 0
        for fold in DEVELOPMENT_FOLDS:
            days = fold_days[fold]
            sampled_days = rng.choice(days, size=days.size, replace=True)
            indices = np.concatenate([by_fold_day[fold][day] for day in sampled_days])
            sampled = frame.loc[indices]
            y = sampled["target"].to_numpy(dtype="int8")
            p = sampled["ensemble_probability"].to_numpy(dtype=float)
            positive_scores = np.sort(p[y == 1])
            negative_scores = np.sort(p[y == 0])
            tp = positive_scores.size - np.searchsorted(positive_scores, grid, side="left")
            fp = negative_scores.size - np.searchsorted(negative_scores, grid, side="left")
            recall = tp / max(1, positive_scores.size)
            precision = np.divide(
                tp, tp + fp, out=np.zeros_like(tp, dtype=float), where=(tp + fp) > 0
            )
            f1 = np.divide(
                2 * precision * recall,
                precision + recall,
                out=np.zeros_like(precision),
                where=(precision + recall) > 0,
            )
            fold_stats.append(
                {"tp": tp, "fp": fp, "recall": recall, "precision": precision, "f1": f1}
            )
            total_days += days.size

        eligible = np.logical_and.reduce(
            [statistics["recall"] >= minimum_recall for statistics in fold_stats]
        )
        candidate_indices = np.flatnonzero(eligible)
        if candidate_indices.size == 0:
            continue
        best_index = max(
            candidate_indices,
            key=lambda index: (
                min(statistics["precision"][index] for statistics in fold_stats),
                np.mean([statistics["precision"][index] for statistics in fold_stats]),
                min(statistics["f1"][index] for statistics in fold_stats),
                grid[index],
            ),
        )
        thresholds.append(float(grid[best_index]))
        minimum_precisions.append(
            float(min(statistics["precision"][best_index] for statistics in fold_stats))
        )
        total_alerts = sum(
            int(statistics["tp"][best_index] + statistics["fp"][best_index])
            for statistics in fold_stats
        )
        alerts_per_day.append(float(total_alerts / total_days))

    if not thresholds:
        raise RuntimeError("No bootstrap draw produced a feasible threshold")

    def interval(values: list[float]) -> dict[str, float]:
        array = np.asarray(values, dtype=float)
        return {
            "median": float(np.median(array)),
            "p2_5": float(np.quantile(array, 0.025)),
            "p97_5": float(np.quantile(array, 0.975)),
        }

    return {
        "requested_draws": draws,
        "successful_draws": len(thresholds),
        "resampling_unit": "calendar day independently within each development fold",
        "minimum_recall": minimum_recall,
        "threshold": interval(thresholds),
        "minimum_precision": interval(minimum_precisions),
        "pooled_alerts_per_day": interval(alerts_per_day),
    }


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    raw_oof = pd.read_parquet(args.champion_oof)
    raw_oof["target_date"] = pd.to_datetime(raw_oof["target_date"])
    frame = raw_oof[raw_oof["fold"].isin(DEVELOPMENT_FOLDS)].copy()
    if set(frame["fold"].unique()) != set(DEVELOPMENT_FOLDS):
        raise ValueError("Both 2024 and 2025 development folds are required")
    if (frame["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen holdout entered threshold analysis")

    balanced, balanced_details = robust_f1_threshold(
        frame["target"], frame["ensemble_probability"], frame["fold"]
    )
    policies: dict[str, Any] = {
        "balanced_f1": {
            "selection": balanced_details,
            "performance": evaluate_threshold(frame, balanced),
        }
    }
    for floor in RECALL_FLOORS:
        threshold, details = threshold_for_min_group_recall(
            frame["target"], frame["ensemble_probability"], frame["fold"], floor
        )
        policies[f"recall_floor_{floor:.2f}"] = {
            "selection": details,
            "performance": evaluate_threshold(frame, threshold),
        }

    current_threshold = float(
        metadata["decision_thresholds_from_2024_2025"]["operational_recall_80"]
    )
    selected_threshold = policies["recall_floor_0.80"]["performance"]["threshold"]
    if not np.isclose(current_threshold, selected_threshold, atol=1e-12):
        raise AssertionError(
            f"Current threshold {current_threshold} is not reproducible: {selected_threshold}"
        )

    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    curve = threshold_curve(frame)
    pd.DataFrame(
        [
            {
                "threshold": row["threshold"],
                "fold": fold,
                **values,
            }
            for row in curve
            for fold, values in row["folds"].items()
        ]
    ).to_csv(output / "threshold_workload_curve.csv", index=False)

    report = {
        "experiment_id": "EXP_010_threshold_workload",
        "status": "diagnostic",
        "protocol": {
            "folds": list(DEVELOPMENT_FOLDS),
            "holdout_2026h1_accessed": False,
            "selection_data": "OOF predictions only",
            "current_threshold_reproduced": True,
        },
        "policies": policies,
        "bootstrap_stability_recall_0.80": _bootstrap_selection(
            frame,
            minimum_recall=0.80,
            draws=args.bootstrap_draws,
        ),
        "decision": {
            "accepted_change": False,
            "reason": (
                "No business cost ratio or hard alert budget was supplied. The existing 0.80 "
                "recall-floor policy is reproducible; alternatives are reported, not silently "
                "promoted."
            ),
        },
    }
    (output / "threshold_workload_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    lines = [
        "# EXP_010 — threshold and workload (development only)",
        "",
        "No 2026H1 row is used. The current operating threshold is reproduced from 2024/2025 OOF.",
        "",
        "| Policy | Threshold | Worst precision | Worst recall | Max alerts/day | Max FP/day |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for name, policy in policies.items():
        robust = policy["performance"]["robust"]
        lines.append(
            f"| {name} | {policy['performance']['threshold']:.6f} | "
            f"{robust['minimum_precision']:.4f} | {robust['minimum_recall']:.4f} | "
            f"{robust['maximum_alerts_per_day']:.2f} | "
            f"{robust['maximum_false_positives_per_day']:.2f} |"
        )
    stability = report["bootstrap_stability_recall_0.80"]
    lines.extend(
        [
            "",
            (
                f"Calendar-day bootstrap threshold median: {stability['threshold']['median']:.6f}; "
                f"95% interval: [{stability['threshold']['p2_5']:.6f}, "
                f"{stability['threshold']['p97_5']:.6f}]."
            ),
            "",
            "No threshold change is accepted without an explicit dispatcher cost or capacity target.",
        ]
    )
    (output / "THRESHOLD_WORKLOAD.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
