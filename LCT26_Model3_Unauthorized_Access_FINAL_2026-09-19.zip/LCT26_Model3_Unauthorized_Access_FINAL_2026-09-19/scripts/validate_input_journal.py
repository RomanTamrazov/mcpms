"""Validate an incoming event journal against the model-3 source contract."""

from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path

import polars as pl

from lct26_access.constants import JOURNAL_COLUMNS, SECURITY_SYSTEM
from lct26_access.data import alarm_flag_expression, read_channel_catalog, scan_journal

VALID_ALARM_TOKENS = ("0", "1", "f", "false", "t", "true")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--journal", type=Path, required=True)
    parser.add_argument("--channel-catalog-dir", type=Path, required=True)
    parser.add_argument("--previous-history-max-date", type=date.fromisoformat)
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def audit_journal(
    journal: Path,
    catalog_dir: Path,
    *,
    previous_history_max_date: date | None = None,
) -> dict[str, object]:
    channels = read_channel_catalog(catalog_dir)
    known_ids = channels["ид_канала_данных"].to_list()
    frame = (
        scan_journal(journal)
        .with_columns(
            [
                alarm_flag_expression().alias("alarm"),
                pl.col("тревожное")
                .cast(pl.String)
                .str.to_lowercase()
                .str.strip_chars()
                .alias("alarm_token"),
                (pl.col("дата") + " " + pl.col("время"))
                .str.to_datetime("%Y-%m-%d %H:%M:%S", strict=False)
                .alias("ts"),
            ]
        )
        .collect(engine="streaming")
    )
    invalid_ids = int(
        frame.select(
            (
                pl.col("ид_события").is_null()
                | pl.col("ид_канала_данных").is_null()
            ).sum()
        ).item()
    )
    malformed_timestamps = int(frame["ts"].null_count())
    unknown_alarm_tokens = (
        frame.filter(
            pl.col("alarm_token").is_not_null()
            & ~pl.col("alarm_token").is_in(VALID_ALARM_TOKENS)
        )["alarm_token"]
        .unique()
        .sort()
        .to_list()
    )
    unknown_channels = frame.filter(
        pl.col("ид_канала_данных").is_not_null()
        & ~pl.col("ид_канала_данных").is_in(known_ids)
    )
    valid = frame.filter(
        pl.col("ид_события").is_not_null()
        & pl.col("ид_канала_данных").is_not_null()
        & pl.col("ts").is_not_null()
    )
    duplicate_rows = valid.height - valid.select(
        pl.struct([*JOURNAL_COLUMNS, "alarm"]).n_unique()
    ).item()
    enriched = valid.join(channels, on="ид_канала_данных", how="left")
    security = enriched.filter(pl.col("тип_инж_системы") == SECURITY_SYSTEM)
    min_date = valid["ts"].min().date() if valid.height else None
    gap_days = None
    if previous_history_max_date is not None and min_date is not None:
        gap_days = max(0, (min_date - previous_history_max_date).days - 1)

    errors: list[str] = []
    warnings: list[str] = []
    if invalid_ids:
        errors.append(f"{invalid_ids} rows contain invalid IDs or repeated headers")
    if malformed_timestamps:
        errors.append(f"{malformed_timestamps} rows contain malformed timestamps")
    if unknown_alarm_tokens:
        errors.append(f"unknown alarm tokens: {unknown_alarm_tokens}")
    if unknown_channels.height:
        errors.append(f"{unknown_channels.height} rows reference unknown channel IDs")
    if duplicate_rows:
        warnings.append(f"{duplicate_rows} exact logical duplicates should be removed")
    if gap_days:
        warnings.append(
            f"{gap_days} calendar days are missing between history and incoming journal"
        )
    if frame.height == 0:
        errors.append("journal is empty")

    return {
        "status": "error" if errors else "ok_with_warnings" if warnings else "ok",
        "journal": str(journal.resolve()),
        "rows": frame.height,
        "valid_rows": valid.height,
        "min_timestamp": valid["ts"].min().isoformat() if valid.height else None,
        "max_timestamp": valid["ts"].max().isoformat() if valid.height else None,
        "alarm_rows": int(valid["alarm"].sum()) if valid.height else 0,
        "security_rows": security.height,
        "security_alarm_rows": int(security["alarm"].sum()) if security.height else 0,
        "unknown_channel_rows": unknown_channels.height,
        "invalid_id_rows": invalid_ids,
        "malformed_timestamp_rows": malformed_timestamps,
        "exact_duplicate_rows": int(duplicate_rows),
        "unknown_alarm_tokens": unknown_alarm_tokens,
        "gap_days_after_previous_history": gap_days,
        "errors": errors,
        "warnings": warnings,
    }


def main() -> None:
    args = parse_args()
    report = audit_journal(
        args.journal,
        args.channel_catalog_dir,
        previous_history_max_date=args.previous_history_max_date,
    )
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered)
    if report["status"] == "error":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
