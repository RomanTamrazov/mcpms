"""Evaluate official model-layer requirements and an explicit internal ML gate.

The official task specification does not define numeric Precision/Recall minima.
Consequently, the script reports those values without presenting the internal
shadow-mode thresholds as organiser-provided acceptance criteria.
"""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--site-metadata", type=Path, required=True)
    parser.add_argument("--zone-metadata", type=Path, required=True)
    parser.add_argument("--robustness-audit", type=Path, required=True)
    parser.add_argument("--metric-uncertainty", type=Path, required=True)
    parser.add_argument("--prediction-run", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    return parser.parse_args()


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _read_thresholds(path: Path) -> dict[str, float]:
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    raw = config["internal_shadow_acceptance"]
    return {
        "site_pr_auc": float(raw["min_site_pr_auc"]),
        "site_pr_auc_gain_vs_28d_baseline": float(
            raw["min_site_pr_auc_gain_vs_28d_baseline"]
        ),
        "site_f1": float(raw["min_site_f1"]),
        "site_precision": float(raw["min_site_precision"]),
        "site_recall": float(raw["min_site_recall"]),
        "zone_hit_rate_at_5": float(raw["min_zone_hit_rate_at_5"]),
        "zone_hit_rate_at_5_gain_vs_90d_baseline": float(
            raw["min_zone_hit_rate_gain_at_5_vs_90d_baseline"]
        ),
        "end_to_end_hit_at_5": float(raw["min_end_to_end_hit_at_5"]),
        "max_prediction_psi_vs_2024": float(
            raw["max_prediction_psi_vs_2024"]
        ),
    }


def _fold(rows: list[dict[str, Any]], name: str) -> dict[str, Any]:
    return next(row for row in rows if row["fold"] == name)


def _minimum_check(
    name: str,
    actual: float,
    minimum: float,
    *,
    rationale: str,
) -> dict[str, Any]:
    return {
        "name": name,
        "actual": float(actual),
        "operator": ">=",
        "threshold": float(minimum),
        "passed": bool(actual >= minimum),
        "rationale": rationale,
    }


def _maximum_check(
    name: str,
    actual: float,
    maximum: float,
    *,
    rationale: str,
) -> dict[str, Any]:
    return {
        "name": name,
        "actual": float(actual),
        "operator": "<=",
        "threshold": float(maximum),
        "passed": bool(actual <= maximum),
        "rationale": rationale,
    }


def build_report(
    site: dict[str, Any],
    zone: dict[str, Any],
    robustness: dict[str, Any],
    uncertainty: dict[str, Any],
    prediction: dict[str, Any],
    thresholds: dict[str, float],
) -> dict[str, Any]:
    site_holdout = _fold(site["validation"]["ensemble"], "2026H1")
    site_baseline = _fold(
        site["validation"]["baselines"]["positive_day_rate_28d"], "2026H1"
    )
    zone_holdout = _fold(zone["validation"]["blend"], "2026H1")
    zone_baseline = _fold(zone["baseline_90day_rate"], "2026H1")
    workload = robustness["dispatcher_workload"]
    end_to_end = robustness["end_to_end_localisation"]["by_fold"]["2026H1"]
    psi = robustness["temporal_drift"]["prediction_psi_vs_2024"]

    official_checks = [
        _minimum_check(
            "forecast_horizon_hours",
            site["horizon_hours"],
            24.0,
            rationale="Числовое требование раздела 9 исходного ТЗ.",
        ),
        _maximum_check(
            "tail_batch_prediction_seconds",
            prediction["total_prediction_seconds"],
            300.0,
            rationale=(
                "ТЗ ограничивает inference одного объекта 300 секундами; измерение "
                "охватывает весь batch из 30 объектов и 1 031 зоны."
            ),
        ),
    ]

    internal_checks = [
        _minimum_check(
            "site_pr_auc",
            site_holdout["pr_auc"],
            thresholds["site_pr_auc"],
            rationale="Основная ranking-метрика для несбалансированной proxy-цели.",
        ),
        _minimum_check(
            "site_pr_auc_gain_vs_28d_baseline",
            site_holdout["pr_auc"] - site_baseline["pr_auc"],
            thresholds["site_pr_auc_gain_vs_28d_baseline"],
            rationale="Требует заметного выигрыша над простым правилом по недавней истории.",
        ),
        _minimum_check(
            "site_f1",
            workload["f1"],
            thresholds["site_f1"],
            rationale="Минимальное сбалансированное качество рабочего решения.",
        ),
        _minimum_check(
            "site_precision",
            workload["precision"],
            thresholds["site_precision"],
            rationale="Ограничивает число лишних профилактических проверок по proxy-цели.",
        ),
        _minimum_check(
            "site_recall",
            workload["recall"],
            thresholds["site_recall"],
            rationale="Security-oriented минимум покрытия proxy-событий.",
        ),
        _minimum_check(
            "zone_hit_rate_at_5",
            zone_holdout["hit_rate_at_5"],
            thresholds["zone_hit_rate_at_5"],
            rationale="Хотя бы одна релевантная proxy-зона обычно должна входить в top-5.",
        ),
        _minimum_check(
            "zone_hit_rate_at_5_gain_vs_90d_baseline",
            zone_holdout["hit_rate_at_5"] - zone_baseline["hit_rate_at_5"],
            thresholds["zone_hit_rate_at_5_gain_vs_90d_baseline"],
            rationale="Требует полезного выигрыша локализации над 90-дневным правилом.",
        ),
        _minimum_check(
            "end_to_end_hit_at_5",
            end_to_end["end_to_end_hit_at_operating_threshold_zones_5"],
            thresholds["end_to_end_hit_at_5"],
            rationale="Измеряет полную цепочку выбора объекта и локализации зоны.",
        ),
        _maximum_check(
            "max_prediction_psi_vs_2024",
            max(float(psi["2025"]), float(psi["2026H1"])),
            thresholds["max_prediction_psi_vs_2024"],
            rationale="Консервативный ограничитель drift распределения score.",
        ),
        {
            "name": "no_forbidden_future_or_label_features",
            "actual": bool(robustness["feature_availability"]["passed"]),
            "operator": "==",
            "threshold": True,
            "passed": bool(robustness["feature_availability"]["passed"]),
            "rationale": "Метрика недействительна при утечке будущего в признаки.",
        },
    ]

    return {
        "generated_on": datetime.now(UTC).date().isoformat(),
        "evaluation_target": site["target_semantics"],
        "final_holdout": "2026-01-01 through 2026-06-30; report-only",
        "official_task_specification": {
            "source": "/Users/dinvinch/Downloads/ТЗ/8. ДЖКХ.pdf",
            "section": 9,
            "numeric_precision_recall_threshold": None,
            "quality_wording": (
                "Целевые Precision и Recall определяются на этапе проектирования "
                "исходя из качества предоставленных данных."
            ),
            "status": (
                "По предоставленному ТЗ нельзя заявить официальный числовой "
                "pass/fail-порог ML-качества."
            ),
        },
        "official_model_layer_checks": {
            "status": "pass" if all(row["passed"] for row in official_checks) else "fail",
            "checks": official_checks,
            "scope_note": (
                "Проверены горизонт model-layer и измеренная batch-serving latency. "
                "Это не сертифицирует весь веб-сервис, нагрузку 20 пользователей, LDAP, "
                "RBAC, PostgreSQL, доступность или аварийное восстановление."
            ),
        },
        "internal_proxy_ml_shadow_gate": {
            "status": "pass" if all(row["passed"] for row in internal_checks) else "fail",
            "checks": internal_checks,
            "bootstrap_uncertainty": uncertainty["internal_gate_uncertainty"],
            "policy_note": (
                "Это предложенные командой shadow-mode guardrails, а не пороги "
                "организаторов и не доказательство качества по подтверждённым вторжениям."
            ),
        },
        "confirmed_intrusion_production_gate": {
            "status": "not_evaluable",
            "blocking_conditions": [
                "В датасете нет подтверждённых диспетчером или человеком исходов.",
                (
                    "Обновлённый справочник связывает каналы с объектами диспетчеризации, "
                    "но не содержит проверенной физической критичности зон, маршрутов "
                    "реагирования и результатов осмотра."
                ),
                "Нет меток СКУД, разрешённых работ, видео и результатов расследования.",
                "В model package нет end-to-end load test на 20 одновременных пользователей.",
            ],
            "required_next_step": (
                "Запустить shadow mode, собирать обязательные outcomes, затем измерить "
                "confirmed precision/recall и false-dispatch rate до production-эскалации."
            ),
        },
    }


def render_markdown(report: dict[str, Any]) -> str:
    official = report["official_model_layer_checks"]
    internal = report["internal_proxy_ml_shadow_gate"]
    uncertainty = internal["bootstrap_uncertainty"]
    lines = [
        "# Приёмочная проверка Модели 3",
        "",
        f"Дата: {report['generated_on']}.",
        "",
        "## Что требует исходное ТЗ",
        "",
        "В разделе 9 исходного ТЗ нет числового минимума для Precision или Recall:",
        "значения должны быть определены на этапе проектирования с учётом качества данных.",
        "Поэтому официальный числовой ML-порог не придумывается.",
        "",
        f"Статус проверяемых требований model-layer: **{official['status'].upper()}**.",
        "",
        "| Проверка | Факт | Требование | Статус |",
        "|---|---:|---:|---|",
    ]
    for check in official["checks"]:
        status = "PASS" if check["passed"] else "FAIL"
        lines.append(
            f"| `{check['name']}` | {check['actual']:.6g} | "
            f"{check['operator']} {check['threshold']:.6g} | {status} |"
        )
    lines.extend(
        [
            "",
            official["scope_note"],
            "",
            "## Внутренний shadow-mode gate по proxy-цели",
            "",
            (
                f"Статус: **{internal['status'].upper()}**. Это внутренние инженерные "
                "ограничители команды, а не норматив организаторов."
            ),
            "",
            "| Проверка | Факт | Gate | Статус |",
            "|---|---:|---:|---|",
        ]
    )
    for check in internal["checks"]:
        status = "PASS" if check["passed"] else "FAIL"
        actual = check["actual"]
        threshold = check["threshold"]
        actual_text = str(actual) if isinstance(actual, bool) else f"{actual:.6f}"
        threshold_text = (
            str(threshold) if isinstance(threshold, bool) else f"{threshold:.6f}"
        )
        lines.append(
            f"| `{check['name']}` | {actual_text} | {check['operator']} "
            f"{threshold_text} | {status} |"
        )
    recall_uncertainty = uncertainty["checks"]["site_recall"]
    lines.extend(
        [
            "",
            (
                "Point-estimate gate пройден полностью, но нижняя 95%-граница recall "
                "ниже 0.80; доля bootstrap-выборок с прохождением равна "
                f"{recall_uncertainty['bootstrap_pass_probability']:.1%}. Поэтому "
                "текущий recall нельзя объявлять гарантированным SLA."
            ),
        ]
    )
    production = report["confirmed_intrusion_production_gate"]
    lines.extend(
        [
            "",
            "## Gate подтверждённых вторжений",
            "",
            f"Статус: **{production['status'].upper()}**.",
            "",
        ]
    )
    lines.extend(f"- {condition}" for condition in production["blocking_conditions"])
    lines.extend(["", production["required_next_step"], ""])
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    report = build_report(
        _read_json(args.site_metadata),
        _read_json(args.zone_metadata),
        _read_json(args.robustness_audit),
        _read_json(args.metric_uncertainty),
        _read_json(args.prediction_run),
        _read_thresholds(args.config),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    args.markdown_output.parent.mkdir(parents=True, exist_ok=True)
    args.markdown_output.write_text(render_markdown(report), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
