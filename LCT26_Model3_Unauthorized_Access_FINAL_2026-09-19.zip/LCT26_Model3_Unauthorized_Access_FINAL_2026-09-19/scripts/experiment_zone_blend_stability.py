"""Select a robust classifier/ranker blend on early zone OOF windows."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from lct26_access.metrics import zone_rank_metrics

SELECTION_FOLDS = ("2023", "2024")
CONFIRMATION_FOLD = "2025"
WEIGHTS = np.linspace(0.0, 1.0, 41)
MIN_CONFIRMATION_MRR_GAIN = 0.001
MAX_CONFIRMATION_HIT_LOSS = 0.001


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expanded-oof", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def metric_subset(report: dict[str, Any]) -> dict[str, float]:
    return {
        metric: float(report[metric])
        for metric in (
            "mrr",
            "hit_rate_at_1",
            "hit_rate_at_3",
            "hit_rate_at_5",
            "hit_rate_at_10",
        )
    }


def metrics(frame: pd.DataFrame, ranker_weight: float) -> dict[str, float]:
    score = (1.0 - ranker_weight) * frame["classifier_rank"] + ranker_weight * frame["ranker_rank"]
    return metric_subset(zone_rank_metrics(frame, score))


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    current_ranker_weight = float(metadata["blend_weights"]["ranker_rank"])
    frame = pd.read_parquet(args.expanded_oof)
    frame["target_date"] = pd.to_datetime(frame["target_date"])
    if (frame["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered zone-blend experiment")
    baseline = {
        fold: metrics(frame[frame["fold"] == fold], current_ranker_weight)
        for fold in (*SELECTION_FOLDS, CONFIRMATION_FOLD)
    }

    trials: list[dict[str, Any]] = []
    best_key: tuple[float, float, float, float] | None = None
    selected_weight: float | None = None
    for ranker_weight in WEIGHTS:
        fold_metrics = {
            fold: metrics(frame[frame["fold"] == fold], float(ranker_weight))
            for fold in SELECTION_FOLDS
        }
        mrr_deltas = {
            fold: fold_metrics[fold]["mrr"] - baseline[fold]["mrr"] for fold in SELECTION_FOLDS
        }
        hit3_deltas = {
            fold: fold_metrics[fold]["hit_rate_at_3"] - baseline[fold]["hit_rate_at_3"]
            for fold in SELECTION_FOLDS
        }
        key = (
            min(mrr_deltas.values()),
            min(hit3_deltas.values()),
            float(np.mean(list(mrr_deltas.values()))),
            -abs(float(ranker_weight) - current_ranker_weight),
        )
        trials.append(
            {
                "ranker_weight": float(ranker_weight),
                "classifier_weight": 1.0 - float(ranker_weight),
                "selection_metrics": fold_metrics,
                "selection_mrr_deltas": mrr_deltas,
                "selection_hit3_deltas": hit3_deltas,
            }
        )
        if best_key is None or key > best_key:
            best_key = key
            selected_weight = float(ranker_weight)
    if selected_weight is None:
        raise RuntimeError("No zone blend evaluated")

    confirmation_metrics = metrics(frame[frame["fold"] == CONFIRMATION_FOLD], selected_weight)
    confirmation_deltas = {
        metric: confirmation_metrics[metric] - baseline[CONFIRMATION_FOLD][metric]
        for metric in confirmation_metrics
    }
    selected_trial = next(trial for trial in trials if trial["ranker_weight"] == selected_weight)
    selection_eligible = min(selected_trial["selection_mrr_deltas"].values()) > 0.0
    accepted = (
        selection_eligible
        and confirmation_deltas["mrr"] >= MIN_CONFIRMATION_MRR_GAIN
        and confirmation_deltas["hit_rate_at_1"] >= 0.0
        and confirmation_deltas["hit_rate_at_3"] >= -MAX_CONFIRMATION_HIT_LOSS
        and confirmation_deltas["hit_rate_at_5"] >= -MAX_CONFIRMATION_HIT_LOSS
    )
    output = frame[frame["fold"] == CONFIRMATION_FOLD][
        [
            "target_date",
            "site_raw",
            "zone_key",
            "target",
            "classifier_rank",
            "ranker_rank",
            "blend_rank",
        ]
    ].copy()
    output["candidate_blend_rank"] = (1.0 - selected_weight) * output[
        "classifier_rank"
    ] + selected_weight * output["ranker_rank"]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    output.to_parquet(args.output_dir / "zone_blend_confirmation_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_019_zone_blend_stability",
        "priority": "P1.7",
        "protocol": {
            "selection_folds": list(SELECTION_FOLDS),
            "confirmation_fold": CONFIRMATION_FOLD,
            "holdout_2026h1_accessed": False,
            "ranker_weight_grid_step": 0.025,
            "objective": "maximise worst selection-fold MRR delta, then worst Hit@3 delta",
            "minimum_confirmation_mrr_gain": MIN_CONFIRMATION_MRR_GAIN,
            "maximum_confirmation_hit_loss": MAX_CONFIRMATION_HIT_LOSS,
        },
        "current_ranker_weight": current_ranker_weight,
        "baseline_metrics": baseline,
        "selected_ranker_weight": selected_weight,
        "selected_classifier_weight": 1.0 - selected_weight,
        "selected_trial": selected_trial,
        "selection_eligible": selection_eligible,
        "confirmation_metrics": confirmation_metrics,
        "confirmation_deltas": confirmation_deltas,
        "trials": trials,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Earlier-fold zone blend passes the predeclared confirmation gate."
                if accepted
                else "Earlier-fold zone blend does not pass the predeclared confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "trials"},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
