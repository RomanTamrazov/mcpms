"""Repeat full batch inference and report robust latency statistics."""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from lct26_access.inference import predict_sites, predict_zones


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--zone-features", type=Path, required=True)
    parser.add_argument("--site-model-dir", type=Path, required=True)
    parser.add_argument("--zone-model-dir", type=Path, required=True)
    parser.add_argument("--as-of", type=pd.Timestamp)
    parser.add_argument("--threshold-mode", default="operational_recall_80")
    parser.add_argument("--top-zones", type=int, default=5)
    parser.add_argument("--warmup", type=int, default=1)
    parser.add_argument("--repetitions", type=int, default=7)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def _digest(frame: pd.DataFrame) -> str:
    values = pd.util.hash_pandas_object(frame, index=True).to_numpy().tobytes()
    return hashlib.sha256(values).hexdigest()


def _stats(values: list[float]) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    return {
        "mean_seconds": float(array.mean()),
        "median_seconds": float(np.median(array)),
        "p95_seconds": float(np.quantile(array, 0.95)),
        "min_seconds": float(array.min()),
        "max_seconds": float(array.max()),
    }


def _run(args: argparse.Namespace) -> dict[str, Any]:
    started = time.perf_counter()
    site, site_run = predict_sites(
        args.site_features,
        args.context_features,
        args.site_model_dir,
        as_of=args.as_of,
        threshold_mode=args.threshold_mode,
    )
    zone, zone_run = predict_zones(
        args.zone_features,
        args.zone_model_dir,
        site,
        as_of=pd.Timestamp(site_run["as_of_date"]),
        top_zones=args.top_zones,
    )
    return {
        "total_seconds": float(time.perf_counter() - started),
        "site_seconds": float(site_run["site_prediction_seconds"]),
        "zone_seconds": float(zone_run["zone_prediction_seconds"]),
        "site_rows": int(site.shape[0]),
        "site_alert_rows": int(site["alert"].sum()),
        "zone_rows": int(zone.shape[0]),
        "site_mapping_nonempty": int(site.get("site_object_ids", pd.Series(dtype=str)).ne("").sum()),
        "zone_mapping_nonempty": int(zone.get("zone_object_ids", pd.Series(dtype=str)).ne("").sum()),
        "site_digest": _digest(site),
        "zone_digest": _digest(zone),
    }


def main() -> None:
    args = parse_args()
    if args.warmup < 0 or args.repetitions < 3:
        raise ValueError("Use non-negative warmup and at least 3 measured repetitions")
    for _ in range(args.warmup):
        _run(args)
    runs = [_run(args) for _ in range(args.repetitions)]
    site_digests = {run["site_digest"] for run in runs}
    zone_digests = {run["zone_digest"] for run in runs}
    report = {
        "protocol": {
            "warmup_runs": args.warmup,
            "measured_repetitions": args.repetitions,
            "scope": "full 30-site and 1,031-zone batch, including feature reads and model loads",
        },
        "latency": {
            "total": _stats([run["total_seconds"] for run in runs]),
            "site": _stats([run["site_seconds"] for run in runs]),
            "zone": _stats([run["zone_seconds"] for run in runs]),
        },
        "output": {
            "site_rows": runs[0]["site_rows"],
            "site_alert_rows": runs[0]["site_alert_rows"],
            "zone_rows": runs[0]["zone_rows"],
            "site_rows_with_object_mapping": runs[0]["site_mapping_nonempty"],
            "zone_rows_with_object_mapping": runs[0]["zone_mapping_nonempty"],
            "deterministic_across_runs": len(site_digests) == 1 and len(zone_digests) == 1,
        },
        "runs": runs,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
