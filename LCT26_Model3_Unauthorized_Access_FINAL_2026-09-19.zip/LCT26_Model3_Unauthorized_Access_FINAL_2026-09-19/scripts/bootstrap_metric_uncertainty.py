"""Calendar-day block bootstrap for the final Model-3 holdout metrics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml
from sklearn.metrics import (
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

METRIC_NAMES = (
    "site_pr_auc",
    "site_roc_auc",
    "site_f1",
    "site_precision",
    "site_recall",
    "zone_hit_rate_at_5",
    "end_to_end_hit_at_5",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-oof", type=Path, required=True)
    parser.add_argument("--site-metadata", type=Path, required=True)
    parser.add_argument("--zone-oof", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=1_000)
    parser.add_argument("--seed", type=int, default=2603)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def _metric_vector(
    target: np.ndarray,
    probability: np.ndarray,
    threshold: float,
    zone_hit: np.ndarray,
    end_to_end_hit: np.ndarray,
) -> np.ndarray:
    predicted = probability >= threshold
    return np.asarray(
        [
            average_precision_score(target, probability),
            roc_auc_score(target, probability),
            f1_score(target, predicted),
            precision_score(target, predicted, zero_division=0),
            recall_score(target, predicted, zero_division=0),
            zone_hit.mean(),
            end_to_end_hit.mean(),
        ],
        dtype=float,
    )


def _gate_thresholds(config: dict[str, Any]) -> dict[str, float]:
    gate = config["internal_shadow_acceptance"]
    return {
        "site_pr_auc": float(gate["min_site_pr_auc"]),
        "site_f1": float(gate["min_site_f1"]),
        "site_precision": float(gate["min_site_precision"]),
        "site_recall": float(gate["min_site_recall"]),
        "zone_hit_rate_at_5": float(gate["min_zone_hit_rate_at_5"]),
        "end_to_end_hit_at_5": float(gate["min_end_to_end_hit_at_5"]),
    }


def main() -> None:
    args = parse_args()
    if args.draws < 100:
        raise ValueError("--draws must be at least 100")

    metadata = json.loads(args.site_metadata.read_text(encoding="utf-8"))
    config = yaml.safe_load(args.config.read_text(encoding="utf-8"))
    threshold_mode = metadata["default_threshold_mode"]
    threshold = float(
        metadata["decision_thresholds_from_2024_2025"][threshold_mode]
    )

    site = pd.read_parquet(args.site_oof)
    site = site[site["fold"] == "2026H1"].copy().reset_index(drop=True)
    site["target_date"] = pd.to_datetime(site["target_date"])
    zone = pd.read_parquet(args.zone_oof)
    zone["target_date"] = pd.to_datetime(zone["target_date"])
    zone = zone[zone["target_date"] >= pd.Timestamp("2026-01-01")].copy()
    zone = zone.sort_values(
        ["target_date", "site_raw", "blend_rank"], ascending=[True, True, False]
    )
    zone["zone_rank"] = zone.groupby(["target_date", "site_raw"]).cumcount() + 1
    positive = zone[zone["target"] == 1]
    groups = (
        positive.groupby(["target_date", "site_raw"], sort=False)["zone_rank"]
        .min()
        .rename("first_positive_zone_rank")
        .reset_index()
    )
    groups = groups.merge(
        site[["target_date", "site_raw", "ensemble_probability"]],
        on=["target_date", "site_raw"],
        validate="one_to_one",
    )
    groups["zone_hit_at_5"] = groups["first_positive_zone_rank"] <= 5
    groups["end_to_end_hit_at_5"] = (
        groups["zone_hit_at_5"] & (groups["ensemble_probability"] >= threshold)
    )
    groups = groups.reset_index(drop=True)

    dates = np.sort(site["target_date"].unique())
    site_indices = {
        key: values.index.to_numpy()
        for key, values in site.groupby("target_date", sort=False)
    }
    group_indices = {
        key: values.index.to_numpy()
        for key, values in groups.groupby("target_date", sort=False)
    }
    if not set(group_indices).issubset(set(dates)):
        raise ValueError("A positive zone group falls outside the site holdout dates")

    target = site["target"].to_numpy(dtype=np.int8)
    probability = site["ensemble_probability"].to_numpy(dtype=float)
    zone_hit = groups["zone_hit_at_5"].to_numpy(dtype=bool)
    end_to_end_hit = groups["end_to_end_hit_at_5"].to_numpy(dtype=bool)
    point = _metric_vector(target, probability, threshold, zone_hit, end_to_end_hit)

    rng = np.random.default_rng(args.seed)
    samples = np.empty((args.draws, len(METRIC_NAMES)), dtype=float)
    for draw in range(args.draws):
        sampled_dates = rng.choice(dates, size=dates.size, replace=True)
        selected_site = np.concatenate([site_indices[value] for value in sampled_dates])
        selected_groups = np.concatenate(
            [
                group_indices.get(value, np.empty(0, dtype=np.int64))
                for value in sampled_dates
            ]
        )
        samples[draw] = _metric_vector(
            target[selected_site],
            probability[selected_site],
            threshold,
            zone_hit[selected_groups],
            end_to_end_hit[selected_groups],
        )

    intervals = {
        name: {
            "point_estimate": float(point[index]),
            "lower_95": float(np.quantile(samples[:, index], 0.025)),
            "bootstrap_median": float(np.median(samples[:, index])),
            "upper_95": float(np.quantile(samples[:, index], 0.975)),
        }
        for index, name in enumerate(METRIC_NAMES)
    }
    gate_thresholds = _gate_thresholds(config)
    gate_checks = {
        name: {
            "threshold": minimum,
            "point_estimate_passed": bool(intervals[name]["point_estimate"] >= minimum),
            "lower_95_passed": bool(intervals[name]["lower_95"] >= minimum),
            "bootstrap_pass_probability": float(
                (samples[:, METRIC_NAMES.index(name)] >= minimum).mean()
            ),
        }
        for name, minimum in gate_thresholds.items()
    }
    report = {
        "protocol": {
            "fold": "2026H1",
            "resampling_unit": "calendar day",
            "draws": args.draws,
            "seed": args.seed,
            "confidence_interval": "2.5th and 97.5th bootstrap percentiles",
            "selection_policy": "report-only; no model or threshold tuning",
        },
        "threshold_mode": threshold_mode,
        "threshold": threshold,
        "intervals": intervals,
        "internal_gate_uncertainty": {
            "checks": gate_checks,
            "all_point_estimates_pass": all(
                row["point_estimate_passed"] for row in gate_checks.values()
            ),
            "all_lower_95_bounds_pass": all(
                row["lower_95_passed"] for row in gate_checks.values()
            ),
            "interpretation": (
                "A point-estimate pass is not an SLA guarantee. Calendar-day block "
                "bootstrap reflects sampling uncertainty inside this single holdout period, "
                "not every possible future drift scenario."
            ),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
