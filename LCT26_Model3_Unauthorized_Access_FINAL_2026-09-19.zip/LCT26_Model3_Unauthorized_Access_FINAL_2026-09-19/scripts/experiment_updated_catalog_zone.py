"""Development-only zone-ranking ablation for the updated object catalog."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import polars as pl
from lightgbm import LGBMClassifier, LGBMRanker, early_stopping, log_evaluation

from lct26_access.features import augment_zone_model_frame
from lct26_access.metrics import zone_rank_metrics
from lct26_access.models import (
    LGB_ZONE_CLASSIFIER_PARAMS,
    LGB_ZONE_RANKER_PARAMS,
    ZONE_CATEGORICAL,
    ZONE_EXCLUDE,
    encode_for_lightgbm,
    feature_columns,
    fit_category_maps,
    group_sizes,
)

MATERIAL_HIT3_GAIN = 0.003


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zone-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--champion-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def _rank_percentile(frame: pd.DataFrame, score: np.ndarray) -> pd.Series:
    temporary = frame[["target_date", "site_raw"]].copy()
    temporary["score"] = score
    return temporary.groupby(["target_date", "site_raw"])["score"].rank(
        method="average", pct=True
    )


def _select_weight(
    frame: pd.DataFrame,
    classifier_rank: pd.Series,
    ranker_rank: pd.Series,
) -> tuple[float, dict[str, Any]]:
    best_key: tuple[float, float, float] | None = None
    best_weight = 0.0
    best_metrics: dict[str, Any] | None = None
    for weight in np.linspace(0.0, 1.0, 21):
        score = (1 - weight) * classifier_rank + weight * ranker_rank
        metrics = zone_rank_metrics(frame, score)
        key = (
            float(metrics["hit_rate_at_3"]),
            float(metrics["hit_rate_at_5"]),
            float(metrics["mrr"]),
        )
        if best_key is None or key > best_key:
            best_key = key
            best_weight = float(weight)
            best_metrics = metrics
    if best_metrics is None:
        raise RuntimeError("No blend weight evaluated")
    return best_weight, best_metrics


def _eligible(
    frame: pd.DataFrame,
    requested: list[str],
) -> list[str]:
    return [
        column
        for column in requested
        if column in frame.columns and frame[column].nunique(dropna=False) > 1
    ]


def _fit_variant(
    frame: pd.DataFrame,
    requested: list[str],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    start = pd.Timestamp("2025-01-01")
    end = pd.Timestamp("2026-01-01")
    train = frame["target_date"] < start
    valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
    features = _eligible(frame.loc[train], requested)
    categorical = [
        column for column in ZONE_CATEGORICAL if column in features
    ]
    maps = fit_category_maps(frame.loc[train], categorical)
    train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
    valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
    target = frame["target"].astype(int)
    train_frame = frame.loc[train]
    valid_frame = frame.loc[valid]

    classifier = LGBMClassifier(
        **LGB_ZONE_CLASSIFIER_PARAMS, n_estimators=1_600
    )
    started = time.monotonic()
    classifier.fit(
        train_matrix,
        target.loc[train],
        categorical_feature=categorical,
        eval_X=valid_matrix,
        eval_y=target.loc[valid],
        eval_metric="average_precision",
        callbacks=[early_stopping(100, verbose=False), log_evaluation(0)],
    )
    classifier_seconds = time.monotonic() - started
    classifier_score = classifier.predict_proba(valid_matrix)[:, 1]

    ranker = LGBMRanker(**LGB_ZONE_RANKER_PARAMS, n_estimators=1_600)
    started = time.monotonic()
    ranker.fit(
        train_matrix,
        target.loc[train],
        group=group_sizes(train_frame),
        categorical_feature=categorical,
        eval_X=valid_matrix,
        eval_y=target.loc[valid],
        eval_group=[group_sizes(valid_frame)],
        eval_at=[1, 3, 5, 10],
        callbacks=[early_stopping(100, verbose=False), log_evaluation(0)],
    )
    ranker_seconds = time.monotonic() - started
    ranker_score = ranker.predict(valid_matrix)

    output = valid_frame[
        ["target_date", "site_raw", "zone_key", "target"]
    ].copy()
    output["classifier_score"] = classifier_score
    output["ranker_score"] = ranker_score
    output["classifier_rank"] = _rank_percentile(
        valid_frame, classifier_score
    ).values
    output["ranker_rank"] = _rank_percentile(valid_frame, ranker_score).values
    weight, metrics = _select_weight(
        output, output["classifier_rank"], output["ranker_rank"]
    )
    output["blend_rank"] = (
        (1 - weight) * output["classifier_rank"]
        + weight * output["ranker_rank"]
    )
    return output, {
        "features": len(features),
        "object_features": sum(
            "object" in feature or "parent" in feature for feature in features
        ),
        "classifier_iterations": int(classifier.best_iteration_),
        "ranker_iterations": int(ranker.best_iteration_),
        "classifier_seconds": round(classifier_seconds, 3),
        "ranker_seconds": round(ranker_seconds, 3),
        "ranker_weight": weight,
        "metrics": metrics,
    }


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    frame = (
        pl.scan_parquet(args.zone_features)
        .with_columns(
            pl.col("target")
            .max()
            .over(["site_raw", "target_date"])
            .alias("site_target")
        )
        .filter(
            (pl.col("site_target") == 1)
            & (pl.col("target_date") < pl.date(2026, 1, 1))
        )
        .collect()
        .to_pandas()
    )
    frame = augment_zone_model_frame(frame).sort_values(
        ["target_date", "site_raw", "zone_key"]
    ).reset_index(drop=True)
    frame["target_date"] = pd.to_datetime(frame["target_date"])
    legacy_requested = list(metadata["features"])
    hierarchy_requested = feature_columns(frame, exclude=ZONE_EXCLUDE)
    legacy_oof, legacy_report = _fit_variant(frame, legacy_requested)
    hierarchy_oof, hierarchy_report = _fit_variant(
        frame, hierarchy_requested
    )
    champion = pd.read_parquet(args.champion_oof)
    champion["target_date"] = pd.to_datetime(champion["target_date"])
    champion = champion[
        (champion["target_date"] >= pd.Timestamp("2025-01-01"))
        & (champion["target_date"] < pd.Timestamp("2026-01-01"))
    ]
    champion_metrics = zone_rank_metrics(champion, champion["blend_rank"])

    key = ["target_date", "site_raw", "zone_key", "target"]
    comparison = legacy_oof[key + ["blend_rank"]].rename(
        columns={"blend_rank": "legacy_strict_rank"}
    ).merge(
        hierarchy_oof[key + ["blend_rank"]].rename(
            columns={"blend_rank": "hierarchy_rank"}
        ),
        on=key,
        validate="one_to_one",
    )
    comparison.to_parquet(
        output_dir / "updated_catalog_zone_development_oof.parquet",
        index=False,
    )
    legacy_metrics = legacy_report["metrics"]
    hierarchy_metrics = hierarchy_report["metrics"]
    deltas = {
        metric: float(hierarchy_metrics[metric] - legacy_metrics[metric])
        for metric in (
            "mrr",
            "hit_rate_at_1",
            "hit_rate_at_3",
            "hit_rate_at_5",
            "hit_rate_at_10",
        )
    }
    accepted = (
        deltas["hit_rate_at_3"] >= MATERIAL_HIT3_GAIN
        and deltas["hit_rate_at_5"] >= -0.002
        and deltas["mrr"] >= -0.002
    )
    report = {
        "protocol": {
            "selection_fold": "2025 only",
            "holdout_accessed": False,
            "category_maps": "fit on rows before 2025 only",
            "feature_eligibility": "evaluated on rows before 2025 only",
            "material_hit_at_3_gain": MATERIAL_HIT3_GAIN,
        },
        "stored_champion_2025": champion_metrics,
        "legacy_feature_set_strict": legacy_report,
        "object_hierarchy_candidate": hierarchy_report,
        "deltas_hierarchy_minus_legacy": deltas,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Object hierarchy passes the development localisation gate."
                if accepted
                else "Object hierarchy does not pass the development localisation gate."
            ),
        },
    }
    (output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(deltas, ensure_ascii=False, indent=2))
    print(json.dumps(report["decision"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
