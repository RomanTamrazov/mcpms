"""Cross-fitted lightweight logistic stacker for the three site components.

Regularisation and blend weight are selected with 2022 OOF as meta-training and
2023 as meta-validation.  The frozen recipe is then evaluated prequentially on
2024 and 2025, always fitting the stacker only on earlier OOF rows.  2026H1 is
never loaded or scored.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from lct26_access.features import augment_site_model_frame

COMPONENTS = ("lgb_base", "lgb_weekly_tuned", "lgb_context")
SELECTION_TRAIN_FOLD = "2022"
SELECTION_VALID_FOLD = "2023"
CONFIRMATION_FOLDS = ("2024", "2025")
C_GRID = (0.01, 0.03, 0.1, 0.3, 1.0, 3.0)
BLEND_WEIGHTS = np.linspace(0.0, 0.5, 21)
MIN_CONFIRMATION_WORST_GAIN = 0.0005
MAX_CONFIRMATION_BRIER_INCREASE = 0.0001


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--expanded-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def logit(values: pd.Series) -> np.ndarray:
    clipped = np.clip(values.to_numpy(dtype=float), 1e-5, 1 - 1e-5)
    return np.log(clipped / (1.0 - clipped))


def make_meta_frame(oof: pd.DataFrame, site_features: Path) -> pd.DataFrame:
    calendar = augment_site_model_frame(site_features, weekly=True)
    calendar = calendar[calendar["target"].notna()].copy()
    calendar["target_date"] = pd.to_datetime(calendar["target_date"])
    columns = [
        "site_raw",
        "target_date",
        "target_dow",
        "target_month",
        "target_weekend",
        "target_doy_sin",
        "target_doy_cos",
        "target_holiday",
        "target_workday",
        "positive_day_rate28",
        "positive_day_rate365",
        "same_target_weekday_rate_13w",
        "same_target_weekday_rate_52w",
    ]
    frame = oof.merge(
        calendar[columns],
        on=["site_raw", "target_date"],
        validate="many_to_one",
    )
    for component in COMPONENTS:
        frame[f"logit_{component}"] = logit(frame[component])
    component_matrix = frame.loc[:, COMPONENTS].to_numpy(dtype=float)
    frame["component_mean"] = component_matrix.mean(axis=1)
    frame["component_std"] = component_matrix.std(axis=1)
    frame["component_range"] = component_matrix.max(axis=1) - component_matrix.min(axis=1)
    return frame


def build_model(c_value: float) -> Any:
    categorical = ["site_raw", "target_dow", "target_month"]
    numeric = [
        *COMPONENTS,
        *(f"logit_{component}" for component in COMPONENTS),
        "component_mean",
        "component_std",
        "component_range",
        "target_weekend",
        "target_doy_sin",
        "target_doy_cos",
        "target_holiday",
        "target_workday",
        "positive_day_rate28",
        "positive_day_rate365",
        "same_target_weekday_rate_13w",
        "same_target_weekday_rate_52w",
    ]
    transform = ColumnTransformer(
        [
            (
                "categorical",
                OneHotEncoder(handle_unknown="ignore"),
                categorical,
            ),
            ("numeric", StandardScaler(with_mean=False), numeric),
        ]
    )
    return make_pipeline(
        transform,
        LogisticRegression(C=c_value, max_iter=2_000, solver="lbfgs"),
    )


def fit_predict(
    frame: pd.DataFrame,
    *,
    train_folds: tuple[str, ...],
    valid_fold: str,
    c_value: float,
) -> np.ndarray:
    train = frame["fold"].isin(train_folds)
    valid = frame["fold"] == valid_fold
    model = build_model(c_value)
    model.fit(frame.loc[train], frame.loc[train, "target"].astype("int8"))
    return model.predict_proba(frame.loc[valid])[:, 1]


def metrics(target: pd.Series, probability: np.ndarray) -> dict[str, float]:
    return {
        "pr_auc": float(average_precision_score(target, probability)),
        "brier": float(brier_score_loss(target, probability)),
    }


def main() -> None:
    args = parse_args()
    oof = pd.read_parquet(args.expanded_oof)
    oof["target_date"] = pd.to_datetime(oof["target_date"])
    if (oof["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered stacker experiment")
    frame = make_meta_frame(oof, args.site_features)
    baseline_metrics = {
        fold: metrics(
            frame.loc[frame["fold"] == fold, "target"],
            frame.loc[frame["fold"] == fold, "ensemble_probability"].to_numpy(),
        )
        for fold in (SELECTION_VALID_FOLD, *CONFIRMATION_FOLDS)
    }

    c_trials: list[dict[str, Any]] = []
    best_c_key: tuple[float, float] | None = None
    selected_c: float | None = None
    selected_validation_probability: np.ndarray | None = None
    selection_target = frame.loc[frame["fold"] == SELECTION_VALID_FOLD, "target"]
    for c_value in C_GRID:
        probability = fit_predict(
            frame,
            train_folds=(SELECTION_TRAIN_FOLD,),
            valid_fold=SELECTION_VALID_FOLD,
            c_value=c_value,
        )
        report = metrics(selection_target, probability)
        c_trials.append({"c": c_value, "metrics": report})
        key = (report["pr_auc"], -report["brier"])
        if best_c_key is None or key > best_c_key:
            best_c_key = key
            selected_c = c_value
            selected_validation_probability = probability
    if selected_c is None or selected_validation_probability is None:
        raise RuntimeError("No stacker regularisation candidate evaluated")

    selection_baseline = frame.loc[
        frame["fold"] == SELECTION_VALID_FOLD, "ensemble_probability"
    ].to_numpy()
    weight_trials: list[dict[str, Any]] = []
    best_weight_key: tuple[float, float, float] | None = None
    selected_weight = 0.0
    for weight in BLEND_WEIGHTS:
        blended = (1.0 - weight) * selection_baseline + weight * selected_validation_probability
        report = metrics(selection_target, blended)
        key = (report["pr_auc"], -report["brier"], -float(weight))
        weight_trials.append({"stacker_weight": float(weight), "metrics": report})
        if best_weight_key is None or key > best_weight_key:
            best_weight_key = key
            selected_weight = float(weight)

    confirmation_parts: list[pd.DataFrame] = []
    confirmation_metrics: dict[str, dict[str, float]] = {}
    for fold in CONFIRMATION_FOLDS:
        train_folds = tuple(str(year) for year in range(2022, int(fold)))
        stacker_probability = fit_predict(
            frame,
            train_folds=train_folds,
            valid_fold=fold,
            c_value=selected_c,
        )
        valid = frame["fold"] == fold
        baseline_probability = frame.loc[valid, "ensemble_probability"].to_numpy()
        candidate_probability = (
            1.0 - selected_weight
        ) * baseline_probability + selected_weight * stacker_probability
        confirmation_metrics[fold] = metrics(frame.loc[valid, "target"], candidate_probability)
        output = frame.loc[
            valid,
            ["site_raw", "target_date", "target", "fold", "ensemble_probability"],
        ].copy()
        output["stacker_probability"] = stacker_probability
        output["candidate_probability"] = candidate_probability
        confirmation_parts.append(output)

    confirmation_deltas = {
        fold: {
            metric: confirmation_metrics[fold][metric] - baseline_metrics[fold][metric]
            for metric in ("pr_auc", "brier")
        }
        for fold in CONFIRMATION_FOLDS
    }
    selection_gain = (
        next(
            trial["metrics"]["pr_auc"]
            for trial in weight_trials
            if trial["stacker_weight"] == selected_weight
        )
        - baseline_metrics[SELECTION_VALID_FOLD]["pr_auc"]
    )
    accepted = (
        selected_weight > 0.0
        and selection_gain > 0.0
        and min(confirmation_deltas[fold]["pr_auc"] for fold in CONFIRMATION_FOLDS)
        >= MIN_CONFIRMATION_WORST_GAIN
        and all(
            confirmation_deltas[fold]["brier"] <= MAX_CONFIRMATION_BRIER_INCREASE
            for fold in CONFIRMATION_FOLDS
        )
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.concat(confirmation_parts, ignore_index=True).to_parquet(
        args.output_dir / "stacker_confirmation_oof.parquet", index=False
    )
    report = {
        "experiment_id": "EXP_022_cross_fitted_logistic_stacker",
        "priority": "P1 stacker",
        "protocol": {
            "regularisation_and_weight_selection_train_fold": SELECTION_TRAIN_FOLD,
            "regularisation_and_weight_selection_valid_fold": SELECTION_VALID_FOLD,
            "confirmation_folds": list(CONFIRMATION_FOLDS),
            "confirmation_training": "strictly earlier OOF folds only",
            "holdout_2026h1_accessed": False,
            "minimum_confirmation_worst_pr_auc_gain": MIN_CONFIRMATION_WORST_GAIN,
            "maximum_confirmation_brier_increase": MAX_CONFIRMATION_BRIER_INCREASE,
        },
        "baseline_metrics": baseline_metrics,
        "c_trials": c_trials,
        "selected_c": selected_c,
        "weight_trials": weight_trials,
        "selected_stacker_weight": selected_weight,
        "selection_pr_auc_gain": selection_gain,
        "confirmation_metrics": confirmation_metrics,
        "confirmation_deltas": confirmation_deltas,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Cross-fitted stacker passes the predeclared confirmation gate."
                if accepted
                else "Cross-fitted stacker does not pass the predeclared confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
