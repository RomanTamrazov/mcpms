"""Generate a feature-level temporal leakage audit for frozen champions."""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

from lct26_access.causality import audit_feature_manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-metadata", type=Path, required=True)
    parser.add_argument("--zone-metadata", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    site = json.loads(args.site_metadata.read_text(encoding="utf-8"))
    zone = json.loads(args.zone_metadata.read_text(encoding="utf-8"))

    membership: dict[tuple[str, str], list[str]] = defaultdict(list)
    for variant, specification in site["variants"].items():
        for feature in specification["features"]:
            membership[("site", feature)].append(variant)
    for feature in zone["features"]:
        membership[("zone", feature)].append("zone_classifier+ranker")

    rows: list[dict[str, object]] = []
    for level in ("site", "zone"):
        features = [feature for candidate_level, feature in membership if candidate_level == level]
        for result in audit_feature_manifest(features, model_level=level):
            row: dict[str, object] = {
                "model_level": level,
                "variants": membership[(level, result.feature)],
                **result.to_dict(),
            }
            rows.append(row)

    status_counts = {
        status: sum(row["causal_status"] == status for row in rows)
        for status in ("pass", "review", "fail")
    }
    failed = [row["feature"] for row in rows if row["causal_status"] == "fail"]
    report = {
        "experiment_id": "EXP_007_feature_causality_audit",
        "forecast_contract": {
            "prediction_timestamp": "after end-of-day D ingestion is complete",
            "prediction_horizon": "calendar day D+1",
            "maximum_observation_timestamp": "end of D",
            "calendar_exception": "deterministic D+1 calendar attributes are known in advance",
        },
        "site_model_version": site["model_version"],
        "zone_model_version": zone["model_version"],
        "unique_feature_rows": len(rows),
        "status_counts": status_counts,
        "automatic_gate_passed": not failed,
        "failed_features": failed,
        "review_note": (
            "Review rows are current catalog-snapshot attributes. They are available for present "
            "inference, but historical availability cannot be proved without versioned catalogs."
        ),
        "rows": rows,
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = args.output_dir / "feature_causality_audit.json"
    json_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    csv_path = args.output_dir / "feature_causality_audit.csv"
    fieldnames = [
        "model_level",
        "variants",
        "feature",
        "source_table",
        "granularity",
        "aggregation_window",
        "shift",
        "prediction_timestamp",
        "max_allowed_timestamp",
        "actual_max_source_timestamp",
        "availability_at_prediction",
        "causal_status",
        "reason",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            serialized = dict(row)
            serialized["variants"] = ",".join(serialized["variants"])
            writer.writerow({name: serialized[name] for name in fieldnames})

    markdown = [
        "# EXP_007 — feature-level causality audit",
        "",
        "Forecast cutoff: after ingestion of calendar day D; target: calendar day D+1.",
        "",
        f"- Unique manifest features: {len(rows)}",
        f"- Pass: {status_counts['pass']}",
        f"- Review: {status_counts['review']}",
        f"- Fail: {status_counts['fail']}",
        f"- Automatic gate: {'PASS' if not failed else 'FAIL'}",
        "",
        (
            "`review` is not a hidden pass: it records unversioned static catalog attributes. "
            "They are usable now, but their historical state cannot be reconstructed from the archive."
        ),
        "",
        "Full row-level lineage is in `feature_causality_audit.csv` and JSON.",
    ]
    (args.output_dir / "FEATURE_CAUSALITY_AUDIT.md").write_text(
        "\n".join(markdown) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {key: report[key] for key in report if key != "rows"}, ensure_ascii=False, indent=2
        )
    )
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
