"""Train conditional classifier + LambdaRank models for zone localisation."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import polars as pl
from lightgbm import LGBMClassifier, LGBMRanker, early_stopping, log_evaluation

from lct26_access.features import augment_zone_model_frame
from lct26_access.metrics import zone_rank_metrics
from lct26_access.models import (
    LGB_ZONE_CLASSIFIER_PARAMS,
    LGB_ZONE_RANKER_PARAMS,
    ZONE_CATEGORICAL,
    ZONE_EXCLUDE,
    encode_for_lightgbm,
    feature_columns,
    fit_category_maps,
    group_sizes,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zone-features", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--feature-manifest",
        type=Path,
        help="Optional prior zone metadata whose feature schema is frozen.",
    )
    parser.add_argument(
        "--model-version",
        default="model3-zone-v1.0-classifier-lambdarank",
    )
    return parser.parse_args()


def eligible_features(
    frame: pd.DataFrame,
    *,
    requested: list[str] | None = None,
) -> list[str]:
    candidates = (
        feature_columns(frame, exclude=ZONE_EXCLUDE)
        if requested is None
        else [column for column in requested if column in frame.columns]
    )
    return [
        column
        for column in candidates
        if frame[column].nunique(dropna=False) > 1
    ]


def rank_percentile(frame: pd.DataFrame, score: pd.Series) -> pd.Series:
    temporary = frame[["target_date", "site_raw"]].copy()
    temporary["score"] = np.asarray(score)
    return temporary.groupby(["target_date", "site_raw"])["score"].rank(
        method="average", pct=True
    )


def select_ranker_weight(
    frame: pd.DataFrame,
    classifier_rank: pd.Series,
    ranker_rank: pd.Series,
) -> tuple[float, dict[str, object]]:
    """Select the rank blend on 2025 only; 2026 remains an untouched holdout."""

    best_key: tuple[float, float, float] | None = None
    best_weight = 0.0
    best_report: dict[str, float | int] | None = None
    for ranker_weight in np.linspace(0.0, 1.0, 21):
        score = (1.0 - ranker_weight) * classifier_rank + ranker_weight * ranker_rank
        report = zone_rank_metrics(frame, score)
        key = (
            float(report["hit_rate_at_3"]),
            float(report["hit_rate_at_5"]),
            float(report["mrr"]),
        )
        if best_key is None or key > best_key:
            best_key = key
            best_weight = float(ranker_weight)
            best_report = report
    if best_report is None:
        raise RuntimeError("No zone blend candidate was evaluated")
    return best_weight, {
        "strategy": "maximise 2025 hit-rate@3, then hit-rate@5 and MRR",
        "grid_step": 0.05,
        "selection_fold": "2025",
        "selected_fold_metrics": best_report,
    }


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    requested_features: list[str] | None = None
    if args.feature_manifest is not None:
        manifest = json.loads(
            args.feature_manifest.read_text(encoding="utf-8")
        )
        requested_features = list(manifest["features"])
    frame = (
        pl.scan_parquet(args.zone_features)
        .with_columns(pl.col("target").max().over(["site_raw", "target_date"]).alias("site_target"))
        .filter(pl.col("site_target") == 1)
        .collect()
        .to_pandas()
    )
    frame = augment_zone_model_frame(frame).sort_values(
        ["target_date", "site_raw", "zone_key"]
    ).reset_index(drop=True)
    features = eligible_features(frame, requested=requested_features)
    categorical_columns = [
        column for column in ZONE_CATEGORICAL if column in features
    ]
    category_maps = fit_category_maps(frame, categorical_columns)
    matrix = encode_for_lightgbm(frame, features, category_maps)
    target = frame["target"].astype(int)
    reports: dict[str, list[dict[str, object]]] = {"classifier": [], "ranker": [], "blend": []}
    baseline_reports: list[dict[str, object]] = []
    oof_parts: list[pd.DataFrame] = []
    classifier_iterations: int | None = None
    ranker_iterations: int | None = None
    selected_ranker_weight: float | None = None
    blend_selection: dict[str, object] | None = None

    for fold, start, end in (
        ("2025", "2025-01-01", "2026-01-01"),
        ("2026H1", "2026-01-01", "2026-07-01"),
    ):
        train = frame["target_date"] < pd.Timestamp(start)
        valid = (frame["target_date"] >= pd.Timestamp(start)) & (
            frame["target_date"] < pd.Timestamp(end)
        )
        fold_features = eligible_features(
            frame.loc[train], requested=requested_features
        )
        fold_categorical = [
            column for column in ZONE_CATEGORICAL if column in fold_features
        ]
        fold_maps = fit_category_maps(frame.loc[train], fold_categorical)
        train_matrix = encode_for_lightgbm(
            frame.loc[train], fold_features, fold_maps
        )
        valid_matrix = encode_for_lightgbm(
            frame.loc[valid], fold_features, fold_maps
        )
        baseline_report = zone_rank_metrics(
            frame.loc[valid], frame.loc[valid, "zone_positive_rate90"]
        )
        baseline_report["fold"] = fold
        baseline_reports.append(baseline_report)
        is_holdout = fold == "2026H1"
        classifier_n_estimators = classifier_iterations if is_holdout else 1_600
        if classifier_n_estimators is None:
            raise RuntimeError("Classifier iteration count must be selected before holdout")
        classifier = LGBMClassifier(
            **LGB_ZONE_CLASSIFIER_PARAMS, n_estimators=classifier_n_estimators
        )
        started = time.monotonic()
        if is_holdout:
            classifier.fit(
                train_matrix,
                target.loc[train],
                categorical_feature=fold_categorical,
            )
            classifier_iteration_selection = "fixed from 2025 development fold"
        else:
            classifier.fit(
                train_matrix,
                target.loc[train],
                categorical_feature=fold_categorical,
                eval_X=valid_matrix,
                eval_y=target.loc[valid],
                eval_metric="average_precision",
                callbacks=[early_stopping(100, verbose=False), log_evaluation(0)],
            )
            classifier_iterations = int(classifier.best_iteration_)
            classifier_iteration_selection = "early stopping on 2025 development fold"
        classifier_score = classifier.predict_proba(valid_matrix)[:, 1]
        report = zone_rank_metrics(frame.loc[valid], classifier_score)
        report.update(
            {
                "fold": fold,
                "iterations_used": classifier_n_estimators
                if is_holdout
                else classifier_iterations,
                "iteration_selection": classifier_iteration_selection,
                "feature_count": len(fold_features),
                "feature_selection_scope": "training rows before fold start",
                "category_map_scope": "training rows before fold start",
                "seconds": round(time.monotonic() - started, 3),
            }
        )
        reports["classifier"].append(report)

        train_frame = frame.loc[train]
        valid_frame = frame.loc[valid]
        ranker_n_estimators = ranker_iterations if is_holdout else 1_600
        if ranker_n_estimators is None:
            raise RuntimeError("Ranker iteration count must be selected before holdout")
        ranker = LGBMRanker(
            **LGB_ZONE_RANKER_PARAMS, n_estimators=ranker_n_estimators
        )
        started = time.monotonic()
        if is_holdout:
            ranker.fit(
                train_matrix,
                target.loc[train],
                group=group_sizes(train_frame),
                categorical_feature=fold_categorical,
            )
            ranker_iteration_selection = "fixed from 2025 development fold"
        else:
            ranker.fit(
                train_matrix,
                target.loc[train],
                group=group_sizes(train_frame),
                categorical_feature=fold_categorical,
                eval_X=valid_matrix,
                eval_y=target.loc[valid],
                eval_group=[group_sizes(valid_frame)],
                eval_at=[1, 3, 5, 10],
                callbacks=[early_stopping(100, verbose=False), log_evaluation(0)],
            )
            ranker_iterations = int(ranker.best_iteration_)
            ranker_iteration_selection = "early stopping on 2025 development fold"
        ranker_score = ranker.predict(valid_matrix)
        report = zone_rank_metrics(valid_frame, ranker_score)
        report.update(
            {
                "fold": fold,
                "iterations_used": ranker_n_estimators if is_holdout else ranker_iterations,
                "iteration_selection": ranker_iteration_selection,
                "feature_count": len(fold_features),
                "feature_selection_scope": "training rows before fold start",
                "category_map_scope": "training rows before fold start",
                "seconds": round(time.monotonic() - started, 3),
            }
        )
        reports["ranker"].append(report)

        valid_output = valid_frame[["target_date", "site_raw", "zone_key", "target"]].copy()
        valid_output["classifier_score"] = classifier_score
        valid_output["ranker_score"] = ranker_score
        valid_output["classifier_rank"] = rank_percentile(valid_frame, classifier_score).values
        valid_output["ranker_rank"] = rank_percentile(valid_frame, ranker_score).values
        if not is_holdout:
            selected_ranker_weight, blend_selection = select_ranker_weight(
                valid_output,
                valid_output["classifier_rank"],
                valid_output["ranker_rank"],
            )
        if selected_ranker_weight is None:
            raise RuntimeError("Zone blend weight must be selected before holdout")
        valid_output["blend_rank"] = (
            (1.0 - selected_ranker_weight) * valid_output["classifier_rank"]
            + selected_ranker_weight * valid_output["ranker_rank"]
        )
        report = zone_rank_metrics(valid_output, valid_output["blend_rank"])
        report["fold"] = fold
        reports["blend"].append(report)
        oof_parts.append(valid_output)

    pd.concat(oof_parts, ignore_index=True).to_parquet(
        output / "zone_oof_predictions.parquet", index=False
    )
    if classifier_iterations is None or ranker_iterations is None:
        raise RuntimeError("Final iteration counts were not selected")
    if selected_ranker_weight is None or blend_selection is None:
        raise RuntimeError("Final blend weight was not selected")
    final_classifier = LGBMClassifier(
        **LGB_ZONE_CLASSIFIER_PARAMS, n_estimators=classifier_iterations
    ).fit(matrix, target, categorical_feature=categorical_columns)
    final_ranker = LGBMRanker(
        **LGB_ZONE_RANKER_PARAMS, n_estimators=ranker_iterations
    ).fit(
        matrix,
        target,
        group=group_sizes(frame),
        categorical_feature=categorical_columns,
    )
    joblib.dump(final_classifier, output / "zone_classifier.joblib", compress=3)
    joblib.dump(final_ranker, output / "zone_ranker.joblib", compress=3)
    metadata = {
        "model_version": args.model_version,
        "feature_policy": (
            "frozen manifest from prior champion; updated catalog mapping is output-only"
            if args.feature_manifest is not None
            else "all eligible features"
        ),
        "feature_manifest_source": (
            str(args.feature_manifest.resolve())
            if args.feature_manifest is not None
            else None
        ),
        "conditional_on": "site has at least one intrusion-proxy event next day",
        "features": features,
        "categorical_columns": categorical_columns,
        "category_maps": category_maps,
        "blend_weights": {
            "classifier_rank": 1.0 - selected_ranker_weight,
            "ranker_rank": selected_ranker_weight,
        },
        "blend_weight_selection": blend_selection,
        "final_holdout_fold": "2026H1",
        "final_model_iterations": {
            "classifier": classifier_iterations,
            "ranker": ranker_iterations,
        },
        "validation": reports,
        "baseline_90day_rate": baseline_reports,
    }
    (output / "zone_model_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(reports["blend"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
