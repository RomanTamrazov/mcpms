"""Validate model-3 site and zone CSV outputs before handoff or serving."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

SITE_REQUIRED = {
    "as_of_date",
    "forecast_date",
    "site_raw",
    "model_version",
    "risk_probability",
    "risk_band",
    "model_disagreement",
    "uncertainty_band",
    "alert",
    "workflow_state",
    "response_priority",
    "requires_independent_verification",
    "auto_incident_confirmation",
    "data_quality",
    "explanation_json",
}
ZONE_REQUIRED = {
    "date",
    "target_date",
    "site_raw",
    "zone_key",
    "zone_rank",
    "zone_classifier_probability",
    "zone_rank_score",
    "risk_probability",
    "uncertainty_band",
    "alert",
    "workflow_state",
    "response_priority",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site", type=Path, required=True)
    parser.add_argument("--zone", type=Path, required=True)
    parser.add_argument("--max-zone-rank", type=int, default=5)
    return parser.parse_args()


def validate(site_path: Path, zone_path: Path, max_zone_rank: int) -> dict[str, object]:
    site = pd.read_csv(site_path)
    zone = pd.read_csv(zone_path)
    errors: list[str] = []
    missing_site = sorted(SITE_REQUIRED.difference(site.columns))
    missing_zone = sorted(ZONE_REQUIRED.difference(zone.columns))
    if missing_site:
        errors.append(f"site output lacks columns: {missing_site}")
    if missing_zone:
        errors.append(f"zone output lacks columns: {missing_zone}")
    if errors:
        return {"status": "error", "errors": errors}

    if site.empty:
        errors.append("site output is empty")
    if site["site_raw"].duplicated().any():
        errors.append("site_raw is not unique in site output")
    if site.loc[:, list(SITE_REQUIRED)].isna().any().any():
        errors.append("site output contains missing required values")
    if not site["risk_probability"].between(0, 1).all():
        errors.append("site risk_probability is outside [0, 1]")
    if not set(site["risk_band"]).issubset(
        {"low", "elevated", "high", "very_high"}
    ):
        errors.append("site output contains an unknown risk_band")
    if (site["model_disagreement"] < 0).any():
        errors.append("site model_disagreement must be non-negative")
    if not set(site["uncertainty_band"]).issubset(
        {"low", "medium", "high", "extreme"}
    ):
        errors.append("site output contains an unknown uncertainty_band")
    if set(site["workflow_state"]) != {"FORECAST_RISK"}:
        errors.append("site forecast may only emit workflow_state=FORECAST_RISK")
    expected_priority = site["alert"].map({True: "P4", False: "NONE"})
    if not site["response_priority"].equals(expected_priority):
        errors.append("site response_priority must be P4 for alerts and NONE otherwise")
    if not site["requires_independent_verification"].equals(site["alert"]):
        errors.append("independent verification flag must match preventive alerts")
    if site["auto_incident_confirmation"].any():
        errors.append("a model forecast must never auto-confirm an incident")
    try:
        for value in site["explanation_json"]:
            json.loads(value)
    except (TypeError, json.JSONDecodeError):
        errors.append("site explanation_json contains invalid JSON")

    if zone.loc[:, list(ZONE_REQUIRED)].isna().any().any():
        errors.append("zone output contains missing required values")
    if zone.duplicated(["site_raw", "zone_key"]).any():
        errors.append("zone output contains duplicate site/zone keys")
    if not zone["zone_classifier_probability"].between(0, 1).all():
        errors.append("zone classifier probability is outside [0, 1]")
    if not zone["zone_rank_score"].between(0, 1).all():
        errors.append("zone rank score is outside [0, 1]")
    if not zone["zone_rank"].between(1, max_zone_rank).all():
        errors.append("zone rank is outside the requested top-k range")
    if set(zone["workflow_state"]) != {"FORECAST_RISK"}:
        errors.append("zone forecast may only emit workflow_state=FORECAST_RISK")
    if not set(zone["site_raw"]).issubset(set(site["site_raw"])):
        errors.append("zone output references a site absent from site output")
    if set(zone["target_date"].astype(str)) != set(site["forecast_date"].astype(str)):
        errors.append("site and zone forecast dates do not match")

    return {
        "status": "ok" if not errors else "error",
        "site_rows": int(site.shape[0]),
        "site_alert_rows": int(site["alert"].sum()),
        "zone_rows": int(zone.shape[0]),
        "zone_sites": int(zone["site_raw"].nunique()),
        "max_zone_rank": int(zone["zone_rank"].max()) if not zone.empty else 0,
        "errors": errors,
    }


def main() -> None:
    args = parse_args()
    if args.max_zone_rank < 1:
        raise ValueError("--max-zone-rank must be positive")
    report = validate(args.site, args.zone, args.max_zone_rank)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report["status"] == "error":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
