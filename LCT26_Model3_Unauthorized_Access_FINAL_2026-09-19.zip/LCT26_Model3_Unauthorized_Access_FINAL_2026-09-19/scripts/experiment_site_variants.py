"""Leakage-safe development search for robust site-model variants.

Candidate families are compared only on 2024 and 2025.  Exactly one selected
candidate is then evaluated once on the untouched 2026H1 holdout.  This script
is an experiment harness; production training remains in train_site_models.py.
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import dataclass
from pathlib import Path
from statistics import median
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score

from lct26_access.features import augment_site_model_frame
from lct26_access.metrics import best_f1_threshold, site_metrics
from lct26_access.models import (
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    SITE_EXCLUDE,
    encode_for_lightgbm,
    feature_columns,
    fit_category_maps,
)

DEVELOPMENT_FOLDS = (
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
HOLDOUT = ("2026H1", pd.Timestamp("2026-01-01"), pd.Timestamp("2026-07-01"))
KEY = ["site_raw", "target_date", "target", "fold"]
MINIMUM_ROBUST_PR_AUC_GAIN = 0.0005


@dataclass(frozen=True)
class Candidate:
    name: str
    frame_name: str
    use_identifiers: bool = True
    recency_half_life_days: int | None = None
    balanced_classes: bool = False


CANDIDATES = (
    Candidate("id_free_weekly", "weekly", use_identifiers=False),
    Candidate("id_free_context", "context", use_identifiers=False),
    Candidate("recency_2y_weekly", "weekly", recency_half_life_days=730),
    Candidate("recency_4y_weekly", "weekly", recency_half_life_days=1460),
    Candidate("balanced_weekly", "weekly", balanced_classes=True),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--baseline-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def _candidate_features(
    frame: pd.DataFrame,
    candidate: Candidate,
) -> tuple[list[str], tuple[str, ...]]:
    excluded = set(SITE_EXCLUDE)
    categorical = SITE_CATEGORICAL if candidate.use_identifiers else ()
    if not candidate.use_identifiers:
        excluded.update(SITE_CATEGORICAL)
    return feature_columns(frame, exclude=excluded), categorical


def _recency_weights(
    target_dates: pd.Series,
    cutoff: pd.Timestamp,
    half_life_days: int | None,
) -> np.ndarray | None:
    if half_life_days is None:
        return None
    age_days = (cutoff - pd.to_datetime(target_dates)).dt.days.clip(lower=0)
    return np.clip(0.5 ** (age_days.to_numpy() / half_life_days), 0.05, 1.0)


def development_predictions(
    frame: pd.DataFrame,
    candidate: Candidate,
) -> tuple[pd.DataFrame, list[int], list[str]]:
    features, categorical = _candidate_features(frame, candidate)
    target = frame["target"].astype(int)
    predictions: list[pd.DataFrame] = []
    iterations: list[int] = []
    for fold, start, end in DEVELOPMENT_FOLDS:
        train = frame["target_date"] < start
        valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
        maps = fit_category_maps(frame.loc[train], categorical)
        train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
        valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
        params = dict(LGB_WEEKLY_TUNED_PARAMS)
        if candidate.balanced_classes:
            params["class_weight"] = "balanced"
        model = LGBMClassifier(**params, n_estimators=1_800)
        started = time.monotonic()
        model.fit(
            train_matrix,
            target.loc[train],
            sample_weight=_recency_weights(
                frame.loc[train, "target_date"], start, candidate.recency_half_life_days
            ),
            categorical_feature=list(categorical),
            eval_X=valid_matrix,
            eval_y=target.loc[valid],
            eval_metric="average_precision",
            callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
        )
        iteration = int(model.best_iteration_)
        iterations.append(iteration)
        probability = model.predict_proba(valid_matrix)[:, 1]
        output = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
        output["fold"] = fold
        output["candidate_probability"] = probability
        output["iterations_used"] = iteration
        output["seconds"] = round(time.monotonic() - started, 3)
        predictions.append(output)
    return pd.concat(predictions, ignore_index=True), iterations, features


def fold_pr_auc(frame: pd.DataFrame, score_column: str) -> dict[str, float]:
    return {
        fold: float(average_precision_score(group["target"], group[score_column]))
        for fold, group in frame.groupby("fold", sort=False)
    }


def select_candidate_and_weight(
    baseline: pd.DataFrame,
    candidates: dict[str, pd.DataFrame],
) -> tuple[str, float, dict[str, Any]]:
    baseline_development = baseline[baseline["fold"].isin({"2024", "2025"})]
    baseline_scores = fold_pr_auc(baseline_development, "ensemble_probability")
    best_key = (
        min(baseline_scores.values()),
        float(np.mean(list(baseline_scores.values()))),
        0.0,
    )
    selected_name = "baseline_only"
    selected_weight = 0.0
    trials: list[dict[str, Any]] = [
        {
            "candidate": selected_name,
            "candidate_weight": 0.0,
            "fold_pr_auc": baseline_scores,
        }
    ]
    for name, candidate_oof in candidates.items():
        merged = baseline_development.merge(
            candidate_oof.loc[:, [*KEY, "candidate_probability"]],
            on=KEY,
            validate="one_to_one",
        )
        for weight in np.linspace(0.05, 0.50, 10):
            merged["trial_probability"] = (
                (1 - weight) * merged["ensemble_probability"]
                + weight * merged["candidate_probability"]
            )
            scores = fold_pr_auc(merged, "trial_probability")
            key = (
                min(scores.values()),
                float(np.mean(list(scores.values()))),
                -float(weight),
            )
            trials.append(
                {
                    "candidate": name,
                    "candidate_weight": float(weight),
                    "fold_pr_auc": scores,
                }
            )
            if key > best_key:
                best_key = key
                selected_name = name
                selected_weight = float(weight)
    unconstrained_name = selected_name
    unconstrained_weight = selected_weight
    minimum_gain = float(best_key[0] - min(baseline_scores.values()))
    rejected_as_immaterial = (
        selected_name != "baseline_only"
        and minimum_gain < MINIMUM_ROBUST_PR_AUC_GAIN
    )
    if rejected_as_immaterial:
        selected_name = "baseline_only"
        selected_weight = 0.0
    return selected_name, selected_weight, {
        "objective": "maximise minimum 2024/2025 PR-AUC, then mean PR-AUC",
        "baseline_fold_pr_auc": baseline_scores,
        "unconstrained_best_key": list(best_key),
        "unconstrained_best_candidate": unconstrained_name,
        "unconstrained_best_candidate_weight": unconstrained_weight,
        "minimum_fold_pr_auc_gain": minimum_gain,
        "minimum_material_gain_required": MINIMUM_ROBUST_PR_AUC_GAIN,
        "rejected_as_immaterial": rejected_as_immaterial,
        "trials": trials,
    }


def holdout_prediction(
    frame: pd.DataFrame,
    candidate: Candidate,
    development_iterations: list[int],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    fold, start, end = HOLDOUT
    train = frame["target_date"] < start
    valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
    features, categorical = _candidate_features(frame, candidate)
    maps = fit_category_maps(frame.loc[train], categorical)
    train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
    valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
    params = dict(LGB_WEEKLY_TUNED_PARAMS)
    if candidate.balanced_classes:
        params["class_weight"] = "balanced"
    iterations = max(1, round(median(development_iterations)))
    model = LGBMClassifier(**params, n_estimators=iterations)
    started = time.monotonic()
    model.fit(
        train_matrix,
        frame.loc[train, "target"].astype(int),
        sample_weight=_recency_weights(
            frame.loc[train, "target_date"], start, candidate.recency_half_life_days
        ),
        categorical_feature=list(categorical),
    )
    output = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
    output["fold"] = fold
    output["candidate_probability"] = model.predict_proba(valid_matrix)[:, 1]
    return output, {
        "iterations": iterations,
        "seconds": round(time.monotonic() - started, 3),
        "selection": "median early-stopping iterations from 2024 and 2025",
    }


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    frames = {
        "weekly": augment_site_model_frame(args.site_features, weekly=True),
        "context": augment_site_model_frame(
            args.site_features, context_path=args.context_features, weekly=True
        ),
    }
    for name, frame in frames.items():
        frame = frame[frame["target"].notna()].copy()
        frame["target_date"] = pd.to_datetime(frame["target_date"])
        frames[name] = frame
    baseline = pd.read_parquet(args.baseline_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])

    candidate_oof: dict[str, pd.DataFrame] = {}
    candidate_iterations: dict[str, list[int]] = {}
    feature_counts: dict[str, int] = {}
    development_reports: dict[str, Any] = {}
    for candidate in CANDIDATES:
        predictions, iterations, features = development_predictions(
            frames[candidate.frame_name], candidate
        )
        candidate_oof[candidate.name] = predictions
        candidate_iterations[candidate.name] = iterations
        feature_counts[candidate.name] = len(features)
        development_reports[candidate.name] = {
            "fold_pr_auc": fold_pr_auc(predictions, "candidate_probability"),
            "iterations": iterations,
            "feature_count": len(features),
            "fit_seconds": {
                fold: float(group["seconds"].iloc[0])
                for fold, group in predictions.groupby("fold", sort=False)
            },
        }

    selected_name, selected_weight, selection = select_candidate_and_weight(
        baseline, candidate_oof
    )
    holdout_report: dict[str, Any] | None = None
    combined_oof = baseline.copy()
    if selected_name != "baseline_only":
        selected = next(item for item in CANDIDATES if item.name == selected_name)
        holdout_candidate, fit_report = holdout_prediction(
            frames[selected.frame_name],
            selected,
            candidate_iterations[selected_name],
        )
        all_selected = pd.concat(
            [candidate_oof[selected_name], holdout_candidate], ignore_index=True
        )
        combined_oof = baseline.merge(
            all_selected.loc[:, [*KEY, "candidate_probability"]],
            on=KEY,
            validate="one_to_one",
        )
        combined_oof["robust_probability"] = (
            (1 - selected_weight) * combined_oof["ensemble_probability"]
            + selected_weight * combined_oof["candidate_probability"]
        )
        development = combined_oof[combined_oof["fold"].isin({"2024", "2025"})]
        threshold = best_f1_threshold(development["target"], development["robust_probability"])
        holdout = combined_oof[combined_oof["fold"] == "2026H1"]
        holdout_report = {
            "candidate_fit": fit_report,
            "candidate_only": site_metrics(
                holdout["target"],
                holdout["candidate_probability"],
                holdout["target_date"],
            ),
            "combined": site_metrics(
                holdout["target"],
                holdout["robust_probability"],
                holdout["target_date"],
                threshold=threshold,
            ),
            "combined_threshold_from_2024_2025": threshold,
        }
    else:
        combined_oof["robust_probability"] = combined_oof["ensemble_probability"]

    combined_oof.to_parquet(output / "robust_variant_oof.parquet", index=False)
    report = {
        "protocol": (
            "All candidates and blend weights selected on 2024/2025 only; exactly one "
            "selected candidate evaluated once on 2026H1."
        ),
        "development_candidates": development_reports,
        "selection": {
            **selection,
            "selected_candidate": selected_name,
            "selected_candidate_weight": selected_weight,
        },
        "holdout_2026H1": holdout_report,
        "feature_counts": feature_counts,
    }
    (output / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
