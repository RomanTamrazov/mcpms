"""Expanded development walk-forward for the frozen zone-localisation recipe.

The 2023--2025 folds use the frozen feature manifest, hyperparameters, blend,
and final tree counts.  Category maps and feature eligibility are fit on rows
strictly before each fold.  The report-only 2026H1 holdout is never loaded.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import pandas as pd
import polars as pl
from lightgbm import LGBMClassifier, LGBMRanker

from lct26_access.features import augment_zone_model_frame
from lct26_access.metrics import zone_rank_metrics
from lct26_access.models import (
    LGB_ZONE_CLASSIFIER_PARAMS,
    LGB_ZONE_RANKER_PARAMS,
    ZONE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
    group_sizes,
)

FOLDS = (
    ("2023", pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
CONTEXT_COLUMNS = (
    "site_family",
    "zone_past_positive_days",
    "zone_history_days",
    "zone_past_positive_rate",
    "zone_positive_rate28",
    "zone_positive_rate90",
    "zone_positive_rate365",
    "site_past_positive_rate",
    "static_channels",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zone-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def rank_percentile(frame: pd.DataFrame, score: pd.Series) -> pd.Series:
    temporary = frame[["target_date", "site_raw"]].copy()
    temporary["score"] = score.to_numpy()
    return temporary.groupby(["target_date", "site_raw"])["score"].rank(method="average", pct=True)


def eligible_features(frame: pd.DataFrame, requested: list[str]) -> list[str]:
    return [
        feature
        for feature in requested
        if feature in frame.columns and frame[feature].nunique(dropna=False) > 1
    ]


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    requested = list(metadata["features"])
    iterations = metadata["final_model_iterations"]
    weights = metadata["blend_weights"]
    frame = (
        pl.scan_parquet(args.zone_features)
        .with_columns(pl.col("target").max().over(["site_raw", "target_date"]).alias("site_target"))
        .filter((pl.col("site_target") == 1) & (pl.col("target_date") < pl.date(2026, 1, 1)))
        .collect()
        .to_pandas()
    )
    frame = (
        augment_zone_model_frame(frame)
        .sort_values(["target_date", "site_raw", "zone_key"])
        .reset_index(drop=True)
    )
    frame["target_date"] = pd.to_datetime(frame["target_date"])
    if (frame["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered expanded zone evaluation")

    target = frame["target"].astype("int8")
    oof_parts: list[pd.DataFrame] = []
    reports: list[dict[str, Any]] = []
    for fold, start, end in FOLDS:
        train = frame["target_date"] < start
        valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
        features = eligible_features(frame.loc[train], requested)
        categorical = [name for name in ZONE_CATEGORICAL if name in features]
        maps = fit_category_maps(frame.loc[train], categorical)
        train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
        valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
        train_frame = frame.loc[train]
        valid_frame = frame.loc[valid]

        classifier = LGBMClassifier(
            **LGB_ZONE_CLASSIFIER_PARAMS,
            n_estimators=int(iterations["classifier"]),
        )
        started = time.monotonic()
        classifier.fit(
            train_matrix,
            target.loc[train],
            categorical_feature=categorical,
        )
        classifier_seconds = time.monotonic() - started
        classifier_score = pd.Series(
            classifier.predict_proba(valid_matrix)[:, 1], index=valid_frame.index
        )

        ranker = LGBMRanker(
            **LGB_ZONE_RANKER_PARAMS,
            n_estimators=int(iterations["ranker"]),
        )
        started = time.monotonic()
        ranker.fit(
            train_matrix,
            target.loc[train],
            group=group_sizes(train_frame),
            categorical_feature=categorical,
        )
        ranker_seconds = time.monotonic() - started
        ranker_score = pd.Series(ranker.predict(valid_matrix), index=valid_frame.index)

        available_context = [name for name in CONTEXT_COLUMNS if name in valid_frame.columns]
        output = valid_frame[
            ["target_date", "site_raw", "zone_key", "target", *available_context]
        ].copy()
        output["fold"] = fold
        output["classifier_score"] = classifier_score.to_numpy()
        output["ranker_score"] = ranker_score.to_numpy()
        output["classifier_rank"] = rank_percentile(valid_frame, classifier_score).to_numpy()
        output["ranker_rank"] = rank_percentile(valid_frame, ranker_score).to_numpy()
        output["blend_rank"] = (
            float(weights["classifier_rank"]) * output["classifier_rank"]
            + float(weights["ranker_rank"]) * output["ranker_rank"]
        )
        oof_parts.append(output)
        reports.append(
            {
                "fold": fold,
                "train_rows": int(train.sum()),
                "validation_rows": int(valid.sum()),
                "groups": int(valid_frame[["target_date", "site_raw"]].drop_duplicates().shape[0]),
                "feature_count": len(features),
                "classifier_seconds": round(classifier_seconds, 3),
                "ranker_seconds": round(ranker_seconds, 3),
                "classifier": zone_rank_metrics(valid_frame, classifier_score),
                "ranker": zone_rank_metrics(valid_frame, ranker_score),
                "blend": zone_rank_metrics(output, output["blend_rank"]),
                "baseline_zone_positive_rate90": zone_rank_metrics(
                    valid_frame, valid_frame["zone_positive_rate90"]
                ),
            }
        )
        print(
            f"completed fold={fold} rows={int(valid.sum())} "
            f"hit@5={reports[-1]['blend']['hit_rate_at_5']:.6f}",
            flush=True,
        )

    oof = pd.concat(oof_parts, ignore_index=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    oof.to_parquet(args.output_dir / "expanded_zone_walk_forward_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_016_expanded_zone_walk_forward",
        "status": "diagnostic",
        "protocol": {
            "folds": [fold for fold, _, _ in FOLDS],
            "train_rule": "strictly target_date before fold start",
            "feature_schema": "frozen champion manifest",
            "tree_counts": iterations,
            "blend_weights": weights,
            "category_maps": "fit on fold-train only",
            "holdout_2026h1_accessed": False,
        },
        "fold_reports": reports,
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
