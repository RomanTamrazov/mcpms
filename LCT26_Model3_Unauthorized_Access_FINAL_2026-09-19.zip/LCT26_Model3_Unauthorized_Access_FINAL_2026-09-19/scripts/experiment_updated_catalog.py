"""Development-only ablation for the organiser's updated object mapping."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    log_loss,
    roc_auc_score,
)

from lct26_access.features import augment_site_model_frame
from lct26_access.metrics import (
    robust_f1_threshold,
    site_metrics,
    threshold_for_min_group_recall,
)
from lct26_access.models import (
    LGB_BASE_PARAMS,
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    SITE_EXCLUDE,
    encode_for_lightgbm,
    feature_columns,
    fit_category_maps,
)

FOLDS = (
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
COMPONENTS = ("lgb_base", "lgb_weekly_tuned", "lgb_context")
OBJECT_TOKENS = ("object", "parent")
MATERIAL_WORST_FOLD_GAIN = 0.0005


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--champion-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def _strict_features(
    frame: pd.DataFrame,
    train_mask: pd.Series,
    requested: list[str],
) -> list[str]:
    train = frame.loc[train_mask]
    return [
        column
        for column in requested
        if column in train.columns and train[column].nunique(dropna=False) > 1
    ]


def _fit_component(
    frame: pd.DataFrame,
    requested_features: list[str],
    params: dict[str, object],
    component: str,
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    target = frame["target"].astype(int)
    parts: list[pd.DataFrame] = []
    reports: list[dict[str, Any]] = []
    for fold, start, end in FOLDS:
        train = frame["target_date"] < start
        valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
        features = _strict_features(frame, train, requested_features)
        categorical = [
            column for column in SITE_CATEGORICAL if column in features
        ]
        maps = fit_category_maps(frame.loc[train], categorical)
        train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
        valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
        model = LGBMClassifier(**params, n_estimators=1_800)
        started = time.monotonic()
        model.fit(
            train_matrix,
            target.loc[train],
            categorical_feature=categorical,
            eval_X=valid_matrix,
            eval_y=target.loc[valid],
            eval_metric="average_precision",
            callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
        )
        probability = model.predict_proba(valid_matrix)[:, 1]
        output = frame.loc[
            valid, ["site_raw", "target_date", "target"]
        ].copy()
        output["fold"] = fold
        output[component] = probability
        parts.append(output)
        reports.append(
            {
                "fold": fold,
                "features": len(features),
                "object_features": sum(
                    any(token in feature for token in OBJECT_TOKENS)
                    for feature in features
                ),
                "iterations": int(model.best_iteration_),
                "fit_seconds": round(time.monotonic() - started, 3),
                "pr_auc": float(
                    average_precision_score(target.loc[valid], probability)
                ),
            }
        )
    return pd.concat(parts, ignore_index=True), reports


def _variant_oof(
    frames: dict[str, pd.DataFrame],
    requested: dict[str, list[str]],
    weights: dict[str, float],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    outputs: list[pd.DataFrame] = []
    component_reports: dict[str, Any] = {}
    params = {
        "lgb_base": LGB_BASE_PARAMS,
        "lgb_weekly_tuned": LGB_WEEKLY_TUNED_PARAMS,
        "lgb_context": LGB_BASE_PARAMS,
    }
    for component in COMPONENTS:
        output, reports = _fit_component(
            frames[component], requested[component], params[component], component
        )
        outputs.append(output)
        component_reports[component] = reports
    key = ["site_raw", "target_date", "target", "fold"]
    merged = outputs[0]
    for output in outputs[1:]:
        merged = merged.merge(output, on=key, validate="one_to_one")
    merged["probability"] = sum(
        float(weights[name]) * merged[name] for name in COMPONENTS
    )
    return merged, component_reports


def _fold_probability_metrics(frame: pd.DataFrame) -> dict[str, Any]:
    output: dict[str, Any] = {}
    for fold, group in frame.groupby("fold", sort=False):
        target = group["target"].to_numpy(dtype=np.int8)
        probability = group["probability"].to_numpy(dtype=float)
        output[fold] = {
            "rows": int(group.shape[0]),
            "pr_auc": float(average_precision_score(target, probability)),
            "roc_auc": float(roc_auc_score(target, probability)),
            "brier": float(brier_score_loss(target, probability)),
            "logloss": float(log_loss(target, probability, labels=[0, 1])),
        }
    return output


def _threshold_report(frame: pd.DataFrame) -> dict[str, Any]:
    balanced, balanced_selection = robust_f1_threshold(
        frame["target"], frame["probability"], frame["fold"]
    )
    operational, operational_selection = threshold_for_min_group_recall(
        frame["target"], frame["probability"], frame["fold"], 0.80
    )
    return {
        "balanced_threshold": balanced,
        "balanced_selection": balanced_selection,
        "operational_threshold": operational,
        "operational_selection": operational_selection,
        "operational_by_fold": {
            fold: site_metrics(
                group["target"],
                group["probability"],
                group["target_date"],
                threshold=operational,
            )
            for fold, group in frame.groupby("fold", sort=False)
        },
    }


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    weights = {
        name: float(metadata["ensemble_weights"][name]) for name in COMPONENTS
    }
    if not np.isclose(sum(weights.values()), 1.0):
        raise ValueError("Active LightGBM champion weights must sum to one")

    frames = {
        "lgb_base": augment_site_model_frame(args.site_features, weekly=False),
        "lgb_weekly_tuned": augment_site_model_frame(
            args.site_features, weekly=True
        ),
        "lgb_context": augment_site_model_frame(
            args.site_features,
            context_path=args.context_features,
            weekly=True,
        ),
    }
    for name, frame in frames.items():
        frame = frame[
            frame["target"].notna()
            & (pd.to_datetime(frame["target_date"]) < pd.Timestamp("2026-01-01"))
        ].copy()
        frame["target_date"] = pd.to_datetime(frame["target_date"])
        frames[name] = frame

    legacy_features = {
        name: list(metadata["variants"][name]["features"])
        for name in COMPONENTS
    }
    hierarchy_features = {
        name: feature_columns(frame, exclude=SITE_EXCLUDE)
        for name, frame in frames.items()
    }
    legacy_oof, legacy_components = _variant_oof(
        frames, legacy_features, weights
    )
    hierarchy_oof, hierarchy_components = _variant_oof(
        frames, hierarchy_features, weights
    )
    comparison = legacy_oof[
        ["site_raw", "target_date", "target", "fold", "probability"]
    ].rename(columns={"probability": "legacy_strict_probability"}).merge(
        hierarchy_oof[
            ["site_raw", "target_date", "target", "fold", "probability"]
        ].rename(columns={"probability": "hierarchy_probability"}),
        on=["site_raw", "target_date", "target", "fold"],
        validate="one_to_one",
    )
    stored = pd.read_parquet(args.champion_oof)
    stored = stored[stored["fold"].isin({"2024", "2025"})][
        ["site_raw", "target_date", "target", "fold", "ensemble_probability"]
    ]
    comparison = comparison.merge(
        stored,
        on=["site_raw", "target_date", "target", "fold"],
        validate="one_to_one",
    )
    legacy_metrics = _fold_probability_metrics(legacy_oof)
    hierarchy_metrics = _fold_probability_metrics(hierarchy_oof)
    stored_metrics = {
        fold: {
            "pr_auc": float(
                average_precision_score(group["target"], group["ensemble_probability"])
            ),
            "brier": float(
                brier_score_loss(group["target"], group["ensemble_probability"])
            ),
        }
        for fold, group in stored.groupby("fold", sort=False)
    }
    fold_deltas = {
        fold: {
            "pr_auc_hierarchy_minus_legacy_strict": (
                hierarchy_metrics[fold]["pr_auc"] - legacy_metrics[fold]["pr_auc"]
            ),
            "brier_hierarchy_minus_legacy_strict": (
                hierarchy_metrics[fold]["brier"] - legacy_metrics[fold]["brier"]
            ),
            "legacy_strict_pr_auc_minus_stored_champion": (
                legacy_metrics[fold]["pr_auc"] - stored_metrics[fold]["pr_auc"]
            ),
        }
        for fold, _, _ in FOLDS
    }
    minimum_pr_gain = min(
        value["pr_auc_hierarchy_minus_legacy_strict"]
        for value in fold_deltas.values()
    )
    accepted = (
        minimum_pr_gain >= MATERIAL_WORST_FOLD_GAIN
        and all(
            value["brier_hierarchy_minus_legacy_strict"] <= 0.001
            for value in fold_deltas.values()
        )
    )
    comparison.to_parquet(output / "updated_catalog_development_oof.parquet", index=False)
    report = {
        "protocol": {
            "dataset": "/Users/dinvinch/Downloads/dataset (1).zip",
            "folds": [fold for fold, _, _ in FOLDS],
            "holdout_accessed": False,
            "category_maps": "fit on fold training rows only",
            "feature_eligibility": "evaluated on fold training rows only",
            "ensemble_weights": weights,
            "material_worst_fold_pr_auc_gain": MATERIAL_WORST_FOLD_GAIN,
        },
        "stored_champion": stored_metrics,
        "legacy_feature_set_strict": {
            "metrics": legacy_metrics,
            "thresholds": _threshold_report(legacy_oof),
            "components": legacy_components,
        },
        "object_hierarchy_candidate": {
            "metrics": hierarchy_metrics,
            "thresholds": _threshold_report(hierarchy_oof),
            "components": hierarchy_components,
        },
        "fold_deltas": fold_deltas,
        "decision": {
            "accepted": accepted,
            "minimum_fold_pr_auc_gain": minimum_pr_gain,
            "reason": (
                "Object hierarchy passes the predeclared robust materiality gate."
                if accepted
                else "Object hierarchy does not pass the robust materiality gate on both development folds."
            ),
        },
    }
    (output / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report["fold_deltas"], ensure_ascii=False, indent=2))
    print(json.dumps(report["decision"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
