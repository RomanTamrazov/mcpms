"""Temporal validation and final training for the 24-hour site-risk ensemble."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from statistics import median

import joblib
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score

from lct26_access.constants import TEMPORAL_FOLDS
from lct26_access.features import augment_site_model_frame
from lct26_access.metrics import (
    robust_f1_threshold,
    site_metrics,
    threshold_for_min_group_recall,
    threshold_for_min_precision,
    threshold_for_min_recall,
)
from lct26_access.models import (
    LGB_BASE_PARAMS,
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    SITE_EXCLUDE,
    encode_for_catboost,
    encode_for_lightgbm,
    feature_columns,
    fit_category_maps,
)

MODEL_NAMES = ("lgb_base", "cat_base", "lgb_weekly_tuned", "lgb_context")
DEVELOPMENT_FOLDS = ("2024", "2025")
FINAL_HOLDOUT_FOLD = "2026H1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument(
        "--feature-manifest",
        type=Path,
        help="Optional prior metadata whose per-variant feature schema is frozen.",
    )
    parser.add_argument(
        "--model-version",
        default="model3-site-v2.0-episode-features",
    )
    return parser.parse_args()


def eligible_features(
    frame: pd.DataFrame,
    *,
    requested: list[str] | None = None,
) -> list[str]:
    candidates = (
        feature_columns(frame, exclude=SITE_EXCLUDE)
        if requested is None
        else [column for column in requested if column in frame.columns]
    )
    return [
        column
        for column in candidates
        if frame[column].nunique(dropna=False) > 1
    ]


def temporal_lgb_predictions(
    frame: pd.DataFrame,
    params: dict[str, object],
    requested_features: list[str] | None = None,
) -> tuple[pd.DataFrame, list[str], dict[str, dict[str, int]], list[dict[str, object]]]:
    # Production schema/maps are fitted on all labelled history only after the
    # temporal evaluation is complete.  Every OOF fold below derives its own
    # feature eligibility and category maps strictly from that fold's past.
    production_features = eligible_features(frame, requested=requested_features)
    production_categorical = [
        name for name in SITE_CATEGORICAL if name in production_features
    ]
    production_maps = fit_category_maps(frame, production_categorical)
    target = frame["target"].astype(int)
    predictions: list[pd.DataFrame] = []
    reports: list[dict[str, object]] = []
    development_iterations: list[int] = []
    for fold, start, end in TEMPORAL_FOLDS:
        train = frame["target_date"] < pd.Timestamp(start)
        valid = (frame["target_date"] >= pd.Timestamp(start)) & (
            frame["target_date"] < pd.Timestamp(end)
        )
        fold_features = eligible_features(
            frame.loc[train], requested=requested_features
        )
        fold_categorical = [
            name for name in SITE_CATEGORICAL if name in fold_features
        ]
        fold_maps = fit_category_maps(frame.loc[train], fold_categorical)
        train_matrix = encode_for_lightgbm(
            frame.loc[train], fold_features, fold_maps
        )
        valid_matrix = encode_for_lightgbm(
            frame.loc[valid], fold_features, fold_maps
        )
        is_holdout = fold == FINAL_HOLDOUT_FOLD
        selected_iterations = (
            max(1, round(median(development_iterations)))
            if is_holdout
            else 1_800
        )
        model = LGBMClassifier(**params, n_estimators=selected_iterations)
        started = time.monotonic()
        if is_holdout:
            model.fit(
                train_matrix,
                target.loc[train],
                categorical_feature=fold_categorical,
            )
            iterations_used = selected_iterations
            iteration_selection = "median of 2024/2025 early-stopping iterations"
        else:
            model.fit(
                train_matrix,
                target.loc[train],
                categorical_feature=fold_categorical,
                eval_X=valid_matrix,
                eval_y=target.loc[valid],
                eval_metric="average_precision",
                callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
            )
            iterations_used = int(model.best_iteration_)
            development_iterations.append(iterations_used)
            iteration_selection = "early stopping on development fold"
        probability = model.predict_proba(valid_matrix)[:, 1]
        report = site_metrics(
            target.loc[valid], probability, frame.loc[valid, "target_date"]
        )
        report.update(
            {
                "fold": fold,
                "train_rows": int(train.sum()),
                "iterations_used": iterations_used,
                "iteration_selection": iteration_selection,
                "feature_count": len(fold_features),
                "feature_selection_scope": "training rows before fold start",
                "category_map_scope": "training rows before fold start",
                "seconds": round(time.monotonic() - started, 3),
            }
        )
        reports.append(report)
        predictions.append(
            pd.DataFrame(
                {
                    "site_raw": frame.loc[valid, "site_raw"].values,
                    "target_date": frame.loc[valid, "target_date"].values,
                    "target": target.loc[valid].values,
                    "fold": fold,
                    "probability": probability,
                }
            )
        )
    return (
        pd.concat(predictions, ignore_index=True),
        production_features,
        production_maps,
        reports,
    )


def temporal_cat_predictions(
    frame: pd.DataFrame,
    requested_features: list[str] | None = None,
) -> tuple[pd.DataFrame, list[str], list[dict[str, object]]]:
    production_features = eligible_features(frame, requested=requested_features)
    target = frame["target"].astype(int)
    predictions: list[pd.DataFrame] = []
    reports: list[dict[str, object]] = []
    development_iterations: list[int] = []
    for fold, start, end in TEMPORAL_FOLDS:
        train = frame["target_date"] < pd.Timestamp(start)
        valid = (frame["target_date"] >= pd.Timestamp(start)) & (
            frame["target_date"] < pd.Timestamp(end)
        )
        fold_features = eligible_features(
            frame.loc[train], requested=requested_features
        )
        fold_categorical = [
            name for name in SITE_CATEGORICAL if name in fold_features
        ]
        categorical_indices = [
            fold_features.index(name) for name in fold_categorical
        ]
        train_matrix = encode_for_catboost(
            frame.loc[train], fold_features, fold_categorical
        )
        valid_matrix = encode_for_catboost(
            frame.loc[valid], fold_features, fold_categorical
        )
        is_holdout = fold == FINAL_HOLDOUT_FOLD
        selected_iterations = (
            max(1, round(median(development_iterations)))
            if is_holdout
            else 1_400
        )
        model = CatBoostClassifier(
            iterations=selected_iterations,
            depth=7,
            learning_rate=0.035,
            loss_function="Logloss",
            eval_metric="AUC",
            l2_leaf_reg=6.0,
            random_seed=2603,
            random_strength=0.35,
            bagging_temperature=0.35,
            border_count=96,
            verbose=False,
            allow_writing_files=False,
            thread_count=-1,
            od_type="Iter",
            od_wait=140,
        )
        started = time.monotonic()
        if is_holdout:
            model.fit(
                train_matrix,
                target.loc[train],
                cat_features=categorical_indices,
                verbose=False,
            )
            iterations_used = selected_iterations
            iteration_selection = "median of 2024/2025 early-stopping iterations"
        else:
            model.fit(
                train_matrix,
                target.loc[train],
                cat_features=categorical_indices,
                eval_set=(valid_matrix, target.loc[valid]),
                verbose=False,
            )
            iterations_used = int(model.tree_count_)
            development_iterations.append(iterations_used)
            iteration_selection = "early stopping on development fold"
        probability = model.predict_proba(valid_matrix)[:, 1]
        report = site_metrics(
            target.loc[valid], probability, frame.loc[valid, "target_date"]
        )
        report.update(
            {
                "fold": fold,
                "train_rows": int(train.sum()),
                "iterations_used": iterations_used,
                "iteration_selection": iteration_selection,
                "feature_count": len(fold_features),
                "feature_selection_scope": "training rows before fold start",
                "category_handling_scope": "raw strings seen by training rows only",
                "seconds": round(time.monotonic() - started, 3),
            }
        )
        reports.append(report)
        predictions.append(
            pd.DataFrame(
                {
                    "site_raw": frame.loc[valid, "site_raw"].values,
                    "target_date": frame.loc[valid, "target_date"].values,
                    "target": target.loc[valid].values,
                    "fold": fold,
                    "probability": probability,
                }
            )
        )
    return pd.concat(predictions, ignore_index=True), production_features, reports


def _simplex_candidates(units: int = 20) -> list[np.ndarray]:
    """Return deterministic four-model weights on a 1/units simplex grid."""

    candidates: list[np.ndarray] = []
    for first in range(units + 1):
        for second in range(units - first + 1):
            for third in range(units - first - second + 1):
                fourth = units - first - second - third
                candidates.append(
                    np.asarray([first, second, third, fourth], dtype=float) / units
                )
    return candidates


def select_ensemble_weights(
    oof: pd.DataFrame,
) -> tuple[dict[str, float], dict[str, object]]:
    """Tune weights only on 2024/2025, maximizing the weaker fold's PR-AUC."""

    development = oof[oof["fold"].isin(DEVELOPMENT_FOLDS)]
    fold_data = {
        fold: (
            group["target"].to_numpy(dtype=np.int8),
            group.loc[:, MODEL_NAMES].to_numpy(dtype=float),
        )
        for fold, group in development.groupby("fold", sort=False)
    }
    if set(fold_data) != set(DEVELOPMENT_FOLDS):
        raise ValueError(f"Expected development folds {DEVELOPMENT_FOLDS}, got {tuple(fold_data)}")

    best_key: tuple[float, float, float] | None = None
    best_weights: np.ndarray | None = None
    best_scores: dict[str, float] | None = None
    for weights in _simplex_candidates():
        scores = {
            fold: float(average_precision_score(target, matrix @ weights))
            for fold, (target, matrix) in fold_data.items()
        }
        # Primary objective is robustness (maximin), then mean quality. The last
        # tie-break favours a less concentrated ensemble when scores are equal.
        key = (min(scores.values()), float(np.mean(list(scores.values()))), -float(weights.max()))
        if best_key is None or key > best_key:
            best_key = key
            best_weights = weights
            best_scores = scores
    if best_weights is None or best_scores is None:
        raise RuntimeError("No ensemble candidate was evaluated")
    selected = {
        name: float(weight) for name, weight in zip(MODEL_NAMES, best_weights, strict=True)
    }
    details: dict[str, object] = {
        "strategy": "maximise minimum PR-AUC across 2024 and 2025",
        "grid_step": 0.05,
        "fold_scores": best_scores,
        "mean_pr_auc": float(np.mean(list(best_scores.values()))),
        "minimum_pr_auc": float(min(best_scores.values())),
    }
    return selected, details


def selected_iteration_count(reports: list[dict[str, object]]) -> int:
    values = [
        int(report["iterations_used"])
        for report in reports
        if report["fold"] in DEVELOPMENT_FOLDS
    ]
    return max(1, round(median(values)))


def weighted_model_disagreement(
    predictions: pd.DataFrame,
    weights: dict[str, float],
) -> np.ndarray:
    """Weighted standard deviation across positively weighted components."""

    active = {name: weight for name, weight in weights.items() if weight > 0}
    matrix = predictions.loc[:, list(active)].to_numpy(dtype=float)
    weight_vector = np.asarray(list(active.values()), dtype=float)
    weight_vector /= weight_vector.sum()
    mean = matrix @ weight_vector
    return np.sqrt(((matrix - mean[:, None]) ** 2) @ weight_vector)


def main() -> None:
    args = parse_args()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    feature_manifest: dict[str, list[str]] = {}
    if args.feature_manifest is not None:
        manifest = json.loads(
            args.feature_manifest.read_text(encoding="utf-8")
        )
        feature_manifest = {
            name: list(spec["features"])
            for name, spec in manifest["variants"].items()
        }

    base = augment_site_model_frame(args.site_features, weekly=False)
    weekly = augment_site_model_frame(args.site_features, weekly=True)
    context = augment_site_model_frame(
        args.site_features, context_path=args.context_features, weekly=True
    )
    base = base[base["target"].notna()].copy()
    weekly = weekly[weekly["target"].notna()].copy()
    context = context[context["target"].notna()].copy()
    base_oof, base_features, base_maps, base_reports = temporal_lgb_predictions(
        base, LGB_BASE_PARAMS, feature_manifest.get("lgb_base")
    )
    cat_oof, cat_features, cat_reports = temporal_cat_predictions(
        base, feature_manifest.get("cat_base")
    )
    weekly_oof, weekly_features, weekly_maps, weekly_reports = temporal_lgb_predictions(
        weekly,
        LGB_WEEKLY_TUNED_PARAMS,
        feature_manifest.get("lgb_weekly_tuned"),
    )
    context_oof, context_features, context_maps, context_reports = temporal_lgb_predictions(
        context, LGB_BASE_PARAMS, feature_manifest.get("lgb_context")
    )
    key = ["site_raw", "target_date", "target", "fold"]
    oof = (
        base_oof.rename(columns={"probability": "lgb_base"})
        .merge(cat_oof.rename(columns={"probability": "cat_base"}), on=key, validate="one_to_one")
        .merge(
            weekly_oof.rename(columns={"probability": "lgb_weekly_tuned"}),
            on=key,
            validate="one_to_one",
        )
        .merge(
            context_oof.rename(columns={"probability": "lgb_context"}),
            on=key,
            validate="one_to_one",
        )
    )
    ensemble_weights, weight_selection = select_ensemble_weights(oof)
    oof["ensemble_probability"] = sum(
        ensemble_weights[name] * oof[name] for name in MODEL_NAMES
    )
    oof["ensemble_disagreement"] = weighted_model_disagreement(
        oof, ensemble_weights
    )
    threshold_rows = oof[oof["fold"].isin(DEVELOPMENT_FOLDS)]
    threshold, threshold_selection = robust_f1_threshold(
        threshold_rows["target"],
        threshold_rows["ensemble_probability"],
        threshold_rows["fold"],
    )
    operational_threshold, operational_threshold_selection = (
        threshold_for_min_group_recall(
            threshold_rows["target"],
            threshold_rows["ensemble_probability"],
            threshold_rows["fold"],
            0.80,
        )
    )
    high_precision_threshold = threshold_for_min_precision(
        threshold_rows["target"], threshold_rows["ensemble_probability"], 0.75
    )
    high_recall_threshold = threshold_for_min_recall(
        threshold_rows["target"], threshold_rows["ensemble_probability"], 0.90
    )
    disagreement_quantiles = {
        "median": float(threshold_rows["ensemble_disagreement"].quantile(0.50)),
        "high": float(threshold_rows["ensemble_disagreement"].quantile(0.75)),
        "extreme": float(threshold_rows["ensemble_disagreement"].quantile(0.95)),
    }
    ensemble_reports = []
    for fold, fold_frame in oof.groupby("fold", sort=False):
        report = site_metrics(
            fold_frame["target"],
            fold_frame["ensemble_probability"],
            fold_frame["target_date"],
            threshold=threshold,
        )
        report["fold"] = fold
        ensemble_reports.append(report)
    oof.to_parquet(output / "site_oof_predictions.parquet", index=False)

    baseline_reports: dict[str, list[dict[str, object]]] = {}
    for baseline_name, score_column in {
        "previous_day_state": "current_intrusion_day",
        "positive_day_rate_28d": "positive_day_rate28",
    }.items():
        fold_reports: list[dict[str, object]] = []
        for fold, start, end in TEMPORAL_FOLDS:
            valid = (base["target_date"] >= pd.Timestamp(start)) & (
                base["target_date"] < pd.Timestamp(end)
            )
            report = site_metrics(
                base.loc[valid, "target"].astype(int),
                base.loc[valid, score_column],
                base.loc[valid, "target_date"],
            )
            report["fold"] = fold
            fold_reports.append(report)
        baseline_reports[baseline_name] = fold_reports

    # Fit production candidates on all labelled history with iteration counts
    # selected from the rolling future folds, never from random CV.
    model_specs = {
        "lgb_base": (
            base,
            base_features,
            base_maps,
            LGB_BASE_PARAMS,
            selected_iteration_count(base_reports),
        ),
        "lgb_weekly_tuned": (
            weekly,
            weekly_features,
            weekly_maps,
            LGB_WEEKLY_TUNED_PARAMS,
            selected_iteration_count(weekly_reports),
        ),
        "lgb_context": (
            context,
            context_features,
            context_maps,
            LGB_BASE_PARAMS,
            selected_iteration_count(context_reports),
        ),
    }
    for name, (frame, features, maps, params, iterations) in model_specs.items():
        matrix = encode_for_lightgbm(frame, features, maps)
        categorical = [
            column for column in SITE_CATEGORICAL if column in features
        ]
        model = LGBMClassifier(**params, n_estimators=iterations)
        model.fit(
            matrix,
            frame["target"].astype(int),
            categorical_feature=categorical,
        )
        joblib.dump(model, output / f"{name}.joblib", compress=3)

    cat_categorical = [
        column for column in SITE_CATEGORICAL if column in cat_features
    ]
    cat_matrix = encode_for_catboost(base, cat_features, cat_categorical)
    cat_iterations = selected_iteration_count(cat_reports)
    cat_model = CatBoostClassifier(
        iterations=cat_iterations,
        depth=7,
        learning_rate=0.035,
        loss_function="Logloss",
        l2_leaf_reg=6.0,
        random_seed=2603,
        random_strength=0.35,
        bagging_temperature=0.35,
        border_count=96,
        verbose=False,
        allow_writing_files=False,
        thread_count=-1,
    )
    cat_model.fit(
        cat_matrix,
        base["target"].astype(int),
        cat_features=[cat_features.index(name) for name in cat_categorical],
        verbose=False,
    )
    cat_model.save_model(output / "cat_base.cbm")

    metadata = {
        "model_version": args.model_version,
        "feature_policy": (
            "frozen manifest from prior champion; updated catalog mapping is output-only"
            if args.feature_manifest is not None
            else "all eligible features"
        ),
        "feature_manifest_source": (
            str(args.feature_manifest.resolve())
            if args.feature_manifest is not None
            else None
        ),
        "target_semantics": (
            "At least one next-calendar-day SCADA security alarm with value "
            "'Обнаружено движение' or 'Не замкнут'; proxy, not dispatcher-confirmed intrusion"
        ),
        "horizon_hours": 24,
        "default_threshold_mode": "operational_recall_80",
        "ensemble_weights": ensemble_weights,
        "ensemble_weight_selection": weight_selection,
        "decision_thresholds_from_2024_2025": {
            "balanced_f1": threshold,
            "operational_recall_80": operational_threshold,
            "high_precision_75": high_precision_threshold,
            "high_recall_90": high_recall_threshold,
        },
        "balanced_threshold_selection": threshold_selection,
        "operational_threshold_selection": operational_threshold_selection,
        "uncertainty": {
            "definition": (
                "weighted standard deviation of positively weighted component "
                "probabilities; higher means less model agreement"
            ),
            "thresholds_from_2024_2025": disagreement_quantiles,
        },
        "final_holdout_fold": FINAL_HOLDOUT_FOLD,
        "final_model_iterations": {
            **{name: spec[-1] for name, spec in model_specs.items()},
            "cat_base": cat_iterations,
        },
        "categorical_columns": cat_categorical,
        "variants": {
            "lgb_base": {"features": base_features, "category_maps": base_maps},
            "cat_base": {"features": cat_features},
            "lgb_weekly_tuned": {
                "features": weekly_features,
                "category_maps": weekly_maps,
            },
            "lgb_context": {
                "features": context_features,
                "category_maps": context_maps,
            },
        },
        "validation": {
            "lgb_base": base_reports,
            "cat_base": cat_reports,
            "lgb_weekly_tuned": weekly_reports,
            "lgb_context": context_reports,
            "ensemble": ensemble_reports,
            "baselines": baseline_reports,
        },
    }
    (output / "site_model_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata["validation"]["ensemble"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
