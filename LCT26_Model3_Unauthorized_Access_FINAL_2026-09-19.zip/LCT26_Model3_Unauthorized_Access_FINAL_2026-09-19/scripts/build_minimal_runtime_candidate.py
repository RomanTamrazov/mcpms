"""Build the production runtime artifact without zero-weight CatBoost files."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

SITE_FILES = (
    "lgb_base.joblib",
    "lgb_weekly_tuned.joblib",
    "lgb_context.joblib",
)
ZONE_FILES = (
    "zone_classifier.joblib",
    "zone_ranker.joblib",
    "zone_model_metadata.json",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-model-dir", type=Path, required=True)
    parser.add_argument("--zone-model-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_record(path: Path, *, root: Path) -> dict[str, Any]:
    return {
        "relative_path": str(path.relative_to(root)),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def main() -> None:
    args = parse_args()
    source_metadata_path = args.site_model_dir / "site_model_metadata.json"
    metadata = json.loads(source_metadata_path.read_text(encoding="utf-8"))
    cat_weight = float(metadata["ensemble_weights"].get("cat_base", 0.0))
    if cat_weight != 0.0:
        raise ValueError(f"Cannot remove CatBoost with non-zero weight {cat_weight}")

    site_output = args.output_dir / "site"
    zone_output = args.output_dir / "zone"
    site_output.mkdir(parents=True, exist_ok=True)
    zone_output.mkdir(parents=True, exist_ok=True)
    for name in SITE_FILES:
        shutil.copy2(args.site_model_dir / name, site_output / name)
    for name in ZONE_FILES:
        shutil.copy2(args.zone_model_dir / name, zone_output / name)

    metadata["variants"].pop("cat_base", None)
    metadata.get("final_model_iterations", {}).pop("cat_base", None)
    metadata["runtime_profile"] = {
        "profile": "three-lightgbm-no-catboost",
        "prediction_equivalence_requirement": "exact",
        "omitted_zero_weight_component": "cat_base",
        "training_evidence_retained_outside_runtime_artifact": True,
    }
    (site_output / "site_model_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    source_files = [
        *(args.site_model_dir / name for name in (*SITE_FILES, "cat_base.cbm")),
        *(args.zone_model_dir / name for name in ZONE_FILES),
        source_metadata_path,
    ]
    output_files = sorted([path for path in args.output_dir.rglob("*") if path.is_file()])
    source_bytes = sum(path.stat().st_size for path in source_files)
    output_bytes = sum(path.stat().st_size for path in output_files)
    report = {
        "experiment_id": "EXP_015_minimal_runtime_no_catboost",
        "decision_basis": "cat_base has frozen ensemble weight 0.0",
        "source_bytes": source_bytes,
        "candidate_bytes": output_bytes,
        "bytes_removed": source_bytes - output_bytes,
        "relative_size_reduction": 1.0 - output_bytes / source_bytes,
        "catboost_model_shipped": (site_output / "cat_base.cbm").exists(),
        "site_variant_metadata": sorted(metadata["variants"]),
        "candidate_files": [file_record(path, root=args.output_dir) for path in output_files],
        "prediction_equivalence": "pending",
    }
    (args.output_dir / "build_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
