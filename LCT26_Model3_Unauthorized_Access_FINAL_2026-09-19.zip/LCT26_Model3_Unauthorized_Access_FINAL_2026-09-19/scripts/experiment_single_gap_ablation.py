"""Compact follow-up to the multi-gap episode experiment.

One alternative gap is selected using only 2022/2023.  Only that gap's 23
features are then fitted and evaluated on 2024/2025.  The 2026H1 holdout is not
loaded or scored.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score, brier_score_loss

from lct26_access.features import augment_site_model_frame
from lct26_access.models import (
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

FOLDS = {
    "2022": (pd.Timestamp("2022-01-01"), pd.Timestamp("2023-01-01")),
    "2023": (pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    "2024": (pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    "2025": (pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
}
SELECTION_FOLDS = ("2022", "2023")
CONFIRMATION_FOLDS = ("2024", "2025")
GAPS = (5, 10, 15, 60, 120)
DAILY_COLUMNS = (
    "intrusion_episode_count",
    "intrusion_multi_event_episodes",
    "intrusion_motion_contact_episodes",
    "intrusion_episode_max_events",
    "intrusion_episode_mean_events",
    "intrusion_episode_max_channels",
    "intrusion_episode_max_zones",
    "intrusion_episode_max_sensor_types",
    "intrusion_episode_max_duration_minutes",
    "intrusion_zone_transitions",
    "intrusion_episode_burstiness",
)
ROLLING_COLUMNS = (
    "intrusion_episode_count",
    "intrusion_multi_event_episodes",
    "intrusion_episode_max_events",
    "intrusion_episode_max_duration_minutes",
    "intrusion_zone_transitions",
    "intrusion_episode_burstiness",
)
MIN_CONFIRMATION_WORST_GAIN = 0.0005
MAX_CONFIRMATION_BRIER_INCREASE = 0.0001


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--multi-gap-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--baseline-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def gap_features(gap: int) -> list[str]:
    return [
        *(f"{column}_gap{gap}" for column in DAILY_COLUMNS),
        *(f"{column}_gap{gap}_mean{window}" for column in ROLLING_COLUMNS for window in (7, 28)),
    ]


def fold_metrics(frame: pd.DataFrame, score_column: str) -> dict[str, dict[str, float]]:
    return {
        str(fold): {
            "pr_auc": float(average_precision_score(group["target"], group[score_column])),
            "brier": float(brier_score_loss(group["target"], group[score_column])),
        }
        for fold, group in frame.groupby("fold", sort=True)
    }


def fit_gap(
    frame: pd.DataFrame,
    *,
    gap: int,
    folds: tuple[str, ...],
    frozen_features: list[str],
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    requested = [*frozen_features, *gap_features(gap)]
    parts: list[pd.DataFrame] = []
    reports: list[dict[str, Any]] = []
    for fold in folds:
        start, end = FOLDS[fold]
        train = frame["target_date"] < start
        valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
        features = [
            feature
            for feature in requested
            if feature in frame.columns and frame.loc[train, feature].nunique(dropna=False) > 1
        ]
        categorical = [name for name in SITE_CATEGORICAL if name in features]
        maps = fit_category_maps(frame.loc[train], categorical)
        train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
        valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
        model = LGBMClassifier(**LGB_WEEKLY_TUNED_PARAMS, n_estimators=1_800)
        started = time.monotonic()
        model.fit(
            train_matrix,
            frame.loc[train, "target"].astype("int8"),
            categorical_feature=categorical,
            eval_X=valid_matrix,
            eval_y=frame.loc[valid, "target"].astype("int8"),
            eval_metric="average_precision",
            callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
        )
        output = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
        output["fold"] = fold
        output["single_gap_probability"] = model.predict_proba(valid_matrix)[:, 1]
        parts.append(output)
        reports.append(
            {
                "gap_minutes": gap,
                "fold": fold,
                "feature_count": len(features),
                "added_feature_count": len(gap_features(gap)),
                "iterations": int(model.best_iteration_),
                "fit_seconds": round(time.monotonic() - started, 3),
            }
        )
        print(f"completed gap={gap} fold={fold}", flush=True)
    return pd.concat(parts, ignore_index=True), reports


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    base = augment_site_model_frame(args.site_features, weekly=True)
    base = base[base["target"].notna()].copy()
    base["date"] = pd.to_datetime(base["date"])
    base["target_date"] = pd.to_datetime(base["target_date"])
    base = base[base["target_date"] < pd.Timestamp("2026-01-01")]
    extra = pd.read_parquet(args.multi_gap_features)
    extra["date"] = pd.to_datetime(extra["date"])
    frame = base.merge(
        extra,
        on=["site_raw", "site_family", "date"],
        how="left",
        validate="one_to_one",
    )
    added_columns = [column for gap in GAPS for column in gap_features(gap)]
    frame[added_columns] = frame[added_columns].fillna(0)
    frozen_features = list(metadata["variants"]["lgb_weekly_tuned"]["features"])
    baseline = pd.read_parquet(args.baseline_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])
    if (baseline["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered single-gap experiment")
    baseline_metrics = fold_metrics(baseline, "ensemble_probability")
    key = ["site_raw", "target_date", "target", "fold"]

    selection_trials: list[dict[str, Any]] = []
    best_key: tuple[float, float, float] | None = None
    selected_gap: int | None = None
    selected_weight = 0.0
    selection_fit_reports: dict[str, list[dict[str, Any]]] = {}
    for gap in GAPS:
        candidate, reports = fit_gap(
            frame,
            gap=gap,
            folds=SELECTION_FOLDS,
            frozen_features=frozen_features,
        )
        selection_fit_reports[str(gap)] = reports
        comparison = baseline[baseline["fold"].isin(SELECTION_FOLDS)][
            key + ["ensemble_probability"]
        ].merge(candidate, on=key, validate="one_to_one")
        for weight in np.linspace(0.0, 0.5, 21):
            comparison["trial_probability"] = (1.0 - weight) * comparison[
                "ensemble_probability"
            ] + weight * comparison["single_gap_probability"]
            trial_metrics = fold_metrics(comparison, "trial_probability")
            deltas = {
                fold: trial_metrics[fold]["pr_auc"] - baseline_metrics[fold]["pr_auc"]
                for fold in SELECTION_FOLDS
            }
            key_value = (
                min(deltas.values()),
                float(np.mean(list(deltas.values()))),
                -float(weight),
            )
            trial = {
                "gap_minutes": gap,
                "candidate_weight": float(weight),
                "selection_metrics": trial_metrics,
                "selection_pr_auc_deltas": deltas,
            }
            selection_trials.append(trial)
            if best_key is None or key_value > best_key:
                best_key = key_value
                selected_gap = gap
                selected_weight = float(weight)
    if selected_gap is None:
        raise RuntimeError("No single-gap candidate evaluated")
    selected_trial = next(
        trial
        for trial in selection_trials
        if trial["gap_minutes"] == selected_gap and trial["candidate_weight"] == selected_weight
    )

    confirmation_candidate, confirmation_fit = fit_gap(
        frame,
        gap=selected_gap,
        folds=CONFIRMATION_FOLDS,
        frozen_features=frozen_features,
    )
    confirmation = baseline[baseline["fold"].isin(CONFIRMATION_FOLDS)][
        key + ["ensemble_probability"]
    ].merge(confirmation_candidate, on=key, validate="one_to_one")
    confirmation["candidate_probability"] = (1.0 - selected_weight) * confirmation[
        "ensemble_probability"
    ] + selected_weight * confirmation["single_gap_probability"]
    confirmation_metrics = fold_metrics(confirmation, "candidate_probability")
    confirmation_deltas = {
        fold: {
            metric: confirmation_metrics[fold][metric] - baseline_metrics[fold][metric]
            for metric in ("pr_auc", "brier")
        }
        for fold in CONFIRMATION_FOLDS
    }
    selection_eligible = (
        selected_weight > 0.0 and min(selected_trial["selection_pr_auc_deltas"].values()) > 0.0
    )
    accepted = (
        selection_eligible
        and min(confirmation_deltas[fold]["pr_auc"] for fold in CONFIRMATION_FOLDS)
        >= MIN_CONFIRMATION_WORST_GAIN
        and all(
            confirmation_deltas[fold]["brier"] <= MAX_CONFIRMATION_BRIER_INCREASE
            for fold in CONFIRMATION_FOLDS
        )
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    confirmation.to_parquet(args.output_dir / "single_gap_confirmation_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_024_single_gap_ablation",
        "priority": "P1 episode windows follow-up",
        "protocol": {
            "candidate_gaps_minutes": list(GAPS),
            "features_per_gap": len(gap_features(GAPS[0])),
            "selection_folds": list(SELECTION_FOLDS),
            "confirmation_folds": list(CONFIRMATION_FOLDS),
            "holdout_2026h1_accessed": False,
            "minimum_confirmation_worst_pr_auc_gain": MIN_CONFIRMATION_WORST_GAIN,
            "maximum_confirmation_brier_increase": MAX_CONFIRMATION_BRIER_INCREASE,
        },
        "baseline_metrics": baseline_metrics,
        "selection_fit_reports": selection_fit_reports,
        "selection_trials": selection_trials,
        "selected_gap_minutes": selected_gap,
        "selected_weight": selected_weight,
        "selected_trial": selected_trial,
        "selection_eligible": selection_eligible,
        "selected_features": gap_features(selected_gap),
        "confirmation_fit": confirmation_fit,
        "confirmation_metrics": confirmation_metrics,
        "confirmation_deltas": confirmation_deltas,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Compact single-gap candidate passes the predeclared confirmation gate."
                if accepted
                else "Compact single-gap candidate does not pass the predeclared confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "selection_trials"},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
