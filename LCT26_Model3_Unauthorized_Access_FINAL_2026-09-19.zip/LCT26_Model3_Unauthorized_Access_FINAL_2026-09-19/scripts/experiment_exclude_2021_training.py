"""Test excluding transition-year 2021 rows from site model fitting.

The organiser Q&A mentions a monitoring-system transition around 2021.  This
experiment changes only the training-row mask; features, hyperparameters,
weights, thresholds, and validation windows remain frozen.  The 2026H1 holdout
is never loaded or scored.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score, brier_score_loss

from lct26_access.features import augment_site_model_frame
from lct26_access.models import (
    LGB_BASE_PARAMS,
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

COMPONENTS = ("lgb_base", "lgb_weekly_tuned", "lgb_context")
FOLDS = (
    ("2022", pd.Timestamp("2022-01-01"), pd.Timestamp("2023-01-01")),
    ("2023", pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
SELECTION_FOLDS = ("2022", "2023")
CONFIRMATION_FOLDS = ("2024", "2025")
EXCLUDED_TRAINING_YEAR = 2021
MIN_CONFIRMATION_PR_GAIN = 0.0005
MAX_CONFIRMATION_BRIER_INCREASE = 0.0001


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--baseline-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def eligible_features(frame: pd.DataFrame, requested: list[str]) -> list[str]:
    return [
        feature
        for feature in requested
        if feature in frame.columns and frame[feature].nunique(dropna=False) > 1
    ]


def fold_metrics(frame: pd.DataFrame, score_column: str) -> dict[str, dict[str, float]]:
    return {
        str(fold): {
            "pr_auc": float(average_precision_score(group["target"], group[score_column])),
            "brier": float(brier_score_loss(group["target"], group[score_column])),
        }
        for fold, group in frame.groupby("fold", sort=True)
    }


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    weights = {
        component: float(metadata["ensemble_weights"][component]) for component in COMPONENTS
    }
    frames = {
        "lgb_base": augment_site_model_frame(args.site_features, weekly=False),
        "lgb_weekly_tuned": augment_site_model_frame(args.site_features, weekly=True),
        "lgb_context": augment_site_model_frame(
            args.site_features,
            context_path=args.context_features,
            weekly=True,
        ),
    }
    for component, frame in frames.items():
        frame = frame[frame["target"].notna()].copy()
        frame["target_date"] = pd.to_datetime(frame["target_date"])
        frames[component] = frame[frame["target_date"] < pd.Timestamp("2026-01-01")]
    params = {
        "lgb_base": LGB_BASE_PARAMS,
        "lgb_weekly_tuned": LGB_WEEKLY_TUNED_PARAMS,
        "lgb_context": LGB_BASE_PARAMS,
    }
    requested = {
        component: list(metadata["variants"][component]["features"]) for component in COMPONENTS
    }
    component_parts: dict[str, list[pd.DataFrame]] = {component: [] for component in COMPONENTS}
    fit_reports: dict[str, list[dict[str, Any]]] = {component: [] for component in COMPONENTS}
    for component in COMPONENTS:
        frame = frames[component]
        for fold, start, end in FOLDS:
            train_before_exclusion = frame["target_date"] < start
            train = train_before_exclusion & (
                frame["target_date"].dt.year != EXCLUDED_TRAINING_YEAR
            )
            valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
            features = eligible_features(frame.loc[train], requested[component])
            categorical = [name for name in SITE_CATEGORICAL if name in features]
            maps = fit_category_maps(frame.loc[train], categorical)
            train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
            valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
            model = LGBMClassifier(**params[component], n_estimators=1_800)
            started = time.monotonic()
            model.fit(
                train_matrix,
                frame.loc[train, "target"].astype("int8"),
                categorical_feature=categorical,
                eval_X=valid_matrix,
                eval_y=frame.loc[valid, "target"].astype("int8"),
                eval_metric="average_precision",
                callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
            )
            output = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
            output["fold"] = fold
            output[component] = model.predict_proba(valid_matrix)[:, 1]
            component_parts[component].append(output)
            fit_reports[component].append(
                {
                    "fold": fold,
                    "train_rows_before_exclusion": int(train_before_exclusion.sum()),
                    "train_rows_after_exclusion": int(train.sum()),
                    "excluded_rows": int((train_before_exclusion & ~train).sum()),
                    "validation_rows": int(valid.sum()),
                    "feature_count": len(features),
                    "iterations": int(model.best_iteration_),
                    "fit_seconds": round(time.monotonic() - started, 3),
                }
            )
            print(f"completed component={component} fold={fold}", flush=True)

    key = ["site_raw", "target_date", "target", "fold"]
    candidate = pd.concat(component_parts[COMPONENTS[0]], ignore_index=True)
    for component in COMPONENTS[1:]:
        candidate = candidate.merge(
            pd.concat(component_parts[component], ignore_index=True),
            on=key,
            validate="one_to_one",
        )
    candidate["candidate_probability"] = sum(
        weights[component] * candidate[component] for component in COMPONENTS
    )
    baseline = pd.read_parquet(args.baseline_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])
    if (baseline["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered 2021-exclusion experiment")
    baseline_metrics = fold_metrics(baseline, "ensemble_probability")
    candidate_metrics = fold_metrics(candidate, "candidate_probability")
    deltas = {
        fold: {
            metric: candidate_metrics[fold][metric] - baseline_metrics[fold][metric]
            for metric in ("pr_auc", "brier")
        }
        for fold, _, _ in FOLDS
    }
    selection_eligible = all(deltas[fold]["pr_auc"] >= 0.0 for fold in SELECTION_FOLDS)
    accepted = (
        selection_eligible
        and min(deltas[fold]["pr_auc"] for fold in CONFIRMATION_FOLDS) >= MIN_CONFIRMATION_PR_GAIN
        and all(
            deltas[fold]["brier"] <= MAX_CONFIRMATION_BRIER_INCREASE for fold in CONFIRMATION_FOLDS
        )
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    candidate.to_parquet(args.output_dir / "exclude_2021_development_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_020_exclude_2021_training",
        "priority": "P1_data_regime",
        "protocol": {
            "motivation": "organiser Q&A notes a monitoring-system transition around 2021",
            "change": "exclude target_date year 2021 from model fitting only",
            "selection_folds": list(SELECTION_FOLDS),
            "confirmation_folds": list(CONFIRMATION_FOLDS),
            "holdout_2026h1_accessed": False,
            "features_hyperparameters_weights_and_threshold": "frozen",
            "minimum_confirmation_pr_auc_gain": MIN_CONFIRMATION_PR_GAIN,
            "maximum_confirmation_brier_increase": MAX_CONFIRMATION_BRIER_INCREASE,
        },
        "fit_reports": fit_reports,
        "baseline_metrics": baseline_metrics,
        "candidate_metrics": candidate_metrics,
        "fold_deltas": deltas,
        "selection_eligible": selection_eligible,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Excluding 2021 passes the predeclared confirmation gate."
                if accepted
                else "Excluding 2021 does not pass the predeclared confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
