"""Independently recompute Model-3 metrics from saved prediction-level rows.

This module intentionally does not import ``lct26_access.metrics``.  Its purpose
is to catch reporting or aggregation errors by implementing the evaluation a
second time from the persisted OOF predictions.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

SITE_FOLDS = ("2024", "2025", "2026H1")
ZONE_FOLDS = ("2025", "2026H1")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-oof", type=Path, required=True)
    parser.add_argument("--site-metadata", type=Path, required=True)
    parser.add_argument("--zone-oof", type=Path, required=True)
    parser.add_argument("--validation-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    parser.add_argument("--tolerance", type=float, default=1e-10)
    return parser.parse_args()


def _top_k_precision(frame: pd.DataFrame, k: int) -> float:
    ranked = frame.sort_values(
        ["target_date", "ensemble_probability", "site_raw"],
        ascending=[True, False, True],
        kind="mergesort",
    )
    selected = ranked.groupby("target_date", sort=False).head(k)
    return float(selected["target"].mean())


def _site_metrics(frame: pd.DataFrame, threshold: float) -> dict[str, Any]:
    target = frame["target"].to_numpy(dtype=np.int8)
    probability = frame["ensemble_probability"].to_numpy(dtype=float)
    predicted = probability >= threshold
    tn, fp, fn, tp = confusion_matrix(target, predicted, labels=[0, 1]).ravel()
    return {
        "rows": int(target.size),
        "positives": int(target.sum()),
        "prevalence": float(target.mean()),
        "roc_auc": float(roc_auc_score(target, probability)),
        "pr_auc": float(average_precision_score(target, probability)),
        "brier": float(brier_score_loss(target, probability)),
        "logloss": float(log_loss(target, probability, labels=[0, 1])),
        "threshold": float(threshold),
        "precision": float(precision_score(target, predicted, zero_division=0)),
        "recall": float(recall_score(target, predicted, zero_division=0)),
        "f1": float(f1_score(target, predicted, zero_division=0)),
        "confusion_matrix": {
            "tn": int(tn),
            "fp": int(fp),
            "fn": int(fn),
            "tp": int(tp),
        },
        "precision_at_3_per_day": _top_k_precision(frame, 3),
        "precision_at_5_per_day": _top_k_precision(frame, 5),
    }


def _zone_group_rows(zone: pd.DataFrame) -> pd.DataFrame:
    ranked = zone.sort_values(
        ["target_date", "site_raw", "blend_rank", "zone_key"],
        ascending=[True, True, False, True],
        kind="mergesort",
    ).copy()
    ranked["zone_rank"] = ranked.groupby(
        ["target_date", "site_raw"], sort=False
    ).cumcount() + 1
    positive = ranked[ranked["target"].astype(int) == 1]
    first = (
        positive.groupby(["target_date", "site_raw"], sort=False)["zone_rank"]
        .min()
        .rename("first_positive_rank")
        .reset_index()
    )
    group_sizes = (
        ranked.groupby(["target_date", "site_raw"], sort=False)
        .size()
        .rename("candidate_zones")
        .reset_index()
    )
    return first.merge(
        group_sizes,
        on=["target_date", "site_raw"],
        how="left",
        validate="one_to_one",
    )


def _zone_metrics(zone: pd.DataFrame) -> tuple[dict[str, Any], pd.DataFrame]:
    groups = _zone_group_rows(zone)
    rank = groups["first_positive_rank"].to_numpy(dtype=float)
    metrics: dict[str, Any] = {
        "candidate_rows": int(zone.shape[0]),
        "positive_site_days": int(groups.shape[0]),
        "positive_zones": int(zone["target"].sum()),
        "mrr": float(np.mean(1.0 / rank)),
        "mean_first_positive_rank": float(rank.mean()),
    }
    for k in (1, 3, 5, 10):
        metrics[f"hit_rate_at_{k}"] = float(np.mean(rank <= k))
    return metrics, groups


def _end_to_end(
    site: pd.DataFrame,
    groups: pd.DataFrame,
    threshold: float,
) -> dict[str, float | int]:
    paired = groups.merge(
        site[["target_date", "site_raw", "target", "ensemble_probability"]],
        on=["target_date", "site_raw"],
        how="left",
        validate="one_to_one",
    )
    if paired["ensemble_probability"].isna().any():
        raise ValueError("Positive zone group lacks a matching site prediction")
    selected = paired["ensemble_probability"].to_numpy(dtype=float) >= threshold
    result: dict[str, float | int] = {
        "positive_site_days": int(paired.shape[0]),
        "site_recall_at_threshold": float(selected.mean()),
    }
    rank = paired["first_positive_rank"].to_numpy(dtype=float)
    for k in (1, 3, 5, 10):
        result[f"end_to_end_hit_at_{k}"] = float(np.mean(selected & (rank <= k)))
    return result


def _delta(actual: float, expected: float) -> float:
    return float(actual - expected)


def _comparison_rows(
    recomputed: dict[str, Any],
    validation: dict[str, Any],
) -> list[dict[str, Any]]:
    site_holdout = validation["site_ensemble"]["holdout_2026H1"]
    site_default = site_holdout["default_operational"]
    zone_holdout = validation["zone_localisation"]["holdout_2026H1"]
    end_to_end = validation["robustness"]["end_to_end_localisation"]["by_fold"][
        "2026H1"
    ]
    mappings = {
        "site.pr_auc": (
            recomputed["site"]["2026H1"]["pr_auc"],
            site_holdout["pr_auc"],
        ),
        "site.roc_auc": (
            recomputed["site"]["2026H1"]["roc_auc"],
            site_holdout["roc_auc"],
        ),
        "site.brier": (
            recomputed["site"]["2026H1"]["brier"],
            site_holdout["brier"],
        ),
        "site.logloss": (
            recomputed["site"]["2026H1"]["logloss"],
            site_holdout["logloss"],
        ),
        "site.precision": (
            recomputed["site"]["2026H1"]["precision"],
            site_default["precision"],
        ),
        "site.recall": (
            recomputed["site"]["2026H1"]["recall"],
            site_default["recall"],
        ),
        "site.f1": (
            recomputed["site"]["2026H1"]["f1"],
            site_default["f1"],
        ),
        "site.precision_at_3": (
            recomputed["site"]["2026H1"]["precision_at_3_per_day"],
            site_holdout["precision_at_3_per_day"],
        ),
        "site.precision_at_5": (
            recomputed["site"]["2026H1"]["precision_at_5_per_day"],
            site_holdout["precision_at_5_per_day"],
        ),
        "zone.mrr": (
            recomputed["zone"]["2026H1"]["mrr"],
            zone_holdout["mrr"],
        ),
        "zone.hit_at_1": (
            recomputed["zone"]["2026H1"]["hit_rate_at_1"],
            zone_holdout["hit_rate_at_1"],
        ),
        "zone.hit_at_3": (
            recomputed["zone"]["2026H1"]["hit_rate_at_3"],
            zone_holdout["hit_rate_at_3"],
        ),
        "zone.hit_at_5": (
            recomputed["zone"]["2026H1"]["hit_rate_at_5"],
            zone_holdout["hit_rate_at_5"],
        ),
        "zone.hit_at_10": (
            recomputed["zone"]["2026H1"]["hit_rate_at_10"],
            zone_holdout["hit_rate_at_10"],
        ),
        "end_to_end.hit_at_5": (
            recomputed["end_to_end"]["2026H1"]["end_to_end_hit_at_5"],
            end_to_end["end_to_end_hit_at_operating_threshold_zones_5"],
        ),
    }
    return [
        {
            "metric": name,
            "recomputed": float(actual),
            "reported": float(expected),
            "absolute_delta": abs(_delta(float(actual), float(expected))),
        }
        for name, (actual, expected) in mappings.items()
    ]


def _markdown(report: dict[str, Any]) -> str:
    holdout = report["recomputed"]["site"]["2026H1"]
    zone = report["recomputed"]["zone"]["2026H1"]
    e2e = report["recomputed"]["end_to_end"]["2026H1"]
    cm = holdout["confusion_matrix"]
    lines = [
        "# Независимая верификация champion Модели 3",
        "",
        f"Статус: **{report['status'].upper()}**.",
        "",
        "Метрики повторно рассчитаны непосредственно из сохранённых OOF-строк, ",
        "без использования функций основного модуля метрик.",
        "",
        "## 2026H1 site",
        "",
        "| Метрика | Значение |",
        "|---|---:|",
        f"| PR-AUC | {holdout['pr_auc']:.10f} |",
        f"| ROC-AUC | {holdout['roc_auc']:.10f} |",
        f"| Brier | {holdout['brier']:.10f} |",
        f"| LogLoss | {holdout['logloss']:.10f} |",
        f"| Precision | {holdout['precision']:.10f} |",
        f"| Recall | {holdout['recall']:.10f} |",
        f"| F1 | {holdout['f1']:.10f} |",
        f"| Precision@3/day | {holdout['precision_at_3_per_day']:.10f} |",
        f"| Precision@5/day | {holdout['precision_at_5_per_day']:.10f} |",
        "",
        f"Confusion matrix: TN={cm['tn']}, FP={cm['fp']}, FN={cm['fn']}, TP={cm['tp']}.",
        "",
        "## 2026H1 zone и end-to-end",
        "",
        "| Метрика | Значение |",
        "|---|---:|",
        f"| MRR | {zone['mrr']:.10f} |",
        f"| Hit@1 | {zone['hit_rate_at_1']:.10f} |",
        f"| Hit@3 | {zone['hit_rate_at_3']:.10f} |",
        f"| Hit@5 | {zone['hit_rate_at_5']:.10f} |",
        f"| Hit@10 | {zone['hit_rate_at_10']:.10f} |",
        f"| End-to-end Hit@5 | {e2e['end_to_end_hit_at_5']:.10f} |",
        "",
        f"Максимальное абсолютное расхождение с отчётом: {report['max_absolute_delta']:.3g}.",
    ]
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    site = pd.read_parquet(args.site_oof)
    zone = pd.read_parquet(args.zone_oof)
    metadata = json.loads(args.site_metadata.read_text(encoding="utf-8"))
    validation = json.loads(args.validation_report.read_text(encoding="utf-8"))
    site["target_date"] = pd.to_datetime(site["target_date"])
    zone["target_date"] = pd.to_datetime(zone["target_date"])
    threshold_mode = metadata.get("default_threshold_mode", "balanced_f1")
    threshold = float(
        metadata["decision_thresholds_from_2024_2025"][threshold_mode]
    )

    recomputed: dict[str, Any] = {"site": {}, "zone": {}, "end_to_end": {}}
    for fold in SITE_FOLDS:
        fold_site = site[site["fold"] == fold].copy()
        recomputed["site"][fold] = _site_metrics(fold_site, threshold)
    for fold in ZONE_FOLDS:
        start, end = (
            (pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01"))
            if fold == "2025"
            else (pd.Timestamp("2026-01-01"), pd.Timestamp("2026-07-01"))
        )
        fold_zone = zone[
            (zone["target_date"] >= start) & (zone["target_date"] < end)
        ].copy()
        zone_metrics, groups = _zone_metrics(fold_zone)
        recomputed["zone"][fold] = zone_metrics
        recomputed["end_to_end"][fold] = _end_to_end(
            site[site["fold"] == fold].copy(), groups, threshold
        )

    comparison = _comparison_rows(recomputed, validation)
    max_delta = max(row["absolute_delta"] for row in comparison)
    report = {
        "protocol": {
            "source": "saved prediction-level OOF rows",
            "independent_of_primary_metric_module": True,
            "threshold_mode": threshold_mode,
            "threshold": threshold,
            "tolerance": args.tolerance,
        },
        "recomputed": recomputed,
        "reported_comparison": comparison,
        "max_absolute_delta": max_delta,
        "status": "pass" if max_delta <= args.tolerance else "fail",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    args.markdown_output.write_text(_markdown(report), encoding="utf-8")
    print(json.dumps({"status": report["status"], "max_delta": max_delta}, indent=2))


if __name__ == "__main__":
    main()
