"""Development-only negative controls for the site weekly model.

The suite is intentionally separated from candidate search.  Its job is to make
unexpectedly strong shortcuts visible: shuffled labels, non-informative random
features, destroyed entity identity, a top-feature permutation, and a deliberate
future-feature sentinel that must be rejected before training.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score, roc_auc_score

from lct26_access.causality import (
    assert_no_failed_features,
    classify_feature_causality,
)
from lct26_access.features import augment_site_model_frame
from lct26_access.models import (
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

FOLDS = (
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
IDENTITY_COLUMNS = ("site_raw", "site_family", "site_parent_id")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--champion-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def fit_model(
    train_matrix: pd.DataFrame,
    train_target: pd.Series,
    valid_matrix: pd.DataFrame,
    valid_target: pd.Series,
    categorical: list[str],
    *,
    early_stopping_rounds: int = 120,
) -> tuple[LGBMClassifier, float]:
    model = LGBMClassifier(**LGB_WEEKLY_TUNED_PARAMS, n_estimators=1_800)
    started = time.monotonic()
    model.fit(
        train_matrix,
        train_target,
        categorical_feature=categorical,
        eval_X=valid_matrix,
        eval_y=valid_target,
        eval_metric="average_precision",
        callbacks=[
            early_stopping(early_stopping_rounds, verbose=False),
            log_evaluation(0),
        ],
    )
    return model, round(time.monotonic() - started, 3)


def fit_fixed_model(
    train_matrix: pd.DataFrame,
    train_target: pd.Series,
    categorical: list[str],
    *,
    iterations: int,
) -> tuple[LGBMClassifier, float]:
    """Fit without touching validation labels or selecting an iteration."""

    model = LGBMClassifier(**LGB_WEEKLY_TUNED_PARAMS, n_estimators=iterations)
    started = time.monotonic()
    model.fit(
        train_matrix,
        train_target,
        categorical_feature=categorical,
    )
    return model, round(time.monotonic() - started, 3)


def shuffled_identities(frame: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    result = frame.copy()
    present = [column for column in IDENTITY_COLUMNS if column in result.columns]
    # Shuffle the identifier tuple inside each date.  This keeps daily category
    # frequencies but severs stable entity identity across time.
    for indices in result.groupby("target_date", sort=False).groups.values():
        index = np.asarray(list(indices))
        permutation = rng.permutation(index)
        result.loc[index, present] = result.loc[permutation, present].to_numpy()
    return result


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    requested = list(metadata["variants"]["lgb_weekly_tuned"]["features"])
    assert_no_failed_features(requested, model_level="site")
    sentinel = classify_feature_causality("intrusion_events_lead1", model_level="site")
    if sentinel.causal_status != "fail":
        raise AssertionError("Deliberate future-feature sentinel was not rejected")

    frame = augment_site_model_frame(args.site_features, weekly=True)
    frame = frame[frame["target"].notna()].copy()
    frame["target_date"] = pd.to_datetime(frame["target_date"])
    if (
        frame.loc[frame["target_date"] < pd.Timestamp("2026-01-01"), "target_date"]
        >= pd.Timestamp("2026-01-01")
    ).any():
        raise AssertionError("Frozen holdout entered development data")
    stored = pd.read_parquet(args.champion_oof)
    stored = stored[stored["fold"].isin({fold for fold, _, _ in FOLDS})].copy()
    stored["target_date"] = pd.to_datetime(stored["target_date"])

    reports: dict[str, list[dict[str, Any]]] = {
        name: []
        for name in (
            "reference_retrained",
            "shuffled_train_labels",
            "independent_random_feature",
            "shuffled_entity_identity",
            "top_feature_permuted_at_scoring",
        )
    }
    output_parts: list[pd.DataFrame] = []
    for fold_index, (fold, start, end) in enumerate(FOLDS):
        train_mask = frame["target_date"] < start
        valid_mask = (frame["target_date"] >= start) & (frame["target_date"] < end)
        train_frame = frame.loc[train_mask].copy()
        valid_frame = frame.loc[valid_mask].copy()
        features = [
            feature
            for feature in requested
            if feature in train_frame.columns and train_frame[feature].nunique(dropna=False) > 1
        ]
        categorical = [name for name in SITE_CATEGORICAL if name in features]
        maps = fit_category_maps(train_frame, categorical)
        train_matrix = encode_for_lightgbm(train_frame, features, maps)
        valid_matrix = encode_for_lightgbm(valid_frame, features, maps)
        train_target = train_frame["target"].astype("int8")
        valid_target = valid_frame["target"].astype("int8")

        reference, seconds = fit_model(
            train_matrix, train_target, valid_matrix, valid_target, categorical
        )
        reference_probability = reference.predict_proba(valid_matrix)[:, 1]
        stored_fold = stored[stored["fold"] == fold].sort_values(["site_raw", "target_date"])
        reference_keys = valid_frame[["site_raw", "target_date"]].copy()
        reference_keys["probability"] = reference_probability
        reference_keys = reference_keys.sort_values(["site_raw", "target_date"])
        comparison = reference_keys.merge(
            stored_fold[["site_raw", "target_date", "lgb_weekly_tuned"]],
            on=["site_raw", "target_date"],
            validate="one_to_one",
        )
        maximum_difference = float(
            np.max(np.abs(comparison["probability"] - comparison["lgb_weekly_tuned"]))
        )
        reports["reference_retrained"].append(
            {
                "fold": fold,
                "pr_auc": float(average_precision_score(valid_target, reference_probability)),
                "iterations": int(reference.best_iteration_),
                "seconds": seconds,
                "max_abs_difference_vs_stored": maximum_difference,
            }
        )

        shuffled_draws: list[dict[str, float | int]] = []
        shuffled_probabilities: list[np.ndarray] = []
        for draw in range(5):
            rng = np.random.default_rng(2603 + 100 * fold_index + draw)
            shuffled_target = pd.Series(
                rng.permutation(train_target.to_numpy()), index=train_target.index
            )
            shuffled_model, seconds = fit_fixed_model(
                train_matrix,
                shuffled_target,
                categorical,
                iterations=int(reference.best_iteration_),
            )
            shuffled_probability = shuffled_model.predict_proba(valid_matrix)[:, 1]
            shuffled_probabilities.append(shuffled_probability)
            shuffled_draws.append(
                {
                    "draw": draw,
                    "seed": 2603 + 100 * fold_index + draw,
                    "pr_auc": float(average_precision_score(valid_target, shuffled_probability)),
                    "roc_auc": float(roc_auc_score(valid_target, shuffled_probability)),
                    "seconds": seconds,
                }
            )
        shuffled_probability = np.mean(shuffled_probabilities, axis=0)
        shuffled_scores = [float(draw["pr_auc"]) for draw in shuffled_draws]
        reports["shuffled_train_labels"].append(
            {
                "fold": fold,
                "pr_auc_mean": float(np.mean(shuffled_scores)),
                "pr_auc_min": float(np.min(shuffled_scores)),
                "pr_auc_max": float(np.max(shuffled_scores)),
                "ensemble_of_draws_pr_auc": float(
                    average_precision_score(valid_target, shuffled_probability)
                ),
                "ensemble_of_draws_roc_auc": float(
                    roc_auc_score(valid_target, shuffled_probability)
                ),
                "validation_prevalence": float(valid_target.mean()),
                "iterations_fixed_before_each_draw": int(reference.best_iteration_),
                "draws": shuffled_draws,
            }
        )

        random_train = train_frame.copy()
        random_valid = valid_frame.copy()
        random_train["negative_control_random"] = np.random.default_rng(
            9600 + fold_index
        ).standard_normal(len(random_train))
        random_valid["negative_control_random"] = np.random.default_rng(
            9700 + fold_index
        ).standard_normal(len(random_valid))
        random_features = [*features, "negative_control_random"]
        random_train_matrix = encode_for_lightgbm(random_train, random_features, maps)
        random_valid_matrix = encode_for_lightgbm(random_valid, random_features, maps)
        random_model, seconds = fit_model(
            random_train_matrix,
            train_target,
            random_valid_matrix,
            valid_target,
            categorical,
        )
        random_probability = random_model.predict_proba(random_valid_matrix)[:, 1]
        reports["independent_random_feature"].append(
            {
                "fold": fold,
                "pr_auc": float(average_precision_score(valid_target, random_probability)),
                "delta_vs_reference": float(
                    average_precision_score(valid_target, random_probability)
                    - average_precision_score(valid_target, reference_probability)
                ),
                "iterations": int(random_model.best_iteration_),
                "seconds": seconds,
            }
        )

        identity_train = shuffled_identities(train_frame, np.random.default_rng(12603 + fold_index))
        identity_valid = shuffled_identities(valid_frame, np.random.default_rng(13603 + fold_index))
        identity_maps = fit_category_maps(identity_train, categorical)
        identity_train_matrix = encode_for_lightgbm(identity_train, features, identity_maps)
        identity_valid_matrix = encode_for_lightgbm(identity_valid, features, identity_maps)
        identity_model, seconds = fit_model(
            identity_train_matrix,
            train_target,
            identity_valid_matrix,
            valid_target,
            categorical,
        )
        identity_probability = identity_model.predict_proba(identity_valid_matrix)[:, 1]
        reports["shuffled_entity_identity"].append(
            {
                "fold": fold,
                "pr_auc": float(average_precision_score(valid_target, identity_probability)),
                "delta_vs_reference": float(
                    average_precision_score(valid_target, identity_probability)
                    - average_precision_score(valid_target, reference_probability)
                ),
                "iterations": int(identity_model.best_iteration_),
                "seconds": seconds,
            }
        )

        gain = reference.booster_.feature_importance(importance_type="gain")
        top_feature = features[int(np.argmax(gain))]
        permuted_valid = valid_frame.copy()
        permuted_valid[top_feature] = np.random.default_rng(15603 + fold_index).permutation(
            permuted_valid[top_feature].to_numpy()
        )
        permuted_matrix = encode_for_lightgbm(permuted_valid, features, maps)
        permuted_probability = reference.predict_proba(permuted_matrix)[:, 1]
        reports["top_feature_permuted_at_scoring"].append(
            {
                "fold": fold,
                "top_feature": top_feature,
                "gain_share": float(gain.max() / gain.sum()),
                "pr_auc": float(average_precision_score(valid_target, permuted_probability)),
                "delta_vs_reference": float(
                    average_precision_score(valid_target, permuted_probability)
                    - average_precision_score(valid_target, reference_probability)
                ),
            }
        )

        output = valid_frame[["site_raw", "target_date", "target"]].copy()
        output["fold"] = fold
        output["reference"] = reference_probability
        output["shuffled_labels"] = shuffled_probability
        output["random_feature"] = random_probability
        output["shuffled_identity"] = identity_probability
        output["top_feature_permuted"] = permuted_probability
        output_parts.append(output)

    random_deltas = [
        float(item["delta_vs_reference"]) for item in reports["independent_random_feature"]
    ]
    reference_pr = {
        str(item["fold"]): float(item["pr_auc"]) for item in reports["reference_retrained"]
    }
    shuffled_signal_collapsed = all(
        abs(float(item["ensemble_of_draws_roc_auc"]) - 0.5) < 0.06
        and float(item["ensemble_of_draws_pr_auc"]) < reference_pr[str(item["fold"])] - 0.25
        for item in reports["shuffled_train_labels"]
    )
    decision = {
        "leakage_sentinel_rejected": True,
        "reference_reproduction_max_abs_difference": max(
            float(item["max_abs_difference_vs_stored"]) for item in reports["reference_retrained"]
        ),
        "random_feature_passed": min(random_deltas) <= 0.0005,
        "shuffled_label_signal_collapsed": shuffled_signal_collapsed,
    }
    report = {
        "experiment_id": "EXP_008_negative_controls",
        "status": "diagnostic",
        "protocol": {
            "folds": [fold for fold, _, _ in FOLDS],
            "model": "lgb_weekly_tuned component only",
            "holdout_2026h1_accessed": False,
            "category_maps": "fit on rows strictly before each fold",
            "feature_eligibility": "fit on rows strictly before each fold",
        },
        "controls": reports,
        "future_feature_sentinel": sentinel.to_dict(),
        "protocol_correction": (
            "A discarded first draft early-stopped shuffled-label models against true validation "
            "labels, which selected a lucky random iteration. Final results fix tree count from "
            "the reference model and average five label permutations without validation-driven "
            "iteration selection."
        ),
        "shuffled_label_interpretation": (
            "Finite high-dimensional shuffled-label fits need not have PR-AUC exactly equal to "
            "prevalence. The fail-closed gate requires near-chance ROC-AUC and a PR-AUC collapse "
            "of at least 0.25 versus the exactly reproduced reference component."
        ),
        "decision": decision,
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.concat(output_parts, ignore_index=True).to_parquet(
        args.output_dir / "negative_control_oof.parquet", index=False
    )
    (args.output_dir / "negative_control_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not decision["shuffled_label_signal_collapsed"]:
        raise SystemExit("Shuffled-label control is unexpectedly predictive")


if __name__ == "__main__":
    main()
