"""Post-training robustness audit for Model 3.

The audit never retunes a model on the final 2026H1 holdout.  It checks target
episode semantics, feature availability, calibration transfer, ensemble
disagreement, temporal drift, dispatcher workload, and end-to-end
site-to-zone retrieval.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import polars as pl
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)

from lct26_access.constants import INTRUSION_VALUES, SECURITY_SYSTEM
from lct26_access.features import EVENT_CORE

DEVELOPMENT_FOLDS = ("2024", "2025")
FINAL_HOLDOUT_FOLD = "2026H1"
CALENDAR_TARGET_PREFIXES = (
    "target_dow",
    "target_month",
    "target_doy",
    "target_weekend",
    "target_holiday",
    "target_preholiday",
    "target_postholiday",
    "target_workday",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--security-dir", type=Path, required=True)
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--site-oof", type=Path, required=True)
    parser.add_argument("--site-metadata", type=Path, required=True)
    parser.add_argument("--zone-oof", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (pd.Timestamp,)):
        return value.isoformat()
    return value


def expected_calibration_error(
    target: np.ndarray,
    probability: np.ndarray,
    *,
    bins: int = 10,
) -> float:
    """Equal-frequency expected calibration error."""

    order = np.argsort(probability)
    chunks = np.array_split(order, bins)
    total = max(1, target.size)
    return float(
        sum(
            chunk.size
            / total
            * abs(float(target[chunk].mean()) - float(probability[chunk].mean()))
            for chunk in chunks
            if chunk.size
        )
    )


def probability_metrics(target: np.ndarray, probability: np.ndarray) -> dict[str, float]:
    clipped = np.clip(probability.astype(float), 1e-8, 1 - 1e-8)
    return {
        "brier": float(brier_score_loss(target, clipped)),
        "logloss": float(log_loss(target, clipped)),
        "ece_10_equal_frequency": expected_calibration_error(target, clipped),
    }


def _logit(probability: np.ndarray) -> np.ndarray:
    clipped = np.clip(probability.astype(float), 1e-6, 1 - 1e-6)
    return np.log(clipped / (1 - clipped)).reshape(-1, 1)


def calibration_audit(oof: pd.DataFrame) -> dict[str, Any]:
    """Choose a calibration candidate on 2024->2025 and report 2026 transfer."""

    train = oof[oof["fold"] == "2024"]
    selection = oof[oof["fold"] == "2025"]
    development = oof[oof["fold"].isin(DEVELOPMENT_FOLDS)]
    holdout = oof[oof["fold"] == FINAL_HOLDOUT_FOLD]
    if any(frame.empty for frame in (train, selection, development, holdout)):
        raise ValueError("Calibration audit requires 2024, 2025, and 2026H1 OOF rows")

    platt = LogisticRegression(C=1_000_000.0, solver="lbfgs", random_state=2603)
    platt.fit(_logit(train["ensemble_probability"].to_numpy()), train["target"])
    isotonic = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
    isotonic.fit(train["ensemble_probability"], train["target"])

    selection_predictions = {
        "raw": selection["ensemble_probability"].to_numpy(dtype=float),
        "platt": platt.predict_proba(
            _logit(selection["ensemble_probability"].to_numpy())
        )[:, 1],
        "isotonic": isotonic.predict(selection["ensemble_probability"]),
    }
    selection_metrics = {
        name: probability_metrics(selection["target"].to_numpy(dtype=np.int8), values)
        for name, values in selection_predictions.items()
    }
    raw_metrics = selection_metrics["raw"]
    eligible = [
        name
        for name in ("platt", "isotonic")
        if selection_metrics[name]["brier"] < raw_metrics["brier"]
        and selection_metrics[name]["logloss"] < raw_metrics["logloss"]
    ]
    selected_method = min(
        eligible,
        key=lambda name: (
            selection_metrics[name]["brier"],
            selection_metrics[name]["logloss"],
        ),
        default="raw",
    )

    final_platt = LogisticRegression(C=1_000_000.0, solver="lbfgs", random_state=2603)
    final_platt.fit(
        _logit(development["ensemble_probability"].to_numpy()), development["target"]
    )
    final_isotonic = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
    final_isotonic.fit(development["ensemble_probability"], development["target"])
    holdout_predictions = {
        "raw": holdout["ensemble_probability"].to_numpy(dtype=float),
        "platt": final_platt.predict_proba(
            _logit(holdout["ensemble_probability"].to_numpy())
        )[:, 1],
        "isotonic": final_isotonic.predict(holdout["ensemble_probability"]),
    }
    holdout_metrics = {
        name: probability_metrics(holdout["target"].to_numpy(dtype=np.int8), values)
        for name, values in holdout_predictions.items()
    }
    return {
        "selection_protocol": (
            "fit on 2024, choose on 2025 only; refit chosen family on 2024+2025; "
            "2026H1 is report-only"
        ),
        "selection_2025": selection_metrics,
        "selected_method_without_holdout": selected_method,
        "holdout_2026H1": holdout_metrics,
        "adoption_rule": (
            "adopt only if both Brier and logloss improve on 2025; holdout is never "
            "used to select the method"
        ),
    }


def target_episode_audit(security_dir: Path, gap_minutes: int = 30) -> dict[str, Any]:
    """Measure next-day proxy labels caused only by a cross-midnight episode."""

    alarms = (
        pl.scan_parquet(str(security_dir / "*.parquet"))
        .unique(subset=EVENT_CORE, keep="first")
        .filter(
            (pl.col("тип_инж_системы") == SECURITY_SYSTEM)
            & (pl.col("alarm") == 1)
            & pl.col("значение_датчика").is_in(INTRUSION_VALUES)
        )
        .select(["site_raw", "ts", "ид_канала_данных", "значение_датчика"])
        .collect(engine="streaming")
        .sort(["site_raw", "ts"])
        .with_columns(
            pl.col("ts").shift(1).over("site_raw").alias("previous_ts")
        )
        .with_columns(
            (
                pl.col("previous_ts").is_null()
                | ((pl.col("ts") - pl.col("previous_ts")).dt.total_minutes() > gap_minutes)
            )
            .cast(pl.Int64)
            .cum_sum()
            .over("site_raw")
            .alias("episode_local_id")
        )
    )
    episodes = alarms.group_by(["site_raw", "episode_local_id"]).agg(
        [
            pl.col("ts").min().alias("started_at"),
            pl.col("ts").max().alias("ended_at"),
            pl.len().alias("event_count"),
            pl.col("ид_канала_данных").n_unique().alias("channel_count"),
        ]
    )
    cross_midnight = episodes.filter(
        pl.col("started_at").dt.date() != pl.col("ended_at").dt.date()
    )
    original_days = alarms.select(
        ["site_raw", pl.col("ts").dt.date().alias("date")]
    ).unique()
    episode_start_days = episodes.select(
        ["site_raw", pl.col("started_at").dt.date().alias("date")]
    ).unique()
    continuation_only_days = original_days.join(
        episode_start_days, on=["site_raw", "date"], how="anti"
    )
    return {
        "gap_minutes": gap_minutes,
        "intrusion_proxy_rows": alarms.height,
        "episodes": episodes.height,
        "cross_midnight_episodes": cross_midnight.height,
        "cross_midnight_event_rows": int(cross_midnight["event_count"].sum() or 0),
        "positive_site_days_original": original_days.height,
        "positive_site_days_by_episode_start": episode_start_days.height,
        "continuation_only_site_days": continuation_only_days.height,
        "continuation_only_share_of_positive_days": float(
            continuation_only_days.height / max(1, original_days.height)
        ),
        "interpretation": (
            "continuation_only_site_days are proxy-positive dates that disappear if an "
            "episode is assigned only to its start date"
        ),
    }


def feature_availability_audit(metadata: dict[str, Any]) -> dict[str, Any]:
    variants = metadata["variants"]
    forbidden: dict[str, list[str]] = {}
    reviewed_calendar: dict[str, list[str]] = {}
    for name, spec in variants.items():
        features = list(spec["features"])
        forbidden[name] = sorted(
            feature
            for feature in features
            if (
                feature in {"target", "target_date", "target_next_events", "target_next_zones"}
                or feature.startswith("target_next_")
                or (
                    feature.startswith("target_")
                    and not feature.startswith(CALENDAR_TARGET_PREFIXES)
                )
            )
        )
        reviewed_calendar[name] = sorted(
            feature for feature in features if feature.startswith(CALENDAR_TARGET_PREFIXES)
        )
    return {
        "forecast_cutoff": "end of as_of_date D",
        "prediction_window": "calendar day D+1",
        "forbidden_features_by_variant": forbidden,
        "passed": all(not values for values in forbidden.values()),
        "known_in_advance_calendar_features_by_variant": reviewed_calendar,
        "note": (
            "target_* calendar fields are deterministic properties of D+1; raw D+1 "
            "events and labels are forbidden"
        ),
    }


def _cold_start_subset_metrics(
    frame: pd.DataFrame,
    *,
    score_column: str = "ensemble_probability",
) -> dict[str, Any]:
    if frame.empty:
        return {"rows": 0, "sites": 0}
    target = frame["target"].to_numpy(dtype=np.int8)
    probability = frame[score_column].to_numpy(dtype=float)
    output: dict[str, Any] = {
        "rows": int(frame.shape[0]),
        "sites": int(frame["site_raw"].nunique()),
        "prevalence": float(target.mean()),
        "brier": float(brier_score_loss(target, probability)),
    }
    if np.unique(target).size == 2:
        output["roc_auc"] = float(roc_auc_score(target, probability))
        output["pr_auc"] = float(average_precision_score(target, probability))
    return output


def natural_cold_start_audit(
    site_features: Path,
    oof: pd.DataFrame,
) -> dict[str, Any]:
    frame = pd.read_parquet(
        site_features,
        columns=["site_raw", "date", "site_day_observed"],
    )
    frame["date"] = pd.to_datetime(frame["date"])
    first_grid = frame.groupby("site_raw")["date"].min()
    observed_rows = frame[frame["site_day_observed"] > 0]
    first_observed = observed_rows.groupby("site_raw")["date"].min()
    fold_windows = {
        "2024": (pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
        "2025": (pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
        "2026H1": (pd.Timestamp("2026-01-01"), pd.Timestamp("2026-07-01")),
    }
    new_sites = {
        fold: sorted(
            first_observed[
                (first_observed >= start) & (first_observed < end)
            ].index.astype(str).tolist()
        )
        for fold, (start, end) in fold_windows.items()
    }
    oof = oof.copy()
    oof["site_raw"] = oof["site_raw"].astype(str)
    scores: dict[str, Any] = {}
    score_columns = ["ensemble_probability"]
    if "candidate_probability" in oof:
        score_columns.append("candidate_probability")
    for fold, sites in new_sites.items():
        fold_frame = oof[oof["fold"] == fold]
        unseen = fold_frame[fold_frame["site_raw"].isin(sites)]
        known = fold_frame[~fold_frame["site_raw"].isin(sites)]
        scores[fold] = {
            "unseen_sites": sites,
            "unseen": {
                score: _cold_start_subset_metrics(unseen, score_column=score)
                for score in score_columns
            },
            "already_seen": {
                score: _cold_start_subset_metrics(known, score_column=score)
                for score in score_columns
            },
        }
    return {
        "sites": int(first_grid.size),
        "first_grid_date_min": first_grid.min().date().isoformat(),
        "first_grid_date_max": first_grid.max().date().isoformat(),
        "first_observed_date_min": first_observed.min().date().isoformat(),
        "first_observed_date_max": first_observed.max().date().isoformat(),
        "naturally_new_sites_by_fold": new_sites,
        "natural_cold_start_test_available": any(new_sites.values()),
        "oof_scores": scores,
        "note": (
            "If no site first appears in a validation fold, a true natural unseen-site "
            "score cannot be estimated from this dataset; an identifier ablation is reported "
            "separately instead of inventing cold-start evidence."
        ),
    }


def ensemble_uncertainty_audit(
    oof: pd.DataFrame,
    metadata: dict[str, Any],
) -> dict[str, Any]:
    weights = {
        name: float(weight)
        for name, weight in metadata["ensemble_weights"].items()
        if float(weight) > 0
    }
    matrix = oof.loc[:, list(weights)].to_numpy(dtype=float)
    weight_vector = np.asarray(list(weights.values()), dtype=float)
    weight_vector /= weight_vector.sum()
    mean = matrix @ weight_vector
    disagreement = np.sqrt(((matrix - mean[:, None]) ** 2) @ weight_vector)
    audited = oof.copy()
    audited["ensemble_disagreement"] = disagreement
    audited["absolute_probability_error"] = np.abs(
        audited["target"] - audited["ensemble_probability"]
    )
    output: dict[str, Any] = {
        "active_components": weights,
        "definition": "weighted standard deviation of active component probabilities",
        "by_fold": {},
    }
    threshold = float(
        metadata["decision_thresholds_from_2024_2025"]["balanced_f1"]
    )
    for fold, group in audited.groupby("fold", sort=False):
        bins = pd.qcut(
            group["ensemble_disagreement"],
            q=4,
            labels=False,
            duplicates="drop",
        )
        misclassified = (
            (group["ensemble_probability"] >= threshold).astype(int)
            != group["target"].astype(int)
        ).astype(int)
        error_auc = (
            float(roc_auc_score(misclassified, group["ensemble_disagreement"]))
            if misclassified.nunique() == 2
            else None
        )
        quartiles = []
        for quartile in sorted(bins.dropna().unique()):
            mask = bins == quartile
            quartiles.append(
                {
                    "quartile": int(quartile) + 1,
                    "rows": int(mask.sum()),
                    "mean_disagreement": float(
                        group.loc[mask, "ensemble_disagreement"].mean()
                    ),
                    "mean_absolute_probability_error": float(
                        group.loc[mask, "absolute_probability_error"].mean()
                    ),
                    "classification_error_rate": float(misclassified.loc[mask].mean()),
                }
            )
        output["by_fold"][fold] = {
            "mean_disagreement": float(group["ensemble_disagreement"].mean()),
            "p95_disagreement": float(
                group["ensemble_disagreement"].quantile(0.95)
            ),
            "error_detection_roc_auc": error_auc,
            "quartiles": quartiles,
        }
    return output


def _population_stability_index(reference: np.ndarray, current: np.ndarray) -> float:
    edges = np.unique(np.quantile(reference, np.linspace(0, 1, 11)))
    if edges.size < 3:
        return 0.0
    edges[0] = -np.inf
    edges[-1] = np.inf
    reference_counts = np.histogram(reference, bins=edges)[0].astype(float)
    current_counts = np.histogram(current, bins=edges)[0].astype(float)
    reference_share = np.clip(reference_counts / reference_counts.sum(), 1e-6, None)
    current_share = np.clip(current_counts / current_counts.sum(), 1e-6, None)
    return float(np.sum((current_share - reference_share) * np.log(current_share / reference_share)))


def temporal_drift_audit(oof: pd.DataFrame) -> dict[str, Any]:
    audited = oof.copy()
    audited["target_date"] = pd.to_datetime(audited["target_date"])
    audited["month"] = audited["target_date"].dt.to_period("M").astype(str)
    monthly = (
        audited.groupby("month", sort=True)
        .agg(
            rows=("target", "size"),
            prevalence=("target", "mean"),
            mean_prediction=("ensemble_probability", "mean"),
        )
        .reset_index()
    )
    reference = audited.loc[
        audited["fold"] == "2024", "ensemble_probability"
    ].to_numpy(dtype=float)
    fold_psi = {
        fold: _population_stability_index(
            reference, group["ensemble_probability"].to_numpy(dtype=float)
        )
        for fold, group in audited.groupby("fold", sort=False)
    }
    return {
        "prediction_psi_vs_2024": fold_psi,
        "monthly": monthly.to_dict(orient="records"),
        "interpretation": "PSI monitors score-distribution shift; it is not a quality metric.",
    }


def workload_audit(oof: pd.DataFrame, metadata: dict[str, Any]) -> dict[str, Any]:
    threshold_mode = str(metadata.get("default_threshold_mode", "balanced_f1"))
    threshold = float(
        metadata["decision_thresholds_from_2024_2025"][threshold_mode]
    )
    holdout = oof[oof["fold"] == FINAL_HOLDOUT_FOLD].copy()
    holdout["alert"] = holdout["ensemble_probability"] >= threshold
    holdout["target_date"] = pd.to_datetime(holdout["target_date"])
    daily = holdout.groupby("target_date", sort=True).agg(
        candidate_sites=("site_raw", "size"),
        alerts=("alert", "sum"),
        proxy_positive_sites=("target", "sum"),
    )
    y = holdout["target"].to_numpy(dtype=np.int8)
    predicted = holdout["alert"].to_numpy(dtype=bool)
    false_proxy_alerts = int(np.sum(predicted & (y == 0)))
    return {
        "fold": FINAL_HOLDOUT_FOLD,
        "threshold_mode": threshold_mode,
        "threshold": threshold,
        "days": int(daily.shape[0]),
        "mean_candidate_sites_per_day": float(daily["candidate_sites"].mean()),
        "mean_alerts_per_day": float(daily["alerts"].mean()),
        "p95_alerts_per_day": float(daily["alerts"].quantile(0.95)),
        "max_alerts_per_day": int(daily["alerts"].max()),
        "total_alerts": int(predicted.sum()),
        "proxy_true_alerts": int(np.sum(predicted & (y == 1))),
        "proxy_false_alerts": false_proxy_alerts,
        "precision": float(precision_score(y, predicted, zero_division=0)),
        "recall": float(recall_score(y, predicted, zero_division=0)),
        "f1": float(f1_score(y, predicted, zero_division=0)),
        "reviews_avoided_vs_review_all": int(y.size - predicted.sum()),
        "review_reduction_vs_all": float(1 - predicted.mean()),
        "wording_note": (
            "true/false here means agreement with the SCADA proxy target, not a "
            "dispatcher-confirmed real intrusion outcome"
        ),
    }


def end_to_end_localisation_audit(
    site_oof: pd.DataFrame,
    zone_oof_path: Path,
    metadata: dict[str, Any],
) -> dict[str, Any]:
    zone = pd.read_parquet(zone_oof_path)
    zone["target_date"] = pd.to_datetime(zone["target_date"])
    zone["fold"] = np.where(
        zone["target_date"] < pd.Timestamp("2026-01-01"), "2025", "2026H1"
    )
    zone = zone.sort_values(
        ["target_date", "site_raw", "blend_rank"], ascending=[True, True, False]
    )
    zone["zone_rank"] = zone.groupby(["target_date", "site_raw"]).cumcount() + 1
    positive = zone[zone["target"] == 1]
    first_positive = (
        positive.groupby(["fold", "target_date", "site_raw"], sort=False)["zone_rank"]
        .min()
        .rename("first_positive_zone_rank")
        .reset_index()
    )
    site = site_oof.copy()
    site["target_date"] = pd.to_datetime(site["target_date"])
    site = site.sort_values(
        ["fold", "target_date", "ensemble_probability"],
        ascending=[True, True, False],
    )
    site["site_rank"] = site.groupby(["fold", "target_date"]).cumcount() + 1
    groups = first_positive.merge(
        site[
            ["fold", "target_date", "site_raw", "site_rank", "ensemble_probability"]
        ],
        on=["fold", "target_date", "site_raw"],
        how="left",
        validate="one_to_one",
    )
    if groups["site_rank"].isna().any():
        raise ValueError("Some positive zone groups have no matching site OOF prediction")
    output: dict[str, Any] = {
        "definition": (
            "A positive site-day is retrieved only when it is inside the daily site "
            "budget and at least one true proxy-positive zone is inside the zone budget."
        ),
        "by_fold": {},
    }
    threshold_mode = str(metadata.get("default_threshold_mode", "balanced_f1"))
    operating_threshold = float(
        metadata["decision_thresholds_from_2024_2025"][threshold_mode]
    )
    for fold, fold_frame in groups.groupby("fold", sort=False):
        fold_sites = site[site["fold"] == fold].copy()
        fold_sites["alert"] = (
            fold_sites["ensemble_probability"] >= operating_threshold
        )
        daily_alerts = fold_sites.groupby("target_date")["alert"].sum()
        threshold_selected = (
            fold_frame["ensemble_probability"] >= operating_threshold
        )
        metrics: dict[str, Any] = {
            "positive_site_days": int(fold_frame.shape[0]),
            "operating_threshold_mode": threshold_mode,
            "operating_site_threshold": operating_threshold,
            "mean_alerted_sites_per_day": float(daily_alerts.mean()),
            "site_recall_at_operating_threshold": float(threshold_selected.mean()),
        }
        for zone_budget in (1, 3, 5, 10):
            captured = threshold_selected & (
                fold_frame["first_positive_zone_rank"] <= zone_budget
            )
            metrics[
                f"end_to_end_hit_at_operating_threshold_zones_{zone_budget}"
            ] = float(captured.mean())
        for site_budget in (3, 5, 10):
            for zone_budget in (1, 3, 5, 10):
                captured = (
                    (fold_frame["site_rank"] <= site_budget)
                    & (fold_frame["first_positive_zone_rank"] <= zone_budget)
                )
                metrics[f"hit_rate_sites_{site_budget}_zones_{zone_budget}"] = float(
                    captured.mean()
                )
        output["by_fold"][fold] = metrics
    return output


def main() -> None:
    args = parse_args()
    site_oof = pd.read_parquet(args.site_oof)
    metadata = json.loads(args.site_metadata.read_text(encoding="utf-8"))
    report = {
        "protocol": {
            "development_folds": list(DEVELOPMENT_FOLDS),
            "final_holdout": FINAL_HOLDOUT_FOLD,
            "holdout_policy": (
                "2026H1 is used for final reporting only; no feature, weight, threshold, "
                "calibration-family, or iteration choice is made from it."
            ),
        },
        "target_episode_audit": target_episode_audit(args.security_dir),
        "feature_availability": feature_availability_audit(metadata),
        "natural_cold_start": natural_cold_start_audit(
            args.site_features, site_oof
        ),
        "calibration": calibration_audit(site_oof),
        "ensemble_uncertainty": ensemble_uncertainty_audit(site_oof, metadata),
        "temporal_drift": temporal_drift_audit(site_oof),
        "dispatcher_workload": workload_audit(site_oof, metadata),
        "end_to_end_localisation": end_to_end_localisation_audit(
            site_oof, args.zone_oof, metadata
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(_jsonable(report), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(_jsonable(report), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
