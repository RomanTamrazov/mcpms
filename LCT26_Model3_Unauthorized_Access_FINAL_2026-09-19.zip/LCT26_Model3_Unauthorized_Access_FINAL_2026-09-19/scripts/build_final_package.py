"""Build the compact, reproducible final handoff for LCT 2026 Model 3."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import zipfile
from datetime import UTC, datetime
from pathlib import Path

DEFAULT_NAME = "LCT26_Model3_Unauthorized_Access_FINAL_2026-09-19"
EVIDENCE_SUFFIXES = {".csv", ".json", ".md"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("deliverables"))
    parser.add_argument("--package-name", default=DEFAULT_NAME)
    return parser.parse_args()


def copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def copy_tree(
    source: Path,
    destination: Path,
    *,
    suffixes: set[str] | None = None,
) -> None:
    for path in sorted(source.rglob("*")):
        if not path.is_file():
            continue
        if ".DS_Store" in path.parts or "__pycache__" in path.parts:
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        if suffixes is not None and path.suffix not in suffixes:
            continue
        copy_file(path, destination / path.relative_to(source))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_manifest(package_dir: Path) -> list[dict[str, object]]:
    manifest_path = package_dir / "MANIFEST.sha256"
    entries: list[dict[str, object]] = []
    lines: list[str] = []
    for path in sorted(package_dir.rglob("*")):
        if not path.is_file() or path == manifest_path:
            continue
        relative = path.relative_to(package_dir).as_posix()
        checksum = sha256(path)
        size = path.stat().st_size
        entries.append({"path": relative, "bytes": size, "sha256": checksum})
        lines.append(f"{checksum}  {relative}")
    manifest_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return entries


def build_archive(package_dir: Path, archive_path: Path) -> None:
    with zipfile.ZipFile(
        archive_path,
        mode="x",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for path in sorted(package_dir.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(package_dir.parent))


def main() -> None:
    args = parse_args()
    project_root = Path(__file__).resolve().parents[1]
    output_dir = (project_root / args.output_dir).resolve()
    package_dir = output_dir / args.package_name
    archive_path = output_dir / f"{args.package_name}.zip"
    if package_dir.exists() or archive_path.exists():
        raise FileExistsError(
            "Refusing to overwrite an existing final delivery: "
            f"{package_dir} or {archive_path}"
        )

    package_dir.mkdir(parents=True)

    root_files = (
        "pyproject.toml",
        "requirements-runtime.txt",
        "requirements.txt",
        "requirements.lock",
    )
    for name in root_files:
        copy_file(project_root / name, package_dir / name)
    copy_file(project_root / "FINAL_DELIVERY_README.md", package_dir / "README_FIRST.md")
    copy_file(project_root / "README.md", package_dir / "README_PROJECT.md")

    for name in ("configs", "docs", "examples", "schemas", "src", "scripts", "tests"):
        copy_tree(project_root / name, package_dir / name)
    copy_tree(project_root / "reports", package_dir / "reports")

    accepted_runtime = (
        project_root
        / "artifacts/experiments/research/EXP_015_minimal_runtime_no_catboost"
        / "runtime_candidate"
    )
    copy_tree(accepted_runtime / "site", package_dir / "models/site")
    copy_tree(accepted_runtime / "zone", package_dir / "models/zone")
    copy_file(
        accepted_runtime / "build_report.json",
        package_dir / "reports/runtime_build_report.json",
    )

    accepted_predictions = (
        project_root
        / "artifacts/experiments/research/EXP_015_minimal_runtime_no_catboost"
        / "predictions"
    )
    copy_tree(accepted_predictions, package_dir / "example_predictions")

    research_source = project_root / "artifacts/experiments/research"
    copy_tree(
        research_source,
        package_dir / "research_evidence",
        suffixes=EVIDENCE_SUFFIXES,
    )

    package_metadata = {
        "package_name": args.package_name,
        "built_on": datetime.now(UTC).date().isoformat(),
        "site_model_version": "model3-site-v2.1-updated-catalog",
        "zone_model_version": "model3-zone-v1.1-updated-catalog",
        "threshold_mode": "operational_recall_80",
        "threshold": 0.35187665923163414,
        "runtime_catboost_included": False,
        "raw_dataset_included": False,
        "prepared_feature_parquets_included": False,
        "oof_parquets_included": False,
        "omission_reason": (
            "Large raw, prepared, and OOF data are reproducible from the supplied "
            "scripts and are intentionally excluded from the transferable runtime."
        ),
    }
    metadata_path = package_dir / "PACKAGE_METADATA.json"
    metadata_path.write_text(
        json.dumps(package_metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    entries = build_manifest(package_dir)
    build_archive(package_dir, archive_path)
    report = {
        "package_dir": str(package_dir),
        "archive": str(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "archive_sha256": sha256(archive_path),
        "manifest_files": len(entries),
        "uncompressed_manifest_bytes": sum(int(item["bytes"]) for item in entries),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
