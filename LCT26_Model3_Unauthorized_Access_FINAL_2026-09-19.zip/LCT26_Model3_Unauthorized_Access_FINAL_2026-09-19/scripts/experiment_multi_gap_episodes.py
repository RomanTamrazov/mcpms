"""Test compact multi-resolution intrusion-episode features.

Episode summaries at 5/10/15/60/120-minute gaps are computed per calendar day,
so no episode may cross the D to D+1 forecast boundary.  Candidate blend weight
is selected on 2022/2023 and confirmed on 2024/2025.  Raw 2026 events and the
frozen 2026H1 holdout are never loaded.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import polars as pl
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score, brier_score_loss

from lct26_access.features import (
    _daily_intrusion_episode_features,
    _security_frame,
    augment_site_model_frame,
)
from lct26_access.models import (
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

FOLDS = (
    ("2022", pd.Timestamp("2022-01-01"), pd.Timestamp("2023-01-01")),
    ("2023", pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
SELECTION_FOLDS = ("2022", "2023")
CONFIRMATION_FOLDS = ("2024", "2025")
GAPS = (5, 10, 15, 60, 120)
DAILY_COLUMNS = (
    "intrusion_episode_count",
    "intrusion_multi_event_episodes",
    "intrusion_motion_contact_episodes",
    "intrusion_episode_max_events",
    "intrusion_episode_mean_events",
    "intrusion_episode_max_channels",
    "intrusion_episode_max_zones",
    "intrusion_episode_max_sensor_types",
    "intrusion_episode_max_duration_minutes",
    "intrusion_zone_transitions",
    "intrusion_episode_burstiness",
)
ROLLING_COLUMNS = (
    "intrusion_episode_count",
    "intrusion_multi_event_episodes",
    "intrusion_episode_max_events",
    "intrusion_episode_max_duration_minutes",
    "intrusion_zone_transitions",
    "intrusion_episode_burstiness",
)
MIN_CONFIRMATION_WORST_GAIN = 0.0005
MAX_CONFIRMATION_BRIER_INCREASE = 0.0001


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--security-dir", type=Path, required=True)
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--baseline-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def build_multi_gap_daily(security_dir: Path) -> pd.DataFrame:
    by_gap: dict[int, list[pl.DataFrame]] = {gap: [] for gap in GAPS}
    for path in sorted(security_dir.glob("*.parquet")):
        if int(path.stem) >= 2026:
            continue
        security = _security_frame(path).with_columns(
            pl.col("тег_инженерной_системы")
            .str.strip_suffix(".")
            .str.replace(r"\.[^.]+$", "")
            .alias("zone_key")
        )
        for gap in GAPS:
            summary = _daily_intrusion_episode_features(security, gap_minutes=gap)
            renamed = summary.select(
                "site_raw",
                "site_family",
                "date",
                *[pl.col(column).alias(f"{column}_gap{gap}") for column in DAILY_COLUMNS],
            )
            by_gap[gap].append(renamed)
        print(f"episode summaries year={path.stem}", flush=True)

    output: pd.DataFrame | None = None
    keys = ["site_raw", "site_family", "date"]
    for gap in GAPS:
        part = pl.concat(by_gap[gap]).to_pandas()
        output = part if output is None else output.merge(part, on=keys, validate="one_to_one")
    if output is None:
        raise RuntimeError("No security files found for multi-gap episode experiment")
    output["date"] = pd.to_datetime(output["date"])
    return output


def add_multi_gap_features(
    frame: pd.DataFrame,
    daily: pd.DataFrame,
) -> tuple[pd.DataFrame, list[str]]:
    keys = ["site_raw", "site_family", "date"]
    frame = frame.merge(daily, on=keys, how="left", validate="many_to_one")
    daily_names = [f"{column}_gap{gap}" for gap in GAPS for column in DAILY_COLUMNS]
    frame[daily_names] = frame[daily_names].fillna(0)
    frame = frame.sort_values(["site_raw", "date"]).reset_index(drop=True)
    groups = frame.groupby("site_raw", sort=False)
    extra: dict[str, pd.Series] = {}
    for gap in GAPS:
        for column in ROLLING_COLUMNS:
            source = f"{column}_gap{gap}"
            for window in (7, 28):
                extra[f"{source}_mean{window}"] = (
                    groups[source]
                    .rolling(window, min_periods=1)
                    .mean()
                    .reset_index(level=0, drop=True)
                )
    for gap in (5, 10, 15, 60):
        extra[f"episode_count_ratio_gap{gap}_120"] = frame[f"intrusion_episode_count_gap{gap}"] / (
            frame["intrusion_episode_count_gap120"] + 1.0
        )
        extra[f"max_duration_ratio_gap{gap}_120"] = frame[
            f"intrusion_episode_max_duration_minutes_gap{gap}"
        ] / (frame["intrusion_episode_max_duration_minutes_gap120"] + 1.0)
    extra_names = sorted(extra)
    frame = pd.concat([frame, pd.DataFrame(extra, index=frame.index)], axis=1)
    return frame, [*daily_names, *extra_names]


def fold_metrics(frame: pd.DataFrame, score_column: str) -> dict[str, dict[str, float]]:
    return {
        str(fold): {
            "pr_auc": float(average_precision_score(group["target"], group[score_column])),
            "brier": float(brier_score_loss(group["target"], group[score_column])),
        }
        for fold, group in frame.groupby("fold", sort=True)
    }


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    daily = build_multi_gap_daily(args.security_dir)
    base = augment_site_model_frame(args.site_features, weekly=True)
    base = base[base["target"].notna()].copy()
    base["target_date"] = pd.to_datetime(base["target_date"])
    base = base[base["target_date"] < pd.Timestamp("2026-01-01")]
    frame, added = add_multi_gap_features(base, daily)
    requested = [
        *metadata["variants"]["lgb_weekly_tuned"]["features"],
        *added,
    ]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frame[["site_raw", "site_family", "date", *added]].to_parquet(
        args.output_dir / "multi_gap_daily_features.parquet", index=False
    )

    parts: list[pd.DataFrame] = []
    fit_reports: list[dict[str, Any]] = []
    for fold, start, end in FOLDS:
        train = frame["target_date"] < start
        valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
        features = [
            feature
            for feature in requested
            if feature in frame.columns and frame.loc[train, feature].nunique(dropna=False) > 1
        ]
        categorical = [name for name in SITE_CATEGORICAL if name in features]
        maps = fit_category_maps(frame.loc[train], categorical)
        train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
        valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
        model = LGBMClassifier(**LGB_WEEKLY_TUNED_PARAMS, n_estimators=1_800)
        started = time.monotonic()
        model.fit(
            train_matrix,
            frame.loc[train, "target"].astype("int8"),
            categorical_feature=categorical,
            eval_X=valid_matrix,
            eval_y=frame.loc[valid, "target"].astype("int8"),
            eval_metric="average_precision",
            callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
        )
        output = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
        output["fold"] = fold
        output["multi_gap_probability"] = model.predict_proba(valid_matrix)[:, 1]
        parts.append(output)
        fit_reports.append(
            {
                "fold": fold,
                "train_rows": int(train.sum()),
                "validation_rows": int(valid.sum()),
                "feature_count": len(features),
                "added_feature_count": len(added),
                "iterations": int(model.best_iteration_),
                "fit_seconds": round(time.monotonic() - started, 3),
            }
        )
        print(f"model completed fold={fold}", flush=True)
    candidate = pd.concat(parts, ignore_index=True)

    baseline = pd.read_parquet(args.baseline_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])
    if (baseline["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered multi-gap experiment")
    key = ["site_raw", "target_date", "target", "fold"]
    comparison = baseline[key + ["ensemble_probability"]].merge(
        candidate,
        on=key,
        validate="one_to_one",
    )
    baseline_metrics = fold_metrics(comparison, "ensemble_probability")
    trials: list[dict[str, Any]] = []
    best_key: tuple[float, float, float] | None = None
    selected_weight = 0.0
    for weight in np.linspace(0.0, 0.5, 21):
        comparison["trial_probability"] = (1.0 - weight) * comparison[
            "ensemble_probability"
        ] + weight * comparison["multi_gap_probability"]
        trial_metrics = fold_metrics(
            comparison[comparison["fold"].isin(SELECTION_FOLDS)],
            "trial_probability",
        )
        deltas = {
            fold: trial_metrics[fold]["pr_auc"] - baseline_metrics[fold]["pr_auc"]
            for fold in SELECTION_FOLDS
        }
        key_value = (
            min(deltas.values()),
            float(np.mean(list(deltas.values()))),
            -float(weight),
        )
        trials.append(
            {
                "candidate_weight": float(weight),
                "selection_metrics": trial_metrics,
                "selection_pr_auc_deltas": deltas,
            }
        )
        if best_key is None or key_value > best_key:
            best_key = key_value
            selected_weight = float(weight)
    selected_trial = next(trial for trial in trials if trial["candidate_weight"] == selected_weight)
    comparison["candidate_probability"] = (1.0 - selected_weight) * comparison[
        "ensemble_probability"
    ] + selected_weight * comparison["multi_gap_probability"]
    candidate_metrics = fold_metrics(comparison, "candidate_probability")
    confirmation_deltas = {
        fold: {
            metric: candidate_metrics[fold][metric] - baseline_metrics[fold][metric]
            for metric in ("pr_auc", "brier")
        }
        for fold in CONFIRMATION_FOLDS
    }
    selection_eligible = (
        selected_weight > 0.0 and min(selected_trial["selection_pr_auc_deltas"].values()) > 0.0
    )
    accepted = (
        selection_eligible
        and min(confirmation_deltas[fold]["pr_auc"] for fold in CONFIRMATION_FOLDS)
        >= MIN_CONFIRMATION_WORST_GAIN
        and all(
            confirmation_deltas[fold]["brier"] <= MAX_CONFIRMATION_BRIER_INCREASE
            for fold in CONFIRMATION_FOLDS
        )
    )
    comparison.to_parquet(args.output_dir / "multi_gap_development_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_023_multi_gap_episodes",
        "priority": "P1 episode windows",
        "protocol": {
            "episode_gaps_minutes": list(GAPS),
            "episodes_cut_at_calendar_day_boundary": True,
            "raw_event_years_loaded": list(range(2019, 2026)),
            "selection_folds": list(SELECTION_FOLDS),
            "confirmation_folds": list(CONFIRMATION_FOLDS),
            "holdout_2026h1_accessed": False,
            "minimum_confirmation_worst_pr_auc_gain": MIN_CONFIRMATION_WORST_GAIN,
            "maximum_confirmation_brier_increase": MAX_CONFIRMATION_BRIER_INCREASE,
        },
        "added_feature_count": len(added),
        "added_features": added,
        "fit_reports": fit_reports,
        "baseline_metrics": baseline_metrics,
        "selected_weight": selected_weight,
        "selected_trial": selected_trial,
        "selection_eligible": selection_eligible,
        "candidate_metrics": candidate_metrics,
        "confirmation_deltas": confirmation_deltas,
        "trials": trials,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Multi-gap episode candidate passes the predeclared confirmation gate."
                if accepted
                else "Multi-gap episode candidate does not pass the predeclared confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "trials"},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
