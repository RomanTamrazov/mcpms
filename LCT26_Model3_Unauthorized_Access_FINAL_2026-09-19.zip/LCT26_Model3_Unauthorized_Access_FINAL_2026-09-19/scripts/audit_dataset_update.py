"""Compare two organiser dataset archives without extracting the event journals."""

from __future__ import annotations

import argparse
import hashlib
import json
from io import BytesIO
from pathlib import Path
from typing import Any
from zipfile import ZipFile

import pandas as pd

CHANNEL_FILE = "dataset/справочник_каналов_датчиков.csv"
OBJECT_FILE = "dataset/справочник_объектов_диспетчер.csv"
CHANNEL_ID = "ид_канала_данных"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--previous", type=Path, required=True)
    parser.add_argument("--updated", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    return parser.parse_args()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _entries(path: Path) -> dict[str, dict[str, Any]]:
    with ZipFile(path) as archive:
        entries: dict[str, dict[str, Any]] = {}
        for info in archive.infolist():
            if info.is_dir():
                continue
            digest = hashlib.sha256()
            with archive.open(info) as stream:
                while chunk := stream.read(8 * 1024 * 1024):
                    digest.update(chunk)
            entries[info.filename] = {
                "size": info.file_size,
                "compressed_size": info.compress_size,
                "crc32": f"{info.CRC:08x}",
                "sha256": digest.hexdigest(),
            }
        return entries


def _csv(path: Path, member: str) -> pd.DataFrame:
    with ZipFile(path) as archive:
        return pd.read_csv(BytesIO(archive.read(member)))


def _catalog_diff(previous: pd.DataFrame, updated: pd.DataFrame) -> dict[str, Any]:
    previous_indexed = previous.set_index(CHANNEL_ID).sort_index()
    updated_indexed = updated.set_index(CHANNEL_ID).sort_index()
    added = updated_indexed.index.difference(previous_indexed.index)
    removed = previous_indexed.index.difference(updated_indexed.index)
    common = previous_indexed.index.intersection(updated_indexed.index)
    common_columns = sorted(
        set(previous_indexed.columns).intersection(updated_indexed.columns)
    )
    changed_by_column = {column: 0 for column in common_columns}
    changed_ids: set[int] = set()
    for column in common_columns:
        left = previous_indexed.loc[common, column].fillna("__NA__").astype(str)
        right = updated_indexed.loc[common, column].fillna("__NA__").astype(str)
        changed = left != right
        changed_by_column[column] = int(changed.sum())
        changed_ids.update(common[changed].astype(int).tolist())
    mapping: dict[str, Any] | None = None
    if "ид_объект" in updated:
        mapping = {
            "mapped_channels": int(updated["ид_объект"].notna().sum()),
            "unmapped_channels": int(updated["ид_объект"].isna().sum()),
            "unique_object_ids": int(updated["ид_объект"].nunique(dropna=True)),
            "by_engineering_system": (
                updated.groupby("тип_инж_системы", dropna=False)["ид_объект"]
                .agg(rows="size", mapped="count", unique_objects="nunique")
                .reset_index()
                .to_dict(orient="records")
            ),
        }
    return {
        "previous_shape": list(previous.shape),
        "updated_shape": list(updated.shape),
        "previous_columns": list(previous.columns),
        "updated_columns": list(updated.columns),
        "added_columns": sorted(set(updated.columns) - set(previous.columns)),
        "removed_columns": sorted(set(previous.columns) - set(updated.columns)),
        "added_channel_ids": added.astype(int).tolist(),
        "removed_channel_ids": removed.astype(int).tolist(),
        "changed_common_channel_ids": sorted(changed_ids),
        "changed_common_channel_count": len(changed_ids),
        "changed_values_by_column": changed_by_column,
        "object_mapping": mapping,
    }


def _markdown(report: dict[str, Any]) -> str:
    catalog = report["channel_catalog"]
    entries = report["archive_entries"]
    mapping = catalog["object_mapping"]
    lines = [
        "# Аудит обновления датасета организаторов",
        "",
        f"Старый SHA-256: `{report['archives']['previous_sha256']}`",
        "",
        f"Новый SHA-256: `{report['archives']['updated_sha256']}`",
        "",
        "## Что изменилось",
        "",
        f"Изменённые ZIP-элементы: {', '.join(entries['changed'])}.",
        "",
        f"Неизменённые ZIP-элементы: {len(entries['unchanged'])}.",
        "",
        f"Справочник каналов: {catalog['previous_shape']} → {catalog['updated_shape']}.",
        "",
        f"Новые колонки: {catalog['added_columns']}.",
        "",
        (
            "Добавлено/удалено channel ID: "
            f"{len(catalog['added_channel_ids'])}/"
            f"{len(catalog['removed_channel_ids'])}."
        ),
        "",
        f"Изменено существующих строк: {catalog['changed_common_channel_count']}.",
    ]
    if mapping is not None:
        lines.extend(
            [
                "",
                "## Покрытие object mapping",
                "",
                f"- mapped channels: {mapping['mapped_channels']};",
                f"- unmapped channels: {mapping['unmapped_channels']};",
                f"- unique object IDs: {mapping['unique_object_ids']}.",
            ]
        )
    lines.extend(
        [
            "",
            "## Вывод",
            "",
            report["conclusion"],
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    previous_entries = _entries(args.previous)
    updated_entries = _entries(args.updated)
    names = sorted(set(previous_entries) | set(updated_entries))
    unchanged = [
        name
        for name in names
        if previous_entries.get(name) == updated_entries.get(name)
    ]
    changed = [name for name in names if name not in unchanged]
    previous_channels = _csv(args.previous, CHANNEL_FILE)
    updated_channels = _csv(args.updated, CHANNEL_FILE)
    updated_objects = _csv(args.updated, OBJECT_FILE)
    catalog = _catalog_diff(previous_channels, updated_channels)
    object_ids = set(updated_objects["ид_объект"].astype(int))
    mapped_ids = set(updated_channels["ид_объект"].dropna().astype(int))
    object_integrity = {
        "object_catalog_rows": int(updated_objects.shape[0]),
        "object_catalog_unique_ids": int(updated_objects["ид_объект"].nunique()),
        "channel_object_ids_missing_from_object_catalog": sorted(
            mapped_ids - object_ids
        ),
    }
    event_archives = [name for name in names if name.endswith(".7z")]
    event_archives_unchanged = all(name in unchanged for name in event_archives)
    conclusion = (
        "Все годовые журналы событий имеют одинаковый SHA-256. Обновление "
        "добавляет полный channel-to-object mapping и уточняет описания каналов; "
        "оно улучшает интеграцию и интерпретацию, но само по себе не добавляет "
        "новых временных наблюдений или labels."
        if event_archives_unchanged
        else "Один или несколько годовых журналов изменены; требуется полный rebuild."
    )
    report = {
        "archives": {
            "previous": str(args.previous.resolve()),
            "updated": str(args.updated.resolve()),
            "previous_sha256": _sha256(args.previous),
            "updated_sha256": _sha256(args.updated),
        },
        "archive_entries": {
            "unchanged": unchanged,
            "changed": changed,
            "previous": previous_entries,
            "updated": updated_entries,
            "event_archives_unchanged": event_archives_unchanged,
        },
        "channel_catalog": catalog,
        "object_catalog_integrity": object_integrity,
        "conclusion": conclusion,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    args.markdown_output.write_text(_markdown(report), encoding="utf-8")
    print(
        json.dumps(
            {
                "changed_entries": changed,
                "new_columns": catalog["added_columns"],
                "changed_rows": catalog["changed_common_channel_count"],
                "event_archives_unchanged": event_archives_unchanged,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
