"""P2: stability-selected pruning of the three active site components.

Feature importance and the retention fraction are selected only on the earlier
2022/2023 walk-forward folds.  One frozen candidate is then evaluated on the
2024/2025 confirmation folds.  The report-only 2026H1 holdout is never loaded.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score, brier_score_loss

from lct26_access.features import augment_site_model_frame
from lct26_access.models import (
    LGB_BASE_PARAMS,
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

COMPONENTS = ("lgb_base", "lgb_weekly_tuned", "lgb_context")
FOLDS = {
    "2022": (pd.Timestamp("2022-01-01"), pd.Timestamp("2023-01-01")),
    "2023": (pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    "2024": (pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    "2025": (pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
}
SELECTION_FOLDS = ("2022", "2023")
CONFIRMATION_FOLDS = ("2024", "2025")
RETENTION_FRACTIONS = (0.40, 0.55, 0.70, 0.85)
MAX_SELECTION_FOLD_LOSS = 0.00025
MAX_CONFIRMATION_BRIER_INCREASE = 0.00010
MIN_FEATURE_REDUCTION = 0.20


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--baseline-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def eligible_features(frame: pd.DataFrame, requested: list[str]) -> list[str]:
    return [
        feature
        for feature in requested
        if feature in frame.columns and frame[feature].nunique(dropna=False) > 1
    ]


def fit_fold(
    frame: pd.DataFrame,
    *,
    fold: str,
    requested_features: list[str],
    params: dict[str, object],
) -> tuple[pd.DataFrame, dict[str, float], dict[str, Any]]:
    start, end = FOLDS[fold]
    train = frame["target_date"] < start
    valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
    features = eligible_features(frame.loc[train], requested_features)
    categorical = [name for name in SITE_CATEGORICAL if name in features]
    category_maps = fit_category_maps(frame.loc[train], categorical)
    train_matrix = encode_for_lightgbm(frame.loc[train], features, category_maps)
    valid_matrix = encode_for_lightgbm(frame.loc[valid], features, category_maps)
    model = LGBMClassifier(**params, n_estimators=1_800)
    started = time.monotonic()
    model.fit(
        train_matrix,
        frame.loc[train, "target"].astype("int8"),
        categorical_feature=categorical,
        eval_X=valid_matrix,
        eval_y=frame.loc[valid, "target"].astype("int8"),
        eval_metric="average_precision",
        callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
    )
    prediction = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
    prediction["fold"] = fold
    prediction["probability"] = model.predict_proba(valid_matrix)[:, 1]
    gains = model.booster_.feature_importance(importance_type="gain")
    gain_sum = float(gains.sum())
    importance = {
        feature: float(gain / gain_sum) if gain_sum > 0 else 0.0
        for feature, gain in zip(features, gains, strict=True)
    }
    details = {
        "fold": fold,
        "train_rows": int(train.sum()),
        "validation_rows": int(valid.sum()),
        "feature_count": len(features),
        "iterations": int(model.best_iteration_),
        "fit_seconds": round(time.monotonic() - started, 3),
    }
    return prediction, importance, details


def ensemble_metrics(
    frame: pd.DataFrame,
    score_column: str,
) -> dict[str, dict[str, float]]:
    return {
        str(fold): {
            "pr_auc": float(average_precision_score(group["target"], group[score_column])),
            "brier": float(brier_score_loss(group["target"], group[score_column])),
        }
        for fold, group in frame.groupby("fold", sort=True)
    }


def merge_components(
    parts: dict[str, pd.DataFrame],
    weights: dict[str, float],
) -> pd.DataFrame:
    key = ["site_raw", "target_date", "target", "fold"]
    output: pd.DataFrame | None = None
    for component in COMPONENTS:
        part = parts[component].rename(columns={"probability": component})
        output = part if output is None else output.merge(part, on=key, validate="one_to_one")
    if output is None:
        raise RuntimeError("No component predictions")
    output["candidate_probability"] = sum(
        weights[component] * output[component] for component in COMPONENTS
    )
    return output


def select_feature_sets(
    requested: dict[str, list[str]],
    importances: dict[str, dict[str, dict[str, float]]],
    fraction: float,
) -> dict[str, list[str]]:
    selected: dict[str, list[str]] = {}
    for component in COMPONENTS:
        aggregate = {
            feature: float(
                np.mean(
                    [importances[component][fold].get(feature, 0.0) for fold in SELECTION_FOLDS]
                )
            )
            for feature in requested[component]
        }
        ranked = sorted(aggregate, key=lambda name: (-aggregate[name], name))
        keep_count = max(1, int(np.ceil(fraction * len(ranked))))
        keep = set(ranked[:keep_count])
        keep.update(name for name in SITE_CATEGORICAL if name in requested[component])
        selected[component] = [name for name in requested[component] if name in keep]
    return selected


def fit_components(
    frames: dict[str, pd.DataFrame],
    features: dict[str, list[str]],
    folds: tuple[str, ...],
    params: dict[str, dict[str, object]],
) -> tuple[dict[str, pd.DataFrame], dict[str, list[dict[str, Any]]]]:
    predictions: dict[str, pd.DataFrame] = {}
    reports: dict[str, list[dict[str, Any]]] = {}
    for component in COMPONENTS:
        parts: list[pd.DataFrame] = []
        reports[component] = []
        for fold in folds:
            print(
                f"fit component={component} fold={fold} features={len(features[component])}",
                flush=True,
            )
            prediction, _, details = fit_fold(
                frames[component],
                fold=fold,
                requested_features=features[component],
                params=params[component],
            )
            parts.append(prediction)
            reports[component].append(details)
        predictions[component] = pd.concat(parts, ignore_index=True)
    return predictions, reports


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    if float(metadata["ensemble_weights"].get("cat_base", 0.0)) != 0.0:
        raise ValueError("Pruning protocol assumes the frozen zero CatBoost weight")
    weights = {
        component: float(metadata["ensemble_weights"][component]) for component in COMPONENTS
    }
    requested = {
        component: list(metadata["variants"][component]["features"]) for component in COMPONENTS
    }
    frames = {
        "lgb_base": augment_site_model_frame(args.site_features, weekly=False),
        "lgb_weekly_tuned": augment_site_model_frame(args.site_features, weekly=True),
        "lgb_context": augment_site_model_frame(
            args.site_features,
            context_path=args.context_features,
            weekly=True,
        ),
    }
    for component, frame in frames.items():
        frame = frame[frame["target"].notna()].copy()
        frame["target_date"] = pd.to_datetime(frame["target_date"])
        frames[component] = frame[frame["target_date"] < pd.Timestamp("2026-01-01")]
    params = {
        "lgb_base": LGB_BASE_PARAMS,
        "lgb_weekly_tuned": LGB_WEEKLY_TUNED_PARAMS,
        "lgb_context": LGB_BASE_PARAMS,
    }
    baseline = pd.read_parquet(args.baseline_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])
    if (baseline["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered pruning experiment")
    baseline_metrics = ensemble_metrics(baseline, "ensemble_probability")

    importances: dict[str, dict[str, dict[str, float]]] = {
        component: {} for component in COMPONENTS
    }
    importance_fit: dict[str, list[dict[str, Any]]] = {component: [] for component in COMPONENTS}
    for component in COMPONENTS:
        for fold in SELECTION_FOLDS:
            print(f"importance component={component} fold={fold}", flush=True)
            _, values, details = fit_fold(
                frames[component],
                fold=fold,
                requested_features=requested[component],
                params=params[component],
            )
            importances[component][fold] = values
            importance_fit[component].append(details)

    trials: list[dict[str, Any]] = []
    trial_feature_sets: dict[float, dict[str, list[str]]] = {}
    for fraction in RETENTION_FRACTIONS:
        features = select_feature_sets(requested, importances, fraction)
        trial_feature_sets[fraction] = features
        predictions, fit_reports = fit_components(
            frames,
            features,
            SELECTION_FOLDS,
            params,
        )
        candidate = merge_components(predictions, weights)
        metrics = ensemble_metrics(candidate, "candidate_probability")
        deltas = {
            fold: metrics[fold]["pr_auc"] - baseline_metrics[fold]["pr_auc"]
            for fold in SELECTION_FOLDS
        }
        total_features = sum(len(values) for values in features.values())
        trials.append(
            {
                "retention_fraction": fraction,
                "feature_counts": {component: len(features[component]) for component in COMPONENTS},
                "total_feature_references": total_features,
                "selection_metrics": metrics,
                "selection_pr_auc_deltas": deltas,
                "selection_eligible": (
                    min(deltas.values()) >= -MAX_SELECTION_FOLD_LOSS
                    and float(np.mean(list(deltas.values()))) >= 0.0
                ),
                "fit_reports": fit_reports,
            }
        )

    eligible_trials = [trial for trial in trials if trial["selection_eligible"]]
    if eligible_trials:
        selected_trial = min(
            eligible_trials,
            key=lambda trial: (
                trial["total_feature_references"],
                -min(trial["selection_pr_auc_deltas"].values()),
            ),
        )
    else:
        selected_trial = max(
            trials,
            key=lambda trial: (
                min(trial["selection_pr_auc_deltas"].values()),
                float(np.mean(list(trial["selection_pr_auc_deltas"].values()))),
                -trial["total_feature_references"],
            ),
        )
    selected_fraction = float(selected_trial["retention_fraction"])
    selected_features = trial_feature_sets[selected_fraction]
    confirmation_predictions, confirmation_fit = fit_components(
        frames,
        selected_features,
        CONFIRMATION_FOLDS,
        params,
    )
    confirmation = merge_components(confirmation_predictions, weights)
    confirmation_metrics = ensemble_metrics(confirmation, "candidate_probability")
    confirmation_deltas = {
        fold: {
            metric: confirmation_metrics[fold][metric] - baseline_metrics[fold][metric]
            for metric in ("pr_auc", "brier")
        }
        for fold in CONFIRMATION_FOLDS
    }
    full_total = sum(len(values) for values in requested.values())
    selected_total = sum(len(values) for values in selected_features.values())
    reduction = 1.0 - selected_total / full_total
    accepted = (
        bool(selected_trial["selection_eligible"])
        and reduction >= MIN_FEATURE_REDUCTION
        and all(confirmation_deltas[fold]["pr_auc"] >= 0.0 for fold in CONFIRMATION_FOLDS)
        and all(
            confirmation_deltas[fold]["brier"] <= MAX_CONFIRMATION_BRIER_INCREASE
            for fold in CONFIRMATION_FOLDS
        )
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    comparison = baseline[
        ["site_raw", "target_date", "target", "fold", "ensemble_probability"]
    ].merge(
        pd.concat(
            [
                merge_components(
                    {
                        component: pd.concat(
                            [
                                confirmation_predictions[component],
                            ],
                            ignore_index=True,
                        )
                        for component in COMPONENTS
                    },
                    weights,
                )
            ],
            ignore_index=True,
        )[["site_raw", "target_date", "target", "fold", "candidate_probability"]],
        on=["site_raw", "target_date", "target", "fold"],
        how="left",
        validate="one_to_one",
    )
    comparison.to_parquet(args.output_dir / "pruning_confirmation_oof.parquet", index=False)
    importance_rows = []
    for component in COMPONENTS:
        for feature in requested[component]:
            importance_rows.append(
                {
                    "component": component,
                    "feature": feature,
                    **{
                        f"normalised_gain_{fold}": importances[component][fold].get(feature, 0.0)
                        for fold in SELECTION_FOLDS
                    },
                    "selected": feature in selected_features[component],
                }
            )
    pd.DataFrame(importance_rows).to_csv(
        args.output_dir / "selection_feature_importance.csv", index=False
    )
    report = {
        "experiment_id": "EXP_012_stability_feature_pruning",
        "priority": "P2",
        "protocol": {
            "importance_folds": list(SELECTION_FOLDS),
            "retention_selection_folds": list(SELECTION_FOLDS),
            "confirmation_folds": list(CONFIRMATION_FOLDS),
            "holdout_2026h1_accessed": False,
            "retention_fractions": list(RETENTION_FRACTIONS),
            "maximum_selection_fold_loss": MAX_SELECTION_FOLD_LOSS,
            "acceptance_requires_nonnegative_confirmation_pr_auc_delta": True,
            "maximum_confirmation_brier_increase": MAX_CONFIRMATION_BRIER_INCREASE,
            "minimum_feature_reduction": MIN_FEATURE_REDUCTION,
        },
        "baseline_metrics": baseline_metrics,
        "importance_fit": importance_fit,
        "selection_trials": trials,
        "selected_retention_fraction": selected_fraction,
        "selected_feature_counts": {
            component: len(selected_features[component]) for component in COMPONENTS
        },
        "original_feature_counts": {
            component: len(requested[component]) for component in COMPONENTS
        },
        "feature_reference_reduction": reduction,
        "selected_features": selected_features,
        "confirmation_fit": confirmation_fit,
        "confirmation_metrics": confirmation_metrics,
        "confirmation_deltas": confirmation_deltas,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Pruned candidate passes the predeclared no-PR-AUC-loss confirmation gate."
                if accepted
                else "Pruned candidate does not pass the predeclared no-PR-AUC-loss confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "selection_trials"},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
