"""Paired temporal bootstrap for two conditional zone-ranking models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

FOLDS = ("2025", "2026H1")
METRICS = ("mrr", "hit_rate_at_1", "hit_rate_at_3", "hit_rate_at_5", "hit_rate_at_10")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--current-oof", type=Path, required=True)
    parser.add_argument("--previous-oof", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=2_000)
    parser.add_argument("--block-days", type=int, default=7)
    parser.add_argument("--seed", type=int, default=2603)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    return parser.parse_args()


def _group_first_positive_rank(frame: pd.DataFrame, score: str) -> pd.DataFrame:
    ordered = frame.sort_values(
        ["target_date", "site_raw", score],
        ascending=[True, True, False],
        kind="mergesort",
    ).copy()
    ordered["rank"] = ordered.groupby(["target_date", "site_raw"]).cumcount() + 1
    return (
        ordered.loc[ordered["target"] == 1]
        .groupby(["target_date", "site_raw"], as_index=False)["rank"]
        .min()
    )


def _metric_values(first_rank: np.ndarray) -> dict[str, float]:
    return {
        "mrr": float(np.mean(1.0 / first_rank)),
        **{
            f"hit_rate_at_{cutoff}": float(np.mean(first_rank <= cutoff))
            for cutoff in (1, 3, 5, 10)
        },
    }


def _calendar_sample(day_count: int, rng: np.random.Generator) -> np.ndarray:
    return rng.integers(0, day_count, size=day_count)


def _block_sample(
    day_count: int,
    block_days: int,
    rng: np.random.Generator,
) -> np.ndarray:
    sampled: list[int] = []
    while len(sampled) < day_count:
        start = int(rng.integers(0, day_count))
        sampled.extend((start + offset) % day_count for offset in range(block_days))
    return np.asarray(sampled[:day_count], dtype=np.int64)


def _summarise(samples: np.ndarray, point: float) -> dict[str, Any]:
    lower = float(np.quantile(samples, 0.025))
    upper = float(np.quantile(samples, 0.975))
    return {
        "point_delta_current_minus_previous": float(point),
        "mean_delta": float(samples.mean()),
        "median_delta": float(np.median(samples)),
        "lower_95": lower,
        "upper_95": upper,
        "probability_current_better": float(np.mean(samples > 0)),
        "ci_excludes_zero": bool(lower > 0 or upper < 0),
    }


def _paired_fold(
    frame: pd.DataFrame,
    *,
    draws: int,
    block_days: int,
    seed: int,
) -> dict[str, Any]:
    frame = frame.sort_values(["target_date", "site_raw"]).reset_index(drop=True)
    dates = pd.Index(frame["target_date"].drop_duplicates().sort_values())
    date_values = frame["target_date"].to_numpy()
    day_rows = [np.flatnonzero(date_values == day) for day in dates]
    current_rank = frame["current_first_rank"].to_numpy(dtype=float)
    previous_rank = frame["previous_first_rank"].to_numpy(dtype=float)
    current_point = _metric_values(current_rank)
    previous_point = _metric_values(previous_rank)
    output: dict[str, Any] = {
        "positive_site_days": int(frame.shape[0]),
        "days": len(dates),
        "current": current_point,
        "previous": previous_point,
        "bootstrap": {},
    }
    for scheme_index, scheme in enumerate(("calendar_day", "moving_block_7d")):
        rng = np.random.default_rng(seed + scheme_index * 100_003)
        deltas = {metric: np.empty(draws, dtype=float) for metric in METRICS}
        for draw in range(draws):
            sampled_days = (
                _calendar_sample(len(dates), rng)
                if scheme == "calendar_day"
                else _block_sample(len(dates), block_days, rng)
            )
            rows = np.concatenate([day_rows[int(index)] for index in sampled_days])
            current_values = _metric_values(current_rank[rows])
            previous_values = _metric_values(previous_rank[rows])
            for metric in METRICS:
                deltas[metric][draw] = current_values[metric] - previous_values[metric]
        output["bootstrap"][scheme] = {
            metric: _summarise(
                deltas[metric],
                current_point[metric] - previous_point[metric],
            )
            for metric in METRICS
        }
    return output


def _markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Paired bootstrap: strict updated zone model vs previous zone model",
        "",
        (
            "Сравнение попарное по тем же site-day. 2025 — development-период; "
            "2026H1 приведён только как report-only holdout."
        ),
        "",
    ]
    for fold in FOLDS:
        lines.extend(
            [
                f"## {fold}",
                "",
                "| Bootstrap | Metric | Point delta | 95% CI | P(current better) |",
                "|---|---|---:|---:|---:|",
            ]
        )
        for scheme, values in report["folds"][fold]["bootstrap"].items():
            for metric in METRICS:
                value = values[metric]
                lines.append(
                    f"| {scheme} | {metric} | "
                    f"{value['point_delta_current_minus_previous']:.8f} | "
                    f"[{value['lower_95']:.8f}, {value['upper_95']:.8f}] | "
                    f"{value['probability_current_better']:.4f} |"
                )
        lines.append("")
    lines.extend(["## Verdict", "", report["development_verdict"]["statement"], ""])
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    if args.draws < 100:
        raise ValueError("--draws must be at least 100")
    required = ["target_date", "site_raw", "zone_key", "target", "blend_rank"]
    current_raw = pd.read_parquet(args.current_oof, columns=required)
    previous_raw = pd.read_parquet(args.previous_oof, columns=required)
    keys = ["target_date", "site_raw", "zone_key", "target"]
    paired_rows = current_raw.merge(
        previous_raw,
        on=keys,
        how="inner",
        validate="one_to_one",
        suffixes=("_current", "_previous"),
    )
    if paired_rows.shape[0] != current_raw.shape[0] or paired_rows.shape[0] != previous_raw.shape[0]:
        raise ValueError("Current and previous zone rows are not perfectly paired")

    current_groups = _group_first_positive_rank(
        paired_rows.rename(columns={"blend_rank_current": "blend_rank"}),
        "blend_rank",
    ).rename(columns={"rank": "current_first_rank"})
    previous_groups = _group_first_positive_rank(
        paired_rows.rename(columns={"blend_rank_previous": "blend_rank"}),
        "blend_rank",
    ).rename(columns={"rank": "previous_first_rank"})
    paired = current_groups.merge(
        previous_groups,
        on=["target_date", "site_raw"],
        validate="one_to_one",
    )
    paired["fold"] = np.where(
        paired["target_date"] < pd.Timestamp("2026-01-01"),
        "2025",
        "2026H1",
    )
    folds = {
        fold: _paired_fold(
            paired.loc[paired["fold"] == fold].copy(),
            draws=args.draws,
            block_days=args.block_days,
            seed=args.seed + index * 1_000_003,
        )
        for index, fold in enumerate(FOLDS)
    }
    development_checks = [
        folds["2025"]["bootstrap"][scheme][metric]
        for scheme in ("calendar_day", "moving_block_7d")
        for metric in ("mrr", "hit_rate_at_3", "hit_rate_at_5")
    ]
    material_degradation = any(check["upper_95"] < -0.01 for check in development_checks)
    statement = (
        "На development-периоде нет статистически подтверждённой материальной "
        "деградации более 1 п.п.; строгую fold-local кодировку можно принять как "
        "исправление причинности, но не как улучшение ranking-качества."
        if not material_degradation
        else "Обнаружена статистически подтверждённая материальная деградация; кандидат не принимать."
    )
    report = {
        "protocol": {
            "paired_on": keys,
            "draws": args.draws,
            "seed": args.seed,
            "calendar_bootstrap_unit": "calendar day",
            "block_bootstrap": f"circular moving blocks of {args.block_days} days",
            "selection_policy": "2025 development-only; 2026H1 report-only",
        },
        "folds": folds,
        "development_verdict": {
            "material_degradation_threshold": -0.01,
            "material_degradation_detected": material_degradation,
            "statement": statement,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    args.markdown_output.write_text(_markdown(report), encoding="utf-8")
    print(json.dumps(report["development_verdict"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
