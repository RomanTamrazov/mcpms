"""Retrospective four-window robustness evaluation of the frozen site champion.

This script never reads or scores 2026H1.  The feature schemas, hyperparameters,
component weights, and operating threshold come from the already frozen champion.
Each fold fits category maps and feature eligibility on strictly earlier rows.
Early stopping is allowed only to choose the number of trees for that same
walk-forward evaluation; it cannot change features, weights, or thresholds.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from statistics import mean, median
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation

from lct26_access.features import augment_site_model_frame
from lct26_access.metrics import site_metrics
from lct26_access.models import (
    LGB_BASE_PARAMS,
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

FOLDS = (
    ("2022", pd.Timestamp("2022-01-01"), pd.Timestamp("2023-01-01")),
    ("2023", pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
COMPONENTS = ("lgb_base", "lgb_weekly_tuned", "lgb_context")
LOWER_IS_BETTER = {"brier", "logloss"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def eligible_features(frame: pd.DataFrame, requested: list[str]) -> list[str]:
    return [
        feature
        for feature in requested
        if feature in frame.columns and frame[feature].nunique(dropna=False) > 1
    ]


def component_predictions(
    frame: pd.DataFrame,
    *,
    component: str,
    requested_features: list[str],
    params: dict[str, object],
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    target = frame["target"].astype("int8")
    parts: list[pd.DataFrame] = []
    reports: list[dict[str, Any]] = []
    for fold, start, end in FOLDS:
        train = frame["target_date"] < start
        valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
        if not train.any() or not valid.any():
            raise ValueError(f"Fold {fold} has no train or validation rows")
        features = eligible_features(frame.loc[train], requested_features)
        categorical = [name for name in SITE_CATEGORICAL if name in features]
        category_maps = fit_category_maps(frame.loc[train], categorical)
        train_matrix = encode_for_lightgbm(frame.loc[train], features, category_maps)
        valid_matrix = encode_for_lightgbm(frame.loc[valid], features, category_maps)
        model = LGBMClassifier(**params, n_estimators=1_800)
        started = time.monotonic()
        model.fit(
            train_matrix,
            target.loc[train],
            categorical_feature=categorical,
            eval_X=valid_matrix,
            eval_y=target.loc[valid],
            eval_metric="average_precision",
            callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
        )
        probability = model.predict_proba(valid_matrix)[:, 1]
        output = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
        output["fold"] = fold
        output[component] = probability
        parts.append(output)
        reports.append(
            {
                "fold": fold,
                "train_end_exclusive": str(start.date()),
                "validation_end_exclusive": str(end.date()),
                "train_rows": int(train.sum()),
                "validation_rows": int(valid.sum()),
                "feature_count": len(features),
                "category_map_scope": f"target_date < {start.date()}",
                "feature_eligibility_scope": f"target_date < {start.date()}",
                "iterations_used": int(model.best_iteration_),
                "fit_seconds": round(time.monotonic() - started, 3),
            }
        )
    return pd.concat(parts, ignore_index=True), reports


def metric_summary(fold_reports: list[dict[str, Any]]) -> dict[str, dict[str, float]]:
    metrics = ("pr_auc", "roc_auc", "brier", "logloss", "f1", "precision", "recall")
    years = np.asarray([int(report["fold"]) for report in fold_reports], dtype=float)
    summary: dict[str, dict[str, float]] = {}
    for metric in metrics:
        values = np.asarray([float(report[metric]) for report in fold_reports])
        summary[metric] = {
            "mean": float(mean(values)),
            "median": float(median(values)),
            "worst": float(values.max() if metric in LOWER_IS_BETTER else values.min()),
            "best": float(values.min() if metric in LOWER_IS_BETTER else values.max()),
            "standard_deviation": float(values.std(ddof=0)),
            "linear_trend_per_year": float(np.polyfit(years, values, 1)[0]),
        }
    return summary


def workload(frame: pd.DataFrame, threshold: float) -> dict[str, float | int]:
    predicted = frame["ensemble_probability"] >= threshold
    days = frame["target_date"].nunique()
    false_positive = predicted & (frame["target"] == 0)
    false_negative = ~predicted & (frame["target"] == 1)
    return {
        "days": int(days),
        "alerts": int(predicted.sum()),
        "alerts_per_day": float(predicted.sum() / days),
        "false_positives_per_day": float(false_positive.sum() / days),
        "false_negatives_per_day": float(false_negative.sum() / days),
        "review_share": float(predicted.mean()),
    }


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    weights = metadata["ensemble_weights"]
    if weights.get("cat_base") != 0:
        raise ValueError("This strict evaluator may skip CatBoost only when its weight is zero")
    active_weights = {name: float(weights[name]) for name in COMPONENTS}
    if not np.isclose(sum(active_weights.values()), 1.0):
        raise ValueError(f"Active weights must sum to one, got {active_weights}")
    threshold = float(metadata["decision_thresholds_from_2024_2025"]["operational_recall_80"])

    frames = {
        "lgb_base": augment_site_model_frame(args.site_features, weekly=False),
        "lgb_weekly_tuned": augment_site_model_frame(args.site_features, weekly=True),
        "lgb_context": augment_site_model_frame(
            args.site_features, context_path=args.context_features, weekly=True
        ),
    }
    for name, frame in frames.items():
        frame = frame[frame["target"].notna()].copy()
        frame["target_date"] = pd.to_datetime(frame["target_date"])
        if (
            frame.loc[frame["target_date"] < pd.Timestamp("2026-01-01"), "target_date"]
            >= pd.Timestamp("2026-01-01")
        ).any():
            raise AssertionError("Frozen holdout entered development frame")
        frames[name] = frame

    params = {
        "lgb_base": LGB_BASE_PARAMS,
        "lgb_weekly_tuned": LGB_WEEKLY_TUNED_PARAMS,
        "lgb_context": LGB_BASE_PARAMS,
    }
    predictions: list[pd.DataFrame] = []
    component_reports: dict[str, list[dict[str, Any]]] = {}
    for component in COMPONENTS:
        result, reports = component_predictions(
            frames[component],
            component=component,
            requested_features=list(metadata["variants"][component]["features"]),
            params=params[component],
        )
        predictions.append(result)
        component_reports[component] = reports

    key = ["site_raw", "target_date", "target", "fold"]
    oof = predictions[0]
    for component, result in zip(COMPONENTS[1:], predictions[1:], strict=True):
        oof = oof.merge(result, on=key, validate="one_to_one")
    oof["ensemble_probability"] = sum(active_weights[name] * oof[name] for name in COMPONENTS)
    if (oof["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("2026H1 is forbidden in expanded development walk-forward")

    fold_reports: list[dict[str, Any]] = []
    baseline_reports: list[dict[str, Any]] = []
    baseline_frame = frames["lgb_weekly_tuned"]
    for fold, start, end in FOLDS:
        fold_frame = oof[oof["fold"] == fold]
        report = site_metrics(
            fold_frame["target"],
            fold_frame["ensemble_probability"],
            fold_frame["target_date"],
            threshold=threshold,
        )
        report.update({"fold": fold, "workload": workload(fold_frame, threshold)})
        fold_reports.append(report)

        valid = (baseline_frame["target_date"] >= start) & (baseline_frame["target_date"] < end)
        baseline = site_metrics(
            baseline_frame.loc[valid, "target"].astype(int),
            baseline_frame.loc[valid, "positive_day_rate28"],
            baseline_frame.loc[valid, "target_date"],
            threshold=threshold,
        )
        baseline["fold"] = fold
        baseline_reports.append(baseline)

    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    oof.to_parquet(output / "expanded_walk_forward_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_006_expanded_walk_forward",
        "status": "diagnostic",
        "champion_version": metadata["model_version"],
        "protocol": {
            "folds": [fold for fold, _, _ in FOLDS],
            "train_rule": "strictly target_date before fold start",
            "feature_schema": "frozen champion manifest",
            "component_weights": active_weights,
            "threshold": threshold,
            "threshold_note": (
                "Frozen on 2024/2025; threshold metrics on 2022/2023 are retrospective "
                "stress tests and not simulations of a historically selected policy."
            ),
            "tree_count": "early stopping inside each walk-forward validation fold",
            "holdout_2026h1_accessed": False,
            "selection_use": "none; robustness diagnosis only",
        },
        "component_fit_reports": component_reports,
        "fold_metrics": fold_reports,
        "summary": metric_summary(fold_reports),
        "baseline_positive_day_rate28": baseline_reports,
    }
    (output / "expanded_walk_forward_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
