"""Test two-to-five-year same-weekday history for site risk.

The candidate adds only past observations aligned to the forecast weekday.
Blend weight is selected on 2022/2023 and checked on 2024/2025.  The frozen
2026H1 holdout is never loaded or scored.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score, brier_score_loss

from lct26_access.features import augment_site_model_frame
from lct26_access.models import (
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

FOLDS = (
    ("2022", pd.Timestamp("2022-01-01"), pd.Timestamp("2023-01-01")),
    ("2023", pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
SELECTION_FOLDS = ("2022", "2023")
CONFIRMATION_FOLDS = ("2024", "2025")
LONG_WINDOWS = (104, 156, 260)
MIN_CONFIRMATION_WORST_GAIN = 0.00025
MIN_CONFIRMATION_MEAN_GAIN = 0.0005
MAX_CONFIRMATION_BRIER_INCREASE = 0.0001


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--baseline-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def add_long_weekly_features(frame: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    frame = frame.sort_values(["site_raw", "date"]).reset_index(drop=True).copy()
    groups = frame.groupby("site_raw", sort=False)
    current_day = (frame["intrusion_events"] > 0).astype("int8")
    day_groups = current_day.groupby(frame["site_raw"], sort=False)
    weekly_days = [day_groups.shift(6 + 7 * index) for index in range(max(LONG_WINDOWS))]
    weekly_events = [
        np.log1p(groups["intrusion_events"].shift(6 + 7 * index))
        for index in range(max(LONG_WINDOWS))
    ]
    extra: dict[str, pd.Series] = {}
    for weeks in LONG_WINDOWS:
        extra[f"same_target_weekday_rate_{weeks}w"] = (
            pd.concat(weekly_days[:weeks], axis=1).mean(axis=1).fillna(0)
        )
        extra[f"same_target_weekday_logevents_{weeks}w"] = (
            pd.concat(weekly_events[:weeks], axis=1).mean(axis=1).fillna(0)
        )
    extra["same_weekday_rate_trend_52_104"] = (
        frame["same_target_weekday_rate_52w"] - extra["same_target_weekday_rate_104w"]
    )
    extra["same_weekday_rate_trend_52_260"] = (
        frame["same_target_weekday_rate_52w"] - extra["same_target_weekday_rate_260w"]
    )
    extra["same_weekday_logevents_trend_52_104"] = (
        frame["same_target_weekday_logevents_52w"] - extra["same_target_weekday_logevents_104w"]
    )
    extra["same_weekday_logevents_trend_52_260"] = (
        frame["same_target_weekday_logevents_52w"] - extra["same_target_weekday_logevents_260w"]
    )
    names = sorted(extra)
    return pd.concat([frame, pd.DataFrame(extra, index=frame.index)], axis=1), names


def fold_metrics(frame: pd.DataFrame, score_column: str) -> dict[str, dict[str, float]]:
    return {
        str(fold): {
            "pr_auc": float(average_precision_score(group["target"], group[score_column])),
            "brier": float(brier_score_loss(group["target"], group[score_column])),
        }
        for fold, group in frame.groupby("fold", sort=True)
    }


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    base = augment_site_model_frame(args.site_features, weekly=True)
    base = base[base["target"].notna()].copy()
    base["target_date"] = pd.to_datetime(base["target_date"])
    base = base[base["target_date"] < pd.Timestamp("2026-01-01")]
    frame, added = add_long_weekly_features(base)
    requested = [
        *metadata["variants"]["lgb_weekly_tuned"]["features"],
        *added,
    ]

    parts: list[pd.DataFrame] = []
    fit_reports: list[dict[str, Any]] = []
    for fold, start, end in FOLDS:
        train = frame["target_date"] < start
        valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
        features = [
            feature
            for feature in requested
            if feature in frame.columns and frame.loc[train, feature].nunique(dropna=False) > 1
        ]
        categorical = [name for name in SITE_CATEGORICAL if name in features]
        maps = fit_category_maps(frame.loc[train], categorical)
        train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
        valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
        model = LGBMClassifier(**LGB_WEEKLY_TUNED_PARAMS, n_estimators=1_800)
        started = time.monotonic()
        model.fit(
            train_matrix,
            frame.loc[train, "target"].astype("int8"),
            categorical_feature=categorical,
            eval_X=valid_matrix,
            eval_y=frame.loc[valid, "target"].astype("int8"),
            eval_metric="average_precision",
            callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
        )
        output = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
        output["fold"] = fold
        output["long_weekly_probability"] = model.predict_proba(valid_matrix)[:, 1]
        parts.append(output)
        fit_reports.append(
            {
                "fold": fold,
                "train_rows": int(train.sum()),
                "validation_rows": int(valid.sum()),
                "feature_count": len(features),
                "added_feature_count": len(added),
                "iterations": int(model.best_iteration_),
                "fit_seconds": round(time.monotonic() - started, 3),
            }
        )
        print(f"completed fold={fold}", flush=True)
    candidate = pd.concat(parts, ignore_index=True)

    baseline = pd.read_parquet(args.baseline_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])
    if (baseline["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered long-weekly experiment")
    key = ["site_raw", "target_date", "target", "fold"]
    comparison = baseline[key + ["ensemble_probability"]].merge(
        candidate,
        on=key,
        validate="one_to_one",
    )
    baseline_metrics = fold_metrics(comparison, "ensemble_probability")
    trials: list[dict[str, Any]] = []
    best_key: tuple[float, float, float] | None = None
    selected_weight = 0.0
    for weight in np.linspace(0.0, 0.5, 21):
        comparison["trial_probability"] = (1.0 - weight) * comparison[
            "ensemble_probability"
        ] + weight * comparison["long_weekly_probability"]
        metrics = fold_metrics(
            comparison[comparison["fold"].isin(SELECTION_FOLDS)],
            "trial_probability",
        )
        deltas = {
            fold: metrics[fold]["pr_auc"] - baseline_metrics[fold]["pr_auc"]
            for fold in SELECTION_FOLDS
        }
        key_value = (
            min(deltas.values()),
            float(np.mean(list(deltas.values()))),
            -float(weight),
        )
        trials.append(
            {
                "candidate_weight": float(weight),
                "selection_metrics": metrics,
                "selection_pr_auc_deltas": deltas,
            }
        )
        if best_key is None or key_value > best_key:
            best_key = key_value
            selected_weight = float(weight)
    selected_trial = next(trial for trial in trials if trial["candidate_weight"] == selected_weight)
    comparison["candidate_probability"] = (1.0 - selected_weight) * comparison[
        "ensemble_probability"
    ] + selected_weight * comparison["long_weekly_probability"]
    candidate_metrics = fold_metrics(comparison, "candidate_probability")
    confirmation_deltas = {
        fold: {
            metric: candidate_metrics[fold][metric] - baseline_metrics[fold][metric]
            for metric in ("pr_auc", "brier")
        }
        for fold in CONFIRMATION_FOLDS
    }
    confirmation_pr_deltas = [confirmation_deltas[fold]["pr_auc"] for fold in CONFIRMATION_FOLDS]
    selection_eligible = (
        selected_weight > 0.0 and min(selected_trial["selection_pr_auc_deltas"].values()) > 0.0
    )
    accepted = (
        selection_eligible
        and min(confirmation_pr_deltas) >= MIN_CONFIRMATION_WORST_GAIN
        and float(np.mean(confirmation_pr_deltas)) >= MIN_CONFIRMATION_MEAN_GAIN
        and all(
            confirmation_deltas[fold]["brier"] <= MAX_CONFIRMATION_BRIER_INCREASE
            for fold in CONFIRMATION_FOLDS
        )
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    comparison.to_parquet(args.output_dir / "long_weekly_development_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_021_long_horizon_weekly",
        "priority": "P1 seasonal",
        "protocol": {
            "selection_folds": list(SELECTION_FOLDS),
            "confirmation_folds": list(CONFIRMATION_FOLDS),
            "holdout_2026h1_accessed": False,
            "maximum_history_weeks": max(LONG_WINDOWS),
            "all_added_features_use_strictly_available_day_D_or_earlier_data": True,
            "minimum_confirmation_worst_pr_auc_gain": MIN_CONFIRMATION_WORST_GAIN,
            "minimum_confirmation_mean_pr_auc_gain": MIN_CONFIRMATION_MEAN_GAIN,
            "maximum_confirmation_brier_increase": MAX_CONFIRMATION_BRIER_INCREASE,
        },
        "added_features": added,
        "fit_reports": fit_reports,
        "baseline_metrics": baseline_metrics,
        "selected_weight": selected_weight,
        "selected_trial": selected_trial,
        "selection_eligible": selection_eligible,
        "candidate_metrics": candidate_metrics,
        "confirmation_deltas": confirmation_deltas,
        "trials": trials,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Long-horizon weekly candidate passes the predeclared confirmation gate."
                if accepted
                else "Long-horizon weekly candidate does not pass the predeclared confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "trials"},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
