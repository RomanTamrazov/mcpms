"""P1.2: causal burstiness and recency candidate for site risk.

The candidate is trained and blended only on 2022--2025 walk-forward OOF rows.
The frozen 2026H1 holdout is neither loaded nor scored.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
from sklearn.metrics import average_precision_score

from lct26_access.features import augment_site_model_frame
from lct26_access.models import (
    LGB_WEEKLY_TUNED_PARAMS,
    SITE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

FOLDS = (
    ("2022", pd.Timestamp("2022-01-01"), pd.Timestamp("2023-01-01")),
    ("2023", pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    ("2024", pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    ("2025", pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
)
HALF_LIVES = (2, 4, 7, 14, 28, 56, 90)
MATERIAL_WORST_FOLD_GAIN = 0.0005
MAX_ALLOWED_SINGLE_FOLD_DEGRADATION = 0.00025


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--baseline-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def add_burst_recency_features(frame: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Add day-D-only exponential hazard and burst features."""

    frame = frame.sort_values(["site_raw", "date"]).reset_index(drop=True).copy()
    frame["current_intrusion_day"] = (frame["intrusion_events"] > 0).astype("int8")
    frame["current_burst_day"] = (frame["intrusion_episode_max_events"] >= 3).astype("int8")
    frame["current_multi_episode_day"] = (frame["intrusion_episode_count"] >= 2).astype("int8")
    groups = frame.groupby("site_raw", sort=False)
    extra: dict[str, pd.Series] = {}
    source_columns = (
        "current_intrusion_day",
        "intrusion_events",
        "intrusion_episode_count",
        "intrusion_multi_event_episodes",
        "intrusion_episode_max_events",
        "intrusion_zone_transitions",
        "current_burst_day",
        "current_multi_episode_day",
    )
    for column in source_columns:
        for half_life in HALF_LIVES:
            name = f"exp_{column}_hl{half_life}"
            extra[name] = groups[column].transform(
                lambda values, half_life=half_life: values.ewm(
                    halflife=half_life,
                    adjust=False,
                    min_periods=1,
                ).mean()
            )

    positive = frame["current_intrusion_day"].astype(bool)
    changes = positive.ne(groups["current_intrusion_day"].shift(1).fillna(-1))
    run_id = changes.groupby(frame["site_raw"]).cumsum()
    run_length = frame.groupby([frame["site_raw"], run_id], sort=False).cumcount() + 1
    extra["current_positive_streak"] = run_length.where(positive, 0).astype("int32")
    extra["current_quiet_streak"] = run_length.where(~positive, 0).astype("int32")

    for half_life in (2, 7, 14, 28, 56):
        extra[f"recency_kernel_hl{half_life}"] = np.exp(
            -np.log(2) * frame["days_since_intrusion"].clip(upper=9999) / half_life
        )
    extra["short_long_intrusion_ratio_7_56"] = extra["exp_intrusion_events_hl7"] / (
        extra["exp_intrusion_events_hl56"] + 0.05
    )
    extra["short_long_burst_ratio_7_56"] = extra["exp_current_burst_day_hl7"] / (
        extra["exp_current_burst_day_hl56"] + 0.05
    )
    extra["episode_acceleration_4_28"] = (
        extra["exp_intrusion_episode_count_hl4"] - extra["exp_intrusion_episode_count_hl28"]
    )
    extra["transition_acceleration_7_56"] = (
        extra["exp_intrusion_zone_transitions_hl7"] - extra["exp_intrusion_zone_transitions_hl56"]
    )
    names = sorted(extra)
    return pd.concat([frame, pd.DataFrame(extra, index=frame.index)], axis=1), names


def fit_candidate(
    frame: pd.DataFrame,
    requested: list[str],
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    target = frame["target"].astype("int8")
    parts: list[pd.DataFrame] = []
    reports: list[dict[str, Any]] = []
    for fold, start, end in FOLDS:
        train = frame["target_date"] < start
        valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
        features = [
            feature
            for feature in requested
            if feature in frame.columns and frame.loc[train, feature].nunique(dropna=False) > 1
        ]
        categorical = [name for name in SITE_CATEGORICAL if name in features]
        maps = fit_category_maps(frame.loc[train], categorical)
        train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
        valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
        model = LGBMClassifier(**LGB_WEEKLY_TUNED_PARAMS, n_estimators=1_800)
        started = time.monotonic()
        model.fit(
            train_matrix,
            target.loc[train],
            categorical_feature=categorical,
            eval_X=valid_matrix,
            eval_y=target.loc[valid],
            eval_metric="average_precision",
            callbacks=[early_stopping(120, verbose=False), log_evaluation(0)],
        )
        probability = model.predict_proba(valid_matrix)[:, 1]
        output = frame.loc[valid, ["site_raw", "target_date", "target"]].copy()
        output["fold"] = fold
        output["burst_recency_probability"] = probability
        parts.append(output)
        reports.append(
            {
                "fold": fold,
                "feature_count": len(features),
                "iterations": int(model.best_iteration_),
                "fit_seconds": round(time.monotonic() - started, 3),
                "pr_auc": float(average_precision_score(target.loc[valid], probability)),
            }
        )
    return pd.concat(parts, ignore_index=True), reports


def fold_scores(frame: pd.DataFrame, column: str) -> dict[str, float]:
    return {
        str(fold): float(average_precision_score(group["target"], group[column]))
        for fold, group in frame.groupby("fold", sort=True)
    }


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    base = augment_site_model_frame(args.site_features, weekly=True)
    base = base[base["target"].notna()].copy()
    base["target_date"] = pd.to_datetime(base["target_date"])
    base = base[base["target_date"] < pd.Timestamp("2026-01-01")].copy()
    frame, added_features = add_burst_recency_features(base)
    frozen_features = list(metadata["variants"]["lgb_weekly_tuned"]["features"])
    candidate, fit_reports = fit_candidate(frame, [*frozen_features, *added_features])

    baseline = pd.read_parquet(args.baseline_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])
    if (baseline["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Baseline OOF contains forbidden 2026H1 rows")
    key = ["site_raw", "target_date", "target", "fold"]
    comparison = baseline[key + ["ensemble_probability"]].merge(
        candidate,
        on=key,
        validate="one_to_one",
    )
    baseline_scores = fold_scores(comparison, "ensemble_probability")

    trials: list[dict[str, Any]] = []
    best_key: tuple[float, float, float] | None = None
    best_weight = 0.0
    best_scores = baseline_scores
    for weight in np.linspace(0.0, 0.5, 21):
        comparison["trial_probability"] = (1 - weight) * comparison[
            "ensemble_probability"
        ] + weight * comparison["burst_recency_probability"]
        scores = fold_scores(comparison, "trial_probability")
        key_value = (
            min(scores.values()),
            float(np.mean(list(scores.values()))),
            -float(weight),
        )
        trials.append({"candidate_weight": float(weight), "fold_pr_auc": scores})
        if best_key is None or key_value > best_key:
            best_key = key_value
            best_weight = float(weight)
            best_scores = scores

    deltas = {fold: best_scores[fold] - baseline_scores[fold] for fold in baseline_scores}
    worst_baseline_fold = min(baseline_scores, key=baseline_scores.get)
    accepted = (
        best_weight > 0
        and deltas[worst_baseline_fold] >= MATERIAL_WORST_FOLD_GAIN
        and min(deltas.values()) >= -MAX_ALLOWED_SINGLE_FOLD_DEGRADATION
        and float(np.mean(list(deltas.values()))) >= MATERIAL_WORST_FOLD_GAIN
    )
    comparison["selected_probability"] = (1 - best_weight) * comparison[
        "ensemble_probability"
    ] + best_weight * comparison["burst_recency_probability"]
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    comparison.to_parquet(output / "burst_recency_development_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_011_burst_recency",
        "priority": "P1.2",
        "protocol": {
            "folds": [fold for fold, _, _ in FOLDS],
            "holdout_2026h1_accessed": False,
            "feature_cutoff": "all added features include observations no later than day D",
            "blend_weight_grid": "0.00 to 0.50 by 0.025",
            "objective": "maximise worst-fold PR-AUC, then mean PR-AUC",
            "material_worst_fold_gain": MATERIAL_WORST_FOLD_GAIN,
            "maximum_single_fold_degradation": MAX_ALLOWED_SINGLE_FOLD_DEGRADATION,
        },
        "added_feature_count": len(added_features),
        "added_features": added_features,
        "candidate_fit": fit_reports,
        "baseline_fold_pr_auc": baseline_scores,
        "selected_weight": best_weight,
        "selected_fold_pr_auc": best_scores,
        "fold_deltas": deltas,
        "trials": trials,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Candidate passes the predeclared four-fold robust materiality gate."
                if accepted
                else "Candidate does not pass the predeclared four-fold robust materiality gate."
            ),
        },
    }
    (output / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "trials"},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
