"""Follow-up pruning candidate prioritising stability over maximum compression.

EXP_012 showed, using only the 2022/2023 selection folds, that the 85% feature
retention candidate was the only tested candidate with a clear PR-AUC gain in
both selection years.  This follow-up freezes that rule and evaluates it once on
the 2024/2025 confirmation folds.  The report-only 2026H1 holdout is not loaded.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from experiment_feature_pruning import (
    COMPONENTS,
    CONFIRMATION_FOLDS,
    MAX_CONFIRMATION_BRIER_INCREASE,
    ensemble_metrics,
    fit_components,
    merge_components,
    select_feature_sets,
)

from lct26_access.features import augment_site_model_frame
from lct26_access.models import LGB_BASE_PARAMS, LGB_WEEKLY_TUNED_PARAMS

RETENTION_FRACTION = 0.85
MIN_FEATURE_REDUCTION = 0.10


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--baseline-oof", type=Path, required=True)
    parser.add_argument("--selection-report", type=Path, required=True)
    parser.add_argument("--selection-importance", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    selection_report = json.loads(args.selection_report.read_text(encoding="utf-8"))
    selection_trial = next(
        trial
        for trial in selection_report["selection_trials"]
        if np.isclose(trial["retention_fraction"], RETENTION_FRACTION)
    )
    selection_deltas = selection_trial["selection_pr_auc_deltas"]
    if not all(float(delta) > 0.0 for delta in selection_deltas.values()):
        raise ValueError("Conservative candidate must improve both selection folds")

    requested = {
        component: list(metadata["variants"][component]["features"]) for component in COMPONENTS
    }
    weights = {
        component: float(metadata["ensemble_weights"][component]) for component in COMPONENTS
    }
    importance_frame = pd.read_csv(args.selection_importance)
    importances = {component: {"2022": {}, "2023": {}} for component in COMPONENTS}
    for row in importance_frame.itertuples(index=False):
        importances[row.component]["2022"][row.feature] = float(row.normalised_gain_2022)
        importances[row.component]["2023"][row.feature] = float(row.normalised_gain_2023)
    selected_features = select_feature_sets(
        requested,
        importances,
        RETENTION_FRACTION,
    )

    frames = {
        "lgb_base": augment_site_model_frame(args.site_features, weekly=False),
        "lgb_weekly_tuned": augment_site_model_frame(args.site_features, weekly=True),
        "lgb_context": augment_site_model_frame(
            args.site_features,
            context_path=args.context_features,
            weekly=True,
        ),
    }
    for component, frame in frames.items():
        frame = frame[frame["target"].notna()].copy()
        frame["target_date"] = pd.to_datetime(frame["target_date"])
        frames[component] = frame[frame["target_date"] < pd.Timestamp("2026-01-01")]
    params = {
        "lgb_base": LGB_BASE_PARAMS,
        "lgb_weekly_tuned": LGB_WEEKLY_TUNED_PARAMS,
        "lgb_context": LGB_BASE_PARAMS,
    }
    predictions, fit_reports = fit_components(
        frames,
        selected_features,
        CONFIRMATION_FOLDS,
        params,
    )
    candidate = merge_components(predictions, weights)
    candidate_metrics = ensemble_metrics(candidate, "candidate_probability")
    baseline = pd.read_parquet(args.baseline_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])
    if (baseline["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered pruning experiment")
    baseline_metrics = ensemble_metrics(baseline, "ensemble_probability")
    deltas = {
        fold: {
            metric: candidate_metrics[fold][metric] - baseline_metrics[fold][metric]
            for metric in ("pr_auc", "brier")
        }
        for fold in CONFIRMATION_FOLDS
    }
    original_total = sum(len(values) for values in requested.values())
    selected_total = sum(len(values) for values in selected_features.values())
    reduction = 1.0 - selected_total / original_total
    accepted = (
        reduction >= MIN_FEATURE_REDUCTION
        and all(deltas[fold]["pr_auc"] >= 0.0 for fold in CONFIRMATION_FOLDS)
        and all(
            deltas[fold]["brier"] <= MAX_CONFIRMATION_BRIER_INCREASE for fold in CONFIRMATION_FOLDS
        )
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    candidate.to_parquet(args.output_dir / "conservative_pruning_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_014_conservative_feature_pruning",
        "priority": "P2_follow_up",
        "protocol": {
            "selection_source": "EXP_012 selection-fold results only",
            "selection_folds": ["2022", "2023"],
            "confirmation_folds": list(CONFIRMATION_FOLDS),
            "holdout_2026h1_accessed": False,
            "retention_fraction": RETENTION_FRACTION,
            "acceptance_requires_nonnegative_confirmation_pr_auc_delta": True,
            "maximum_confirmation_brier_increase": MAX_CONFIRMATION_BRIER_INCREASE,
            "minimum_feature_reduction": MIN_FEATURE_REDUCTION,
        },
        "selection_pr_auc_deltas": selection_deltas,
        "original_feature_counts": {
            component: len(requested[component]) for component in COMPONENTS
        },
        "selected_feature_counts": {
            component: len(selected_features[component]) for component in COMPONENTS
        },
        "feature_reference_reduction": reduction,
        "selected_features": selected_features,
        "confirmation_fit": fit_reports,
        "baseline_metrics": {fold: baseline_metrics[fold] for fold in CONFIRMATION_FOLDS},
        "candidate_metrics": candidate_metrics,
        "confirmation_deltas": deltas,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Conservative pruning passes the no-PR-AUC-loss confirmation gate."
                if accepted
                else "Conservative pruning does not pass the no-PR-AUC-loss confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
