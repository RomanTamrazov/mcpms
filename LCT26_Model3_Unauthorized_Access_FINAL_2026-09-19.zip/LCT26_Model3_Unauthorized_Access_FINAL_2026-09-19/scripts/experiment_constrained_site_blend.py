"""P1.4: constrained OOF reweighting of the three active site components.

Weights are selected on the earlier 2022/2023 OOF windows and then checked on
2024/2025.  The all-window optimum is reported only as an oracle/headroom
diagnostic and is ineligible for promotion.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss

COMPONENTS = ("lgb_base", "lgb_weekly_tuned", "lgb_context")
SELECTION_FOLDS = ("2022", "2023")
CONFIRMATION_FOLDS = ("2024", "2025")
MATERIAL_CONFIRMATION_WORST_GAIN = 0.0005
MAX_CONFIRMATION_FOLD_DEGRADATION = 0.00025


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expanded-oof", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def simplex(step_units: int = 40) -> list[np.ndarray]:
    return [
        np.asarray([first, second, step_units - first - second], dtype=float) / step_units
        for first in range(step_units + 1)
        for second in range(step_units - first + 1)
    ]


def fold_metrics(frame: pd.DataFrame, score: np.ndarray) -> dict[str, dict[str, float]]:
    temporary = frame[["target", "fold"]].copy()
    temporary["score"] = score
    return {
        str(fold): {
            "pr_auc": float(average_precision_score(group["target"], group["score"])),
            "brier": float(brier_score_loss(group["target"], group["score"])),
        }
        for fold, group in temporary.groupby("fold", sort=True)
    }


def select_weights(
    frame: pd.DataFrame,
    folds: tuple[str, ...],
) -> tuple[np.ndarray, dict[str, Any]]:
    selected = frame[frame["fold"].isin(folds)]
    fold_arrays = {
        str(fold): (
            group["target"].to_numpy(dtype="int8"),
            group.loc[:, COMPONENTS].to_numpy(dtype=float),
        )
        for fold, group in selected.groupby("fold", sort=True)
    }
    best_key: tuple[float, float, float] | None = None
    best_weights: np.ndarray | None = None
    best_scores: dict[str, float] | None = None
    for weights in simplex():
        scores = {
            fold: float(average_precision_score(target, matrix @ weights))
            for fold, (target, matrix) in fold_arrays.items()
        }
        key = (
            min(scores.values()),
            float(np.mean(list(scores.values()))),
            -float(weights.max()),
        )
        if best_key is None or key > best_key:
            best_key = key
            best_weights = weights
            best_scores = scores
    if best_weights is None or best_scores is None:
        raise RuntimeError("No weight candidate evaluated")
    return best_weights, {
        "folds": list(folds),
        "grid_step": 1 / 40,
        "objective": "maximise minimum fold PR-AUC, then mean, then dispersion",
        "selected_fold_pr_auc": best_scores,
    }


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    frame = pd.read_parquet(args.expanded_oof)
    frame["target_date"] = pd.to_datetime(frame["target_date"])
    if (frame["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen holdout entered OOF blend experiment")
    if set(frame["fold"].unique()) != {*SELECTION_FOLDS, *CONFIRMATION_FOLDS}:
        raise ValueError("Expected exactly 2022-2025 OOF folds")

    current_weights = np.asarray([float(metadata["ensemble_weights"][name]) for name in COMPONENTS])
    matrix = frame.loc[:, COMPONENTS].to_numpy(dtype=float)
    current_score = matrix @ current_weights
    selection_weights, selection_details = select_weights(frame, SELECTION_FOLDS)
    candidate_score = matrix @ selection_weights
    oracle_weights, oracle_details = select_weights(frame, (*SELECTION_FOLDS, *CONFIRMATION_FOLDS))
    oracle_score = matrix @ oracle_weights

    current_metrics = fold_metrics(frame, current_score)
    candidate_metrics = fold_metrics(frame, candidate_score)
    oracle_metrics = fold_metrics(frame, oracle_score)
    confirmation_deltas = {
        fold: {
            metric: candidate_metrics[fold][metric] - current_metrics[fold][metric]
            for metric in ("pr_auc", "brier")
        }
        for fold in CONFIRMATION_FOLDS
    }
    worst_current_confirmation = min(
        CONFIRMATION_FOLDS,
        key=lambda fold: current_metrics[fold]["pr_auc"],
    )
    accepted = (
        confirmation_deltas[worst_current_confirmation]["pr_auc"]
        >= MATERIAL_CONFIRMATION_WORST_GAIN
        and min(confirmation_deltas[fold]["pr_auc"] for fold in CONFIRMATION_FOLDS)
        >= -MAX_CONFIRMATION_FOLD_DEGRADATION
        and all(confirmation_deltas[fold]["brier"] <= 0.0005 for fold in CONFIRMATION_FOLDS)
    )

    output_frame = frame[["site_raw", "target_date", "target", "fold", *COMPONENTS]].copy()
    output_frame["current_probability"] = current_score
    output_frame["candidate_probability"] = candidate_score
    output_frame["ineligible_oracle_probability"] = oracle_score
    args.output_dir.mkdir(parents=True, exist_ok=True)
    output_frame.to_parquet(args.output_dir / "constrained_blend_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_013_constrained_site_blend",
        "priority": "P1.4",
        "protocol": {
            "selection_folds": list(SELECTION_FOLDS),
            "confirmation_folds": list(CONFIRMATION_FOLDS),
            "holdout_2026h1_accessed": False,
            "weights_nonnegative": True,
            "weights_sum_to_one": True,
            "catboost_fixed_weight": 0.0,
            "material_confirmation_worst_gain": MATERIAL_CONFIRMATION_WORST_GAIN,
            "maximum_confirmation_fold_degradation": MAX_CONFIRMATION_FOLD_DEGRADATION,
        },
        "current_weights": dict(zip(COMPONENTS, current_weights.tolist(), strict=True)),
        "candidate_weights_selected_on_2022_2023": dict(
            zip(COMPONENTS, selection_weights.tolist(), strict=True)
        ),
        "selection_details": selection_details,
        "current_metrics": current_metrics,
        "candidate_metrics": candidate_metrics,
        "confirmation_deltas": confirmation_deltas,
        "ineligible_all_window_oracle": {
            "reason_ineligible": "uses confirmation folds for weight selection",
            "weights": dict(zip(COMPONENTS, oracle_weights.tolist(), strict=True)),
            "selection": oracle_details,
            "metrics": oracle_metrics,
        },
        "decision": {
            "accepted": accepted,
            "reason": (
                "Earlier-window weights pass the predeclared confirmation gate."
                if accepted
                else "Earlier-window weights do not pass the predeclared 2024/2025 confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
