"""P1.3: empirical-Bayes shrinkage for conditional zone localisation.

Alpha, prior level, and blend weight are selected only on 2023/2024 expanded
walk-forward predictions.  One frozen candidate is then checked on 2025.  The
report-only 2026H1 holdout is never loaded or scored.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import polars as pl

from lct26_access.metrics import zone_rank_metrics

SELECTION_FOLDS = ("2023", "2024")
CONFIRMATION_FOLD = "2025"
PRIOR_MODES = ("global", "family", "site")
ALPHAS = (7.0, 30.0, 90.0, 365.0)
WEIGHTS = (0.05, 0.10, 0.15, 0.20, 0.25, 0.30)
HIERARCHY_STRENGTH_ROWS = 1_000.0
MIN_CONFIRMATION_MRR_GAIN = 0.001
MAX_CONFIRMATION_HIT_LOSS = 0.001


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--expanded-oof", type=Path, required=True)
    parser.add_argument("--zone-features", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def rank_percentile(frame: pd.DataFrame, score: pd.Series) -> pd.Series:
    temporary = frame[["target_date", "site_raw"]].copy()
    temporary["score"] = score.to_numpy(dtype=float)
    return temporary.groupby(["target_date", "site_raw"])["score"].rank(method="average", pct=True)


def hierarchy_priors(
    history: pd.DataFrame,
) -> tuple[float, dict[str, float], dict[str, float]]:
    global_prior = float(history["target"].mean())
    family = history.groupby("site_family", sort=False)["target"].agg(["sum", "count"])
    family_prior = (family["sum"] + HIERARCHY_STRENGTH_ROWS * global_prior) / (
        family["count"] + HIERARCHY_STRENGTH_ROWS
    )
    site = history.groupby(["site_raw", "site_family"], sort=False)["target"].agg(["sum", "count"])
    site_family_prior = site.index.get_level_values("site_family").map(family_prior)
    site_prior = (
        site["sum"].to_numpy() + HIERARCHY_STRENGTH_ROWS * site_family_prior.to_numpy()
    ) / (site["count"].to_numpy() + HIERARCHY_STRENGTH_ROWS)
    return (
        global_prior,
        family_prior.astype(float).to_dict(),
        dict(
            zip(
                site.index.get_level_values("site_raw"),
                site_prior.astype(float),
                strict=True,
            )
        ),
    )


def add_posterior_ranks(
    frame: pd.DataFrame,
    history: pd.DataFrame,
) -> pd.DataFrame:
    output = frame.copy()
    global_prior, family_priors, site_priors = hierarchy_priors(history)
    prior_values = {
        "global": pd.Series(global_prior, index=output.index, dtype=float),
        "family": output["site_family"].map(family_priors).fillna(global_prior),
        "site": output["site_raw"]
        .map(site_priors)
        .fillna(output["site_family"].map(family_priors).fillna(global_prior)),
    }
    positive_days = output["zone_past_positive_days"].to_numpy(dtype=float)
    history_days = output["zone_history_days"].to_numpy(dtype=float)
    for mode in PRIOR_MODES:
        prior = prior_values[mode].to_numpy(dtype=float)
        for alpha in ALPHAS:
            posterior = (positive_days + alpha * prior) / (history_days + alpha)
            name = f"eb_{mode}_alpha{int(alpha)}_rank"
            output[name] = rank_percentile(
                output,
                pd.Series(posterior, index=output.index),
            ).to_numpy()
    return output


def metric_subset(report: dict[str, Any]) -> dict[str, float]:
    return {
        metric: float(report[metric])
        for metric in (
            "mrr",
            "hit_rate_at_1",
            "hit_rate_at_3",
            "hit_rate_at_5",
            "hit_rate_at_10",
        )
    }


def main() -> None:
    args = parse_args()
    oof = pd.read_parquet(args.expanded_oof)
    oof["target_date"] = pd.to_datetime(oof["target_date"])
    if (oof["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered hierarchy experiment")
    raw = (
        pl.scan_parquet(args.zone_features)
        .select("target_date", "site_raw", "site_family", "target")
        .filter(pl.col("target_date") < pl.date(2026, 1, 1))
        .collect()
        .to_pandas()
    )
    raw["target_date"] = pd.to_datetime(raw["target_date"])
    raw = raw[raw["target"].notna()].copy()

    enriched_parts: list[pd.DataFrame] = []
    baseline_metrics: dict[str, dict[str, float]] = {}
    for fold in (*SELECTION_FOLDS, CONFIRMATION_FOLD):
        fold_frame = oof[oof["fold"] == fold].copy().reset_index(drop=True)
        history = raw[raw["target_date"] < pd.Timestamp(f"{fold}-01-01")]
        enriched = add_posterior_ranks(fold_frame, history)
        enriched_parts.append(enriched)
        baseline_metrics[fold] = metric_subset(zone_rank_metrics(enriched, enriched["blend_rank"]))
    enriched_oof = pd.concat(enriched_parts, ignore_index=True)

    trials: list[dict[str, Any]] = []
    best_key: tuple[float, float, float, float] | None = None
    selected: dict[str, Any] | None = None
    for mode in PRIOR_MODES:
        for alpha in ALPHAS:
            rank_column = f"eb_{mode}_alpha{int(alpha)}_rank"
            for weight in WEIGHTS:
                fold_metrics: dict[str, dict[str, float]] = {}
                for fold in SELECTION_FOLDS:
                    fold_frame = enriched_oof[enriched_oof["fold"] == fold]
                    score = (1.0 - weight) * fold_frame["blend_rank"] + weight * fold_frame[
                        rank_column
                    ]
                    fold_metrics[fold] = metric_subset(zone_rank_metrics(fold_frame, score))
                mrr_deltas = [
                    fold_metrics[fold]["mrr"] - baseline_metrics[fold]["mrr"]
                    for fold in SELECTION_FOLDS
                ]
                hit5_deltas = [
                    fold_metrics[fold]["hit_rate_at_5"] - baseline_metrics[fold]["hit_rate_at_5"]
                    for fold in SELECTION_FOLDS
                ]
                key = (
                    min(mrr_deltas),
                    min(hit5_deltas),
                    float(np.mean(mrr_deltas)),
                    -weight,
                )
                trial = {
                    "prior_mode": mode,
                    "alpha": alpha,
                    "weight": weight,
                    "selection_metrics": fold_metrics,
                    "selection_mrr_deltas": dict(zip(SELECTION_FOLDS, mrr_deltas, strict=True)),
                    "selection_hit5_deltas": dict(zip(SELECTION_FOLDS, hit5_deltas, strict=True)),
                }
                trials.append(trial)
                if best_key is None or key > best_key:
                    best_key = key
                    selected = trial
    if selected is None:
        raise RuntimeError("No hierarchy candidate evaluated")

    confirmation = enriched_oof[enriched_oof["fold"] == CONFIRMATION_FOLD].copy()
    selected_column = f"eb_{selected['prior_mode']}_alpha{int(selected['alpha'])}_rank"
    confirmation["candidate_rank"] = (1.0 - float(selected["weight"])) * confirmation[
        "blend_rank"
    ] + float(selected["weight"]) * confirmation[selected_column]
    confirmation_metrics = metric_subset(
        zone_rank_metrics(confirmation, confirmation["candidate_rank"])
    )
    confirmation_deltas = {
        metric: confirmation_metrics[metric] - baseline_metrics[CONFIRMATION_FOLD][metric]
        for metric in confirmation_metrics
    }
    accepted = (
        confirmation_deltas["mrr"] >= MIN_CONFIRMATION_MRR_GAIN
        and confirmation_deltas["hit_rate_at_1"] >= 0.0
        and confirmation_deltas["hit_rate_at_3"] >= -MAX_CONFIRMATION_HIT_LOSS
        and confirmation_deltas["hit_rate_at_5"] >= -MAX_CONFIRMATION_HIT_LOSS
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    confirmation[
        [
            "target_date",
            "site_raw",
            "zone_key",
            "target",
            "blend_rank",
            selected_column,
            "candidate_rank",
        ]
    ].to_parquet(args.output_dir / "hierarchy_confirmation_oof.parquet", index=False)
    report = {
        "experiment_id": "EXP_017_zone_hierarchical_shrinkage",
        "priority": "P1.3",
        "protocol": {
            "selection_folds": list(SELECTION_FOLDS),
            "confirmation_fold": CONFIRMATION_FOLD,
            "holdout_2026h1_accessed": False,
            "prior_modes": list(PRIOR_MODES),
            "alpha_grid": list(ALPHAS),
            "weight_grid": list(WEIGHTS),
            "hierarchy_strength_rows": HIERARCHY_STRENGTH_ROWS,
            "objective": "maximise worst selection-fold MRR delta, then worst Hit@5 delta",
            "minimum_confirmation_mrr_gain": MIN_CONFIRMATION_MRR_GAIN,
            "maximum_confirmation_hit_loss": MAX_CONFIRMATION_HIT_LOSS,
        },
        "baseline_metrics": baseline_metrics,
        "selected_candidate": selected,
        "confirmation_metrics": confirmation_metrics,
        "confirmation_deltas": confirmation_deltas,
        "trials": trials,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Hierarchical shrinkage passes the predeclared confirmation gate."
                if accepted
                else "Hierarchical shrinkage does not pass the predeclared confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {key: value for key, value in report.items() if key != "trials"},
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
