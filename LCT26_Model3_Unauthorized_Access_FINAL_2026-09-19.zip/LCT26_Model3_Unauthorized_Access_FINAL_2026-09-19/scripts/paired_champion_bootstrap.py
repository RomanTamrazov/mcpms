"""Paired temporal bootstrap for a current and previous Model-3 champion."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    f1_score,
    precision_score,
    recall_score,
)

FOLDS = ("2024", "2025", "2026H1")
METRICS = ("pr_auc", "brier", "f1", "precision", "recall")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--current-oof", type=Path, required=True)
    parser.add_argument("--current-metadata", type=Path, required=True)
    parser.add_argument("--previous-oof", type=Path, required=True)
    parser.add_argument("--previous-metadata", type=Path, required=True)
    parser.add_argument("--draws", type=int, default=2_000)
    parser.add_argument("--block-days", type=int, default=7)
    parser.add_argument("--seed", type=int, default=2603)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    return parser.parse_args()


def _load_threshold(metadata_path: Path, *, current: bool) -> tuple[str, float]:
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    thresholds = metadata["decision_thresholds_from_2024_2025"]
    if current:
        mode = metadata.get("default_threshold_mode", "balanced_f1")
    else:
        # The prior pipeline had one primary development-selected threshold.
        mode = "balanced_f1"
    return mode, float(thresholds[mode])


def _metric_values(
    target: np.ndarray,
    probability: np.ndarray,
    threshold: float,
) -> dict[str, float]:
    predicted = probability >= threshold
    return {
        "pr_auc": float(average_precision_score(target, probability)),
        "brier": float(brier_score_loss(target, probability)),
        "f1": float(f1_score(target, predicted, zero_division=0)),
        "precision": float(precision_score(target, predicted, zero_division=0)),
        "recall": float(recall_score(target, predicted, zero_division=0)),
    }


def _calendar_sample(day_count: int, rng: np.random.Generator) -> np.ndarray:
    return rng.integers(0, day_count, size=day_count)


def _block_sample(
    day_count: int,
    block_days: int,
    rng: np.random.Generator,
) -> np.ndarray:
    samples: list[int] = []
    while len(samples) < day_count:
        start = int(rng.integers(0, day_count))
        samples.extend((start + offset) % day_count for offset in range(block_days))
    return np.asarray(samples[:day_count], dtype=np.int64)


def _resampled_rows(day_rows: list[np.ndarray], sampled_days: np.ndarray) -> np.ndarray:
    return np.concatenate([day_rows[int(index)] for index in sampled_days])


def _summarise(samples: np.ndarray, point_delta: float, *, higher_is_better: bool) -> dict[str, Any]:
    if higher_is_better:
        improvement_probability = float(np.mean(samples > 0))
    else:
        improvement_probability = float(np.mean(samples < 0))
    return {
        "point_delta_current_minus_previous": float(point_delta),
        "mean_delta": float(np.mean(samples)),
        "median_delta": float(np.median(samples)),
        "lower_95": float(np.quantile(samples, 0.025)),
        "upper_95": float(np.quantile(samples, 0.975)),
        "probability_current_better": improvement_probability,
        "ci_excludes_zero": bool(
            np.quantile(samples, 0.025) > 0
            if higher_is_better
            else np.quantile(samples, 0.975) < 0
        ),
    }


def _paired_fold(
    frame: pd.DataFrame,
    current_threshold: float,
    previous_threshold: float,
    *,
    draws: int,
    block_days: int,
    seed: int,
) -> dict[str, Any]:
    frame = frame.sort_values(
        ["target_date", "site_raw"], kind="mergesort"
    ).reset_index(drop=True)
    target = frame["target"].to_numpy(dtype=np.int8)
    current = frame["current_probability"].to_numpy(dtype=float)
    previous = frame["previous_probability"].to_numpy(dtype=float)
    current_point = _metric_values(target, current, current_threshold)
    previous_point = _metric_values(target, previous, previous_threshold)
    dates = pd.Index(frame["target_date"].drop_duplicates().sort_values())
    day_rows = [
        np.flatnonzero(frame["target_date"].to_numpy() == day)
        for day in dates
    ]
    output: dict[str, Any] = {
        "rows": int(frame.shape[0]),
        "days": len(dates),
        "current": current_point,
        "previous": previous_point,
        "bootstrap": {},
    }
    for scheme_index, scheme in enumerate(("calendar_day", "moving_block_7d")):
        rng = np.random.default_rng(seed + scheme_index * 100_003)
        deltas = {metric: np.empty(draws, dtype=float) for metric in METRICS}
        for draw in range(draws):
            sampled_days = (
                _calendar_sample(len(dates), rng)
                if scheme == "calendar_day"
                else _block_sample(len(dates), block_days, rng)
            )
            rows = _resampled_rows(day_rows, sampled_days)
            sample_target = target[rows]
            current_values = _metric_values(
                sample_target, current[rows], current_threshold
            )
            previous_values = _metric_values(
                sample_target, previous[rows], previous_threshold
            )
            for metric in METRICS:
                deltas[metric][draw] = current_values[metric] - previous_values[metric]
        output["bootstrap"][scheme] = {
            metric: _summarise(
                deltas[metric],
                current_point[metric] - previous_point[metric],
                higher_is_better=metric != "brier",
            )
            for metric in METRICS
        }
    return output


def _markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Paired bootstrap: current champion vs previous champion",
        "",
        "Одинаковые site-day строки ресемплируются попарно. Положительная delta ",
        "для PR-AUC/F1/Precision/Recall означает преимущество current; для Brier ",
        "улучшением является отрицательная delta.",
        "",
        "2026H1 приведён только как финальный post-hoc report и не участвует в решении.",
        "",
    ]
    for fold in FOLDS:
        fold_report = report["folds"][fold]
        lines.extend(
            [
                f"## {fold}",
                "",
                "| Bootstrap | Metric | Point delta | 95% CI | P(current better) |",
                "|---|---|---:|---:|---:|",
            ]
        )
        for scheme, values in fold_report["bootstrap"].items():
            for metric in METRICS:
                value = values[metric]
                lines.append(
                    f"| {scheme} | {metric} | "
                    f"{value['point_delta_current_minus_previous']:.8f} | "
                    f"[{value['lower_95']:.8f}, {value['upper_95']:.8f}] | "
                    f"{value['probability_current_better']:.4f} |"
                )
        lines.append("")
    verdict = report["development_verdict"]
    lines.extend(
        [
            "## Development-only verdict",
            "",
            verdict["statement"],
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    current = pd.read_parquet(args.current_oof)[
        ["site_raw", "target_date", "target", "fold", "ensemble_probability"]
    ].rename(columns={"ensemble_probability": "current_probability"})
    previous = pd.read_parquet(args.previous_oof)[
        ["site_raw", "target_date", "target", "fold", "ensemble_probability"]
    ].rename(columns={"ensemble_probability": "previous_probability"})
    key = ["site_raw", "target_date", "target", "fold"]
    paired = current.merge(previous, on=key, how="inner", validate="one_to_one")
    if paired.shape[0] != current.shape[0] or paired.shape[0] != previous.shape[0]:
        raise ValueError("Current and previous OOF rows are not perfectly paired")
    current_mode, current_threshold = _load_threshold(
        args.current_metadata, current=True
    )
    previous_mode, previous_threshold = _load_threshold(
        args.previous_metadata, current=False
    )
    folds = {
        fold: _paired_fold(
            paired[paired["fold"] == fold].copy(),
            current_threshold,
            previous_threshold,
            draws=args.draws,
            block_days=args.block_days,
            seed=args.seed + index * 1_000_003,
        )
        for index, fold in enumerate(FOLDS)
    }
    development_pr = [
        folds[fold]["bootstrap"][scheme]["pr_auc"]
        for fold in ("2024", "2025")
        for scheme in ("calendar_day", "moving_block_7d")
    ]
    proven = all(result["lower_95"] > 0 for result in development_pr)
    statement = (
        "Преимущество current по PR-AUC статистически подтверждено во всех "
        "development folds и обеих схемах bootstrap."
        if proven
        else "Point-estimate улучшение current есть, но его PR-AUC преимущество не "
        "доказано одновременно на обоих development folds и обеих схемах bootstrap."
    )
    report = {
        "protocol": {
            "paired_on": key,
            "draws": args.draws,
            "seed": args.seed,
            "calendar_bootstrap_unit": "calendar day",
            "block_bootstrap": f"circular moving blocks of {args.block_days} days",
            "selection_policy": "development-only; 2026H1 report-only",
            "current_threshold": {
                "mode": current_mode,
                "value": current_threshold,
            },
            "previous_threshold": {
                "mode": previous_mode,
                "value": previous_threshold,
            },
        },
        "folds": folds,
        "development_verdict": {
            "pr_auc_advantage_proven_across_all_checks": proven,
            "statement": statement,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    args.markdown_output.write_text(_markdown(report), encoding="utf-8")
    print(json.dumps(report["development_verdict"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
