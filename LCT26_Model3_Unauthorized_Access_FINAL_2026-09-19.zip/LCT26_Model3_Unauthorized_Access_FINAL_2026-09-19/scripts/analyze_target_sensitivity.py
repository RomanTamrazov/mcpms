"""Development-only sensitivity study for plausible intrusion-proxy targets.

The source archive has no dispatcher-confirmed intrusion outcome.  This study
therefore does not search for a convenient label.  It quantifies how much the
accepted broad physical-alarm proxy changes under narrower, auditable event
definitions and how the frozen champion score ranks those definitions.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

DEVELOPMENT_FOLDS = {"2024", "2025"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--champion-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def shifted_next_day(frame: pd.DataFrame, column: str) -> pd.Series:
    shifted = frame.groupby("site_raw", sort=False)[column].shift(-1)
    next_date = frame.groupby("site_raw", sort=False)["date"].shift(-1)
    consecutive = next_date.eq(frame["target_date"])
    return shifted.where(consecutive)


def safe_score_metrics(target: pd.Series, score: pd.Series) -> dict[str, float | int | None]:
    y = target.astype("int8").to_numpy()
    p = score.to_numpy(dtype=float)
    prevalence = float(y.mean())
    if np.unique(y).size < 2:
        return {
            "rows": int(y.size),
            "positives": int(y.sum()),
            "prevalence": prevalence,
            "pr_auc": None,
            "roc_auc": None,
            "pr_lift_over_prevalence": None,
        }
    pr_auc = float(average_precision_score(y, p))
    return {
        "rows": int(y.size),
        "positives": int(y.sum()),
        "prevalence": prevalence,
        "pr_auc": pr_auc,
        "roc_auc": float(roc_auc_score(y, p)),
        "pr_lift_over_prevalence": float(pr_auc / prevalence) if prevalence else None,
    }


def overlap(primary: pd.Series, alternative: pd.Series) -> dict[str, float | int]:
    first = primary.astype(bool).to_numpy()
    second = alternative.astype(bool).to_numpy()
    intersection = int(np.logical_and(first, second).sum())
    union = int(np.logical_or(first, second).sum())
    return {
        "intersection": intersection,
        "union": union,
        "jaccard": float(intersection / union) if union else 1.0,
        "alternative_recall_of_primary": float(intersection / first.sum()) if first.sum() else 1.0,
        "alternative_precision_vs_primary": (
            float(intersection / second.sum()) if second.sum() else 1.0
        ),
    }


def main() -> None:
    args = parse_args()
    feature_columns = [
        "site_raw",
        "date",
        "target_date",
        "target",
        "intrusion_events",
        "intrusion_zones",
        "motion_intrusion_events",
        "av_contact_intrusion_events",
        "door_intrusion_events",
        "hatch_intrusion_events",
        "glass_intrusion_events",
        "nine_hatch_intrusion_events",
        "intrusion_episode_count",
        "intrusion_multi_event_episodes",
        "intrusion_episode_max_events",
        "intrusion_episode_max_zones",
        "intrusion_motion_contact_episodes",
    ]
    frame = pd.read_parquet(args.site_features, columns=feature_columns)
    frame["date"] = pd.to_datetime(frame["date"])
    frame["target_date"] = pd.to_datetime(frame["target_date"])
    frame = frame.sort_values(["site_raw", "date"]).reset_index(drop=True)

    next_values = {
        column: shifted_next_day(frame, column)
        for column in feature_columns
        if column not in {"site_raw", "date", "target_date", "target"}
    }
    motion = next_values["motion_intrusion_events"].fillna(0)
    contact_columns = [
        "av_contact_intrusion_events",
        "door_intrusion_events",
        "hatch_intrusion_events",
        "glass_intrusion_events",
        "nine_hatch_intrusion_events",
    ]
    contact = sum(next_values[column].fillna(0) for column in contact_columns)
    sensor_presence = pd.concat(
        [(motion > 0).rename("motion")]
        + [(next_values[column].fillna(0) > 0).rename(column) for column in contact_columns],
        axis=1,
    ).sum(axis=1)

    labels = pd.DataFrame(
        {
            "site_raw": frame["site_raw"],
            "target_date": frame["target_date"],
            "primary_any_physical_alarm": frame["target"],
            "motion_only": (motion > 0).astype("int8"),
            "contact_open_only": (contact > 0).astype("int8"),
            "motion_and_contact": ((motion > 0) & (contact > 0)).astype("int8"),
            "event_count_ge_2": (next_values["intrusion_events"].fillna(0) >= 2).astype("int8"),
            "multi_zone": (next_values["intrusion_zones"].fillna(0) >= 2).astype("int8"),
            "multiple_sensor_families": (sensor_presence >= 2).astype("int8"),
            "multi_event_episode": (
                next_values["intrusion_multi_event_episodes"].fillna(0) > 0
            ).astype("int8"),
            "multi_episode_day": (next_values["intrusion_episode_count"].fillna(0) >= 2).astype(
                "int8"
            ),
            "burst_ge_3_events": (
                next_values["intrusion_episode_max_events"].fillna(0) >= 3
            ).astype("int8"),
            "motion_contact_same_episode": (
                next_values["intrusion_motion_contact_episodes"].fillna(0) > 0
            ).astype("int8"),
        }
    )
    labels = labels[labels["primary_any_physical_alarm"].notna()].copy()

    oof = pd.read_parquet(args.champion_oof)
    oof["target_date"] = pd.to_datetime(oof["target_date"])
    oof = oof[oof["fold"].isin(DEVELOPMENT_FOLDS)].copy()
    if (oof["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen holdout entered target sensitivity analysis")
    merged = oof.merge(labels, on=["site_raw", "target_date"], validate="one_to_one")
    if not np.array_equal(
        merged["target"].astype("int8").to_numpy(),
        merged["primary_any_physical_alarm"].astype("int8").to_numpy(),
    ):
        raise AssertionError("Reconstructed primary target differs from champion OOF target")

    target_names = [
        column for column in labels.columns if column not in {"site_raw", "target_date"}
    ]
    target_reports: dict[str, Any] = {}
    primary = merged["primary_any_physical_alarm"].astype("int8")
    for name in target_names:
        per_fold = {
            fold: safe_score_metrics(group[name], group["ensemble_probability"])
            for fold, group in merged.groupby("fold", sort=True)
        }
        target_reports[name] = {
            "pooled": safe_score_metrics(merged[name], merged["ensemble_probability"]),
            "per_fold": per_fold,
            "overlap_with_primary": overlap(primary, merged[name]),
        }

    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    report = {
        "experiment_id": "EXP_009_target_sensitivity",
        "status": "diagnostic",
        "protocol": {
            "folds": sorted(DEVELOPMENT_FOLDS),
            "holdout_2026h1_accessed": False,
            "model_retrained": False,
            "score": "frozen champion OOF ensemble_probability",
            "purpose": (
                "label semantics and ranking sensitivity; not target shopping and not evidence "
                "of confirmed physical intrusion"
            ),
        },
        "definitions": {
            "primary_any_physical_alarm": "alarm=true and value is movement detected or open contact",
            "motion_only": "at least one next-day alarmed movement-detected event",
            "contact_open_only": "at least one next-day alarmed open-contact event",
            "motion_and_contact": "both motion and contact evidence during next day",
            "event_count_ge_2": "at least two next-day proxy events",
            "multi_zone": "at least two next-day positive zones",
            "multiple_sensor_families": "at least two positive sensor families next day",
            "multi_event_episode": "at least one next-day episode containing multiple events",
            "multi_episode_day": "at least two distinct next-day episodes",
            "burst_ge_3_events": "at least one next-day episode with three or more events",
            "motion_contact_same_episode": "motion and contact occur in the same next-day episode",
        },
        "targets": target_reports,
        "interpretation": (
            "Narrow definitions are subsets of the accepted proxy and materially alter prevalence. "
            "Without dispatcher outcomes none can be promoted as 'real intrusion'. The primary "
            "target remains the broad, directly auditable task label."
        ),
    }
    (output / "target_sensitivity_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    lines = [
        "# EXP_009 — target sensitivity (development only)",
        "",
        (
            "The table uses the frozen champion OOF score. No model was selected or retrained, and "
            "2026H1 was not accessed."
        ),
        "",
        "| Target | Prevalence | PR-AUC | PR lift | Jaccard vs primary |",
        "|---|---:|---:|---:|---:|",
    ]
    for name in target_names:
        pooled = target_reports[name]["pooled"]
        comparison = target_reports[name]["overlap_with_primary"]
        lines.append(
            f"| {name} | {pooled['prevalence']:.4f} | {pooled['pr_auc']:.4f} | "
            f"{pooled['pr_lift_over_prevalence']:.2f} | {comparison['jaccard']:.4f} |"
        )
    lines.extend(
        [
            "",
            (
                "These are proxy variants, not verified unauthorized-entry outcomes. The broad "
                "primary label stays canonical until dispatcher-confirmed incident outcomes exist."
            ),
        ]
    )
    (output / "TARGET_SENSITIVITY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
