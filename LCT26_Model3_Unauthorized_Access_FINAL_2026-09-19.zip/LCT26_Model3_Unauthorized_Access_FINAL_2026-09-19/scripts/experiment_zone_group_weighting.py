"""P1.7: equalise site/day influence in the zone classifier loss.

Three sample-weighting schemes are compared on 2023/2024.  The best scheme is
frozen and evaluated once on 2025.  The ranker, feature manifest, tree count,
and blend weights remain frozen.  The report-only 2026H1 holdout is not loaded.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import polars as pl
from lightgbm import LGBMClassifier

from lct26_access.features import augment_zone_model_frame
from lct26_access.metrics import zone_rank_metrics
from lct26_access.models import (
    LGB_ZONE_CLASSIFIER_PARAMS,
    ZONE_CATEGORICAL,
    encode_for_lightgbm,
    fit_category_maps,
)

FOLDS = {
    "2023": (pd.Timestamp("2023-01-01"), pd.Timestamp("2024-01-01")),
    "2024": (pd.Timestamp("2024-01-01"), pd.Timestamp("2025-01-01")),
    "2025": (pd.Timestamp("2025-01-01"), pd.Timestamp("2026-01-01")),
}
SELECTION_FOLDS = ("2023", "2024")
CONFIRMATION_FOLD = "2025"
SCHEMES = ("equal_group", "sqrt_group", "balanced_group")
MIN_CONFIRMATION_MRR_GAIN = 0.001
MAX_CONFIRMATION_HIT_LOSS = 0.001


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zone-features", type=Path, required=True)
    parser.add_argument("--champion-metadata", type=Path, required=True)
    parser.add_argument("--expanded-oof", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def eligible_features(frame: pd.DataFrame, requested: list[str]) -> list[str]:
    return [
        feature
        for feature in requested
        if feature in frame.columns and frame[feature].nunique(dropna=False) > 1
    ]


def sample_weights(frame: pd.DataFrame, scheme: str) -> np.ndarray:
    keys = [frame["target_date"], frame["site_raw"]]
    group_size = frame.groupby(["target_date", "site_raw"], sort=False)["target"].transform("size")
    if scheme == "equal_group":
        weight = 1.0 / group_size
    elif scheme == "sqrt_group":
        weight = 1.0 / np.sqrt(group_size)
    elif scheme == "balanced_group":
        positive_count = frame["target"].groupby(keys, sort=False).transform("sum")
        negative_count = group_size - positive_count
        positive_weight = 0.5 / positive_count.clip(lower=1)
        negative_weight = 0.5 / negative_count.clip(lower=1)
        weight = np.where(frame["target"].to_numpy() == 1, positive_weight, negative_weight)
        all_one_class = (positive_count == 0) | (negative_count == 0)
        weight = np.where(all_one_class, 1.0 / group_size, weight)
    else:
        raise ValueError(f"Unknown sample-weight scheme: {scheme}")
    values = np.asarray(weight, dtype=float)
    return values / values.mean()


def rank_percentile(frame: pd.DataFrame, score: np.ndarray) -> pd.Series:
    temporary = frame[["target_date", "site_raw"]].copy()
    temporary["score"] = score
    return temporary.groupby(["target_date", "site_raw"])["score"].rank(method="average", pct=True)


def metric_subset(report: dict[str, Any]) -> dict[str, float]:
    return {
        metric: float(report[metric])
        for metric in (
            "mrr",
            "hit_rate_at_1",
            "hit_rate_at_3",
            "hit_rate_at_5",
            "hit_rate_at_10",
        )
    }


def fit_scheme(
    frame: pd.DataFrame,
    *,
    fold: str,
    scheme: str,
    requested: list[str],
    iterations: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    start, end = FOLDS[fold]
    train = frame["target_date"] < start
    valid = (frame["target_date"] >= start) & (frame["target_date"] < end)
    features = eligible_features(frame.loc[train], requested)
    categorical = [name for name in ZONE_CATEGORICAL if name in features]
    maps = fit_category_maps(frame.loc[train], categorical)
    train_matrix = encode_for_lightgbm(frame.loc[train], features, maps)
    valid_matrix = encode_for_lightgbm(frame.loc[valid], features, maps)
    train_frame = frame.loc[train]
    valid_frame = frame.loc[valid]
    weights = sample_weights(train_frame, scheme)
    model = LGBMClassifier(
        **LGB_ZONE_CLASSIFIER_PARAMS,
        n_estimators=iterations,
    )
    started = time.monotonic()
    model.fit(
        train_matrix,
        train_frame["target"].astype("int8"),
        sample_weight=weights,
        categorical_feature=categorical,
    )
    probability = model.predict_proba(valid_matrix)[:, 1]
    output = valid_frame[["target_date", "site_raw", "zone_key", "target"]].copy()
    output["candidate_classifier_score"] = probability
    output["candidate_classifier_rank"] = rank_percentile(valid_frame, probability).to_numpy()
    return output, {
        "fold": fold,
        "scheme": scheme,
        "train_rows": int(train.sum()),
        "validation_rows": int(valid.sum()),
        "feature_count": len(features),
        "iterations": iterations,
        "sample_weight_min": float(weights.min()),
        "sample_weight_max": float(weights.max()),
        "sample_weight_mean": float(weights.mean()),
        "fit_seconds": round(time.monotonic() - started, 3),
    }


def evaluate_candidate(
    candidate: pd.DataFrame,
    baseline: pd.DataFrame,
    *,
    classifier_weight: float,
    ranker_weight: float,
) -> tuple[pd.DataFrame, dict[str, float]]:
    key = ["target_date", "site_raw", "zone_key", "target"]
    comparison = candidate.merge(
        baseline[key + ["ranker_rank", "blend_rank"]],
        on=key,
        validate="one_to_one",
    )
    comparison["candidate_blend_rank"] = (
        classifier_weight * comparison["candidate_classifier_rank"]
        + ranker_weight * comparison["ranker_rank"]
    )
    return comparison, metric_subset(
        zone_rank_metrics(comparison, comparison["candidate_blend_rank"])
    )


def main() -> None:
    args = parse_args()
    metadata = json.loads(args.champion_metadata.read_text(encoding="utf-8"))
    requested = list(metadata["features"])
    iterations = int(metadata["final_model_iterations"]["classifier"])
    classifier_weight = float(metadata["blend_weights"]["classifier_rank"])
    ranker_weight = float(metadata["blend_weights"]["ranker_rank"])
    frame = (
        pl.scan_parquet(args.zone_features)
        .with_columns(pl.col("target").max().over(["site_raw", "target_date"]).alias("site_target"))
        .filter((pl.col("site_target") == 1) & (pl.col("target_date") < pl.date(2026, 1, 1)))
        .collect()
        .to_pandas()
    )
    frame = (
        augment_zone_model_frame(frame)
        .sort_values(["target_date", "site_raw", "zone_key"])
        .reset_index(drop=True)
    )
    frame["target_date"] = pd.to_datetime(frame["target_date"])
    baseline = pd.read_parquet(args.expanded_oof)
    baseline["target_date"] = pd.to_datetime(baseline["target_date"])
    if (baseline["target_date"] >= pd.Timestamp("2026-01-01")).any():
        raise AssertionError("Frozen 2026H1 holdout entered group-weighting experiment")
    baseline_metrics = {
        fold: metric_subset(
            zone_rank_metrics(
                baseline[baseline["fold"] == fold],
                baseline.loc[baseline["fold"] == fold, "blend_rank"],
            )
        )
        for fold in (*SELECTION_FOLDS, CONFIRMATION_FOLD)
    }

    trials: list[dict[str, Any]] = []
    best_key: tuple[float, float, float] | None = None
    selected_scheme: str | None = None
    for scheme in SCHEMES:
        fold_metrics: dict[str, dict[str, float]] = {}
        fit_reports: list[dict[str, Any]] = []
        for fold in SELECTION_FOLDS:
            print(f"fit scheme={scheme} fold={fold}", flush=True)
            candidate, fit_report = fit_scheme(
                frame,
                fold=fold,
                scheme=scheme,
                requested=requested,
                iterations=iterations,
            )
            fold_baseline = baseline[baseline["fold"] == fold]
            _, metrics = evaluate_candidate(
                candidate,
                fold_baseline,
                classifier_weight=classifier_weight,
                ranker_weight=ranker_weight,
            )
            fold_metrics[fold] = metrics
            fit_reports.append(fit_report)
        mrr_deltas = {
            fold: fold_metrics[fold]["mrr"] - baseline_metrics[fold]["mrr"]
            for fold in SELECTION_FOLDS
        }
        hit3_deltas = {
            fold: fold_metrics[fold]["hit_rate_at_3"] - baseline_metrics[fold]["hit_rate_at_3"]
            for fold in SELECTION_FOLDS
        }
        key = (
            min(mrr_deltas.values()),
            min(hit3_deltas.values()),
            float(np.mean(list(mrr_deltas.values()))),
        )
        trials.append(
            {
                "scheme": scheme,
                "selection_metrics": fold_metrics,
                "selection_mrr_deltas": mrr_deltas,
                "selection_hit3_deltas": hit3_deltas,
                "fit_reports": fit_reports,
            }
        )
        if best_key is None or key > best_key:
            best_key = key
            selected_scheme = scheme
    if selected_scheme is None:
        raise RuntimeError("No group-weighting candidate evaluated")

    print(f"confirmation scheme={selected_scheme} fold={CONFIRMATION_FOLD}", flush=True)
    confirmation_candidate, confirmation_fit = fit_scheme(
        frame,
        fold=CONFIRMATION_FOLD,
        scheme=selected_scheme,
        requested=requested,
        iterations=iterations,
    )
    confirmation, confirmation_metrics = evaluate_candidate(
        confirmation_candidate,
        baseline[baseline["fold"] == CONFIRMATION_FOLD],
        classifier_weight=classifier_weight,
        ranker_weight=ranker_weight,
    )
    confirmation_deltas = {
        metric: confirmation_metrics[metric] - baseline_metrics[CONFIRMATION_FOLD][metric]
        for metric in confirmation_metrics
    }
    selected_trial = next(trial for trial in trials if trial["scheme"] == selected_scheme)
    selection_eligible = (
        min(selected_trial["selection_mrr_deltas"].values()) > 0.0
        and min(selected_trial["selection_hit3_deltas"].values()) >= -MAX_CONFIRMATION_HIT_LOSS
    )
    accepted = (
        selection_eligible
        and confirmation_deltas["mrr"] >= MIN_CONFIRMATION_MRR_GAIN
        and confirmation_deltas["hit_rate_at_1"] >= 0.0
        and confirmation_deltas["hit_rate_at_3"] >= -MAX_CONFIRMATION_HIT_LOSS
        and confirmation_deltas["hit_rate_at_5"] >= -MAX_CONFIRMATION_HIT_LOSS
    )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    confirmation.to_parquet(
        args.output_dir / "group_weighting_confirmation_oof.parquet", index=False
    )
    report = {
        "experiment_id": "EXP_018_zone_group_weighting",
        "priority": "P1.7",
        "protocol": {
            "selection_folds": list(SELECTION_FOLDS),
            "confirmation_fold": CONFIRMATION_FOLD,
            "holdout_2026h1_accessed": False,
            "schemes": list(SCHEMES),
            "features_hyperparameters_tree_count_ranker_and_blend": "frozen",
            "objective": "maximise worst selection-fold MRR delta, then worst Hit@3 delta",
            "minimum_confirmation_mrr_gain": MIN_CONFIRMATION_MRR_GAIN,
            "maximum_confirmation_hit_loss": MAX_CONFIRMATION_HIT_LOSS,
        },
        "baseline_metrics": baseline_metrics,
        "selection_trials": trials,
        "selected_scheme": selected_scheme,
        "selection_eligible": selection_eligible,
        "confirmation_fit": confirmation_fit,
        "confirmation_metrics": confirmation_metrics,
        "confirmation_deltas": confirmation_deltas,
        "decision": {
            "accepted": accepted,
            "reason": (
                "Group-weighted classifier passes the predeclared confirmation gate."
                if accepted
                else "Group-weighted classifier does not pass the predeclared confirmation gate."
            ),
        },
    }
    (args.output_dir / "experiment_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
