"""Create next-day site-risk and top-zone prediction files."""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import pandas as pd

from lct26_access.inference import predict_sites, predict_zones


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--site-features", type=Path, required=True)
    parser.add_argument("--context-features", type=Path, required=True)
    parser.add_argument("--zone-features", type=Path, required=True)
    parser.add_argument("--site-model-dir", type=Path, required=True)
    parser.add_argument("--zone-model-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--as-of", type=pd.Timestamp)
    parser.add_argument(
        "--threshold-mode",
        choices=(
            "operational_recall_80",
            "balanced_f1",
            "high_precision_75",
            "high_recall_90",
        ),
        default="operational_recall_80",
    )
    parser.add_argument("--top-zones", type=int, default=5)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.top_zones < 1:
        raise ValueError("--top-zones must be positive")
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    site_forecast, site_run = predict_sites(
        args.site_features,
        args.context_features,
        args.site_model_dir,
        as_of=args.as_of,
        threshold_mode=args.threshold_mode,
    )
    as_of = pd.Timestamp(site_run["as_of_date"])
    zone_forecast, zone_run = predict_zones(
        args.zone_features,
        args.zone_model_dir,
        site_forecast,
        as_of=as_of,
        top_zones=args.top_zones,
    )
    site_path = output / "site_risk_forecast.csv"
    zone_path = output / "zone_ranking_forecast.csv"
    site_forecast.to_csv(site_path, index=False)
    zone_forecast.to_csv(zone_path, index=False)
    run = {
        **site_run,
        **zone_run,
        "total_prediction_seconds": round(time.monotonic() - started, 4),
        "site_output": str(site_path),
        "zone_output": str(zone_path),
    }
    (output / "prediction_run.json").write_text(
        json.dumps(run, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(run, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
