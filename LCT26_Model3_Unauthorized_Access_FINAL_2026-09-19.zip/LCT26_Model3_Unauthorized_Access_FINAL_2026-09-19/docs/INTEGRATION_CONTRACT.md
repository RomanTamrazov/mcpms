# Контракт интеграции модели 3

## 1. Входной журнал событий

Кодировка UTF-8, CSV, одна строка на событие.

| Поле | Тип | Обязательное | Пример |
|---|---|---:|---|
| `ид_события` | integer-like | да | `4524243389` |
| `ид_канала_данных` | integer-like | да | `120473` |
| `дата` | `YYYY-MM-DD` | да | `2026-08-01` |
| `время` | `HH:MM:SS` | да | `03:09:27` |
| `тревожное` | bool-like | да | `t`, `f`, `true`, `false`, `1`, `0` |
| `значение_датчика` | string | да | `Не замкнут` |

True-токены нормализуются без учёта регистра: `t`, `true`, `1`. Остальные
значения, включая null, считаются false только на уровне parser-а; неизвестные
форматы желательно отклонять в upstream schema validation.

Для обогащения обязателен справочник каналов с полями:

- `ид_канала_данных`;
- `тип_инж_системы`;
- `тип_датчика`;
- `тег_инженерной_системы`;
- `название_датчика`;
- `ид_объект` — внешний ключ обновлённого датасета.

`ид_канала_данных` в справочнике должен быть уникальным.
`ид_объект` должен находиться в `справочник_объектов_диспетчер.csv`, где
используются поля `иерархия_уровень`, `родитель`, `вид_объекта` и
`диспетчерское_название_объекта`.

## 2. Временная семантика

- `as_of_date = D`: использованы события не позже конца D;
- `forecast_date = D + 1 календарный день`;
- горизонт: 24 часа;
- часовой пояс эксплуатационного API должен быть явно зафиксирован backend-ом;
  исходный архив timezone не содержит.

Если между последним сохранённым днём истории и D есть пропуски, backend не
должен молча интерпретировать их как нормальные нулевые дни. Нужно передать
coverage-warning или отказаться от SLA до восстановления данных.

## 3. Выход `site_risk_forecast.csv`

Одна строка на `site_raw`.

| Поле | Значение |
|---|---|
| `as_of_date` | дата среза данных |
| `forecast_date` | дата прогноза |
| `site_raw` | префикс тега объекта |
| `site_family` | более общий префикс тега для контекстного join |
| `site_object_ids` | ID связанных объектов диспетчеризации, разделённые `|` |
| `site_dispatcher_objects` | названия связанных объектов диспетчеризации |
| `model_version` | версия site-модели и feature contract |
| `risk_probability` | ensemble-score в диапазоне `[0, 1]` |
| `risk_band` | `low`, `elevated`, `high`, `very_high` |
| `model_disagreement` | взвешенное расхождение активных моделей; не вероятность ошибки |
| `uncertainty_band` | `low`, `medium`, `high`, `extreme` по порогам development |
| `threshold_mode` | выбранный диспетчерский режим |
| `decision_threshold` | порог режима |
| `alert` | итоговое бинарное решение |
| `workflow_state` | для model forecast всегда `FORECAST_RISK` |
| `response_priority` | `P4` для alert, иначе `NONE` |
| `requires_independent_verification` | необходимость независимого текущего сигнала |
| `auto_incident_confirmation` | всегда `false` для model forecast |
| `data_quality` | статус наличия security-event сигнала |
| `explanation_json` | направленные локальные вклады признаков |
| `component_*` | диагностические score отдельных моделей |

Допустимые режимы:

- `operational_recall_80` — рекомендуемый режим: на каждом development-окне
  recall не ниже 0.80, а затем максимизируется худшая precision;
- `balanced_f1` — maximin-F1 между development-окнами;
- `high_precision_75` — порог выбран под 75% precision на development, без
  гарантии сохранения ровно 75% после drift;
- `high_recall_90` — режим для пропуска минимального числа тревог.

## 4. Выход `zone_ranking_forecast.csv`

До K строк на объект, где K задаётся `--top-zones`.
Если у объекта в справочнике меньше K охранных зон, возвращаются все доступные;
поэтому общее число строк может быть меньше `число объектов × K`. Метаданные
запуска содержат число таких объектов.

| Поле | Значение |
|---|---|
| `date` | D |
| `target_date` | D+1 |
| `site_raw`, `site_family` | идентификаторы объекта |
| `zone_key` | тег зоны; текущая безопасная локация |
| `zone_object_ids` | ID объектов диспетчеризации, связанных с каналами зоны |
| `zone_dispatcher_objects` | названия связанных объектов диспетчеризации |
| `zone_rank` | место внутри объекта, начиная с 1 |
| `zone_classifier_probability` | условный classifier-score зоны |
| `zone_rank_score` | смешанный percentile-rank для сортировки |
| `priority_score` | произведение site-risk и zone classifier score; не калиброванная вероятность |
| `risk_probability`, `risk_band`, `model_disagreement`, `uncertainty_band`, `alert` | результат site-уровня |
| `workflow_state`, `response_priority` | безопасная семантика forecast/P4 |
| `data_quality` | статус event-сигнала объекта |
| `recommendation` | безопасная текстовая подсказка диспетчеру |

Несколько зон могут быть истинными одновременно. Поэтому
`zone_classifier_probability` не нормируется до суммы 1, а `zone_rank_score`
вообще не интерпретируется как вероятность.

## 5. Python-контракт

Backend может импортировать:

```python
from lct26_access.inference import predict_sites, predict_zones
```

Обе функции read-only относительно источника и возвращают `pandas.DataFrame`
плюс словарь метаданных запуска. Сохранение CSV выполняет
`scripts/predict_model3.py`.

## 6. Рекомендуемый HTTP-ответ

Это предложение для команды API, а не уже реализованный endpoint:

```json
{
  "model": "model3-site-v2.1-updated-catalog",
  "threshold_mode": "operational_recall_80",
  "as_of_date": "2026-06-30",
  "forecast_date": "2026-07-01",
  "target": "security_alarm_proxy",
  "sites": [
    {
      "site_raw": "217-1",
      "risk_probability": 0.96934,
      "risk_band": "very_high",
      "model_disagreement": 0.00603,
      "uncertainty_band": "low",
      "alert": true,
      "workflow_state": "FORECAST_RISK",
      "response_priority": "P4",
      "requires_independent_verification": true,
      "auto_incident_confirmation": false,
      "top_zones": [
        {
          "zone_key": "217-1.1.142",
          "rank": 1,
          "conditional_score": 0.93019
        }
      ]
    }
  ]
}
```

В каждый ответ также рекомендуется добавлять `feature_as_of_ts`,
`input_coverage`, `latency_ms` и warning о proxy-цели. Полная карточка инцидента
валидируется схемой `schemas/incident_card.schema.json`, а правила повышения
приоритета описаны в `docs/RESPONSE_PLAYBOOK.md`.

## 7. Граница объектного сопоставления

Обновлённый датасет содержит доказуемый join
`ид_канала_данных → ид_объект → диспетчерское_название_объекта`; покрытие каналов
полное. Поэтому ID и названия объектов можно безопасно показывать в demo и
передавать backend-команде.

Справочник не содержит почтового адреса, проверенной физической критичности
каждой зоны, маршрута реагирования или человеко-подтверждённого результата
осмотра. Эти поля нельзя угадывать по строкам или числовым префиксам; для них
нужен отдельный эксплуатационный справочник владельца системы.
