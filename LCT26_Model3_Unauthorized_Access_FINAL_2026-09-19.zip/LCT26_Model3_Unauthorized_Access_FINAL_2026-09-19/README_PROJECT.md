# ЛЦТ 2026 — модель 3 «Несанкционированный доступ»

Репозиторий содержит воспроизводимый ML-контур для прогноза охранных событий на
следующие календарные 24 часа и ранжирования вероятных зон внутри объекта.

Текущий статус: обновление датасета от организаторов проверено, витрины и модели
переобучены, временная валидация и независимый пересчёт метрик выполнены.
Приняты версии `model3-site-v2.1-updated-catalog` и
`model3-zone-v1.1-updated-catalog`. Финальный переносимый пакет использует
принятый минимальный runtime без CatBoost с нулевым весом; правила его сборки
зафиксированы в `scripts/build_final_package.py`.

## Самое важное о цели

В переданных данных нет подтверждённой диспетчером метки «реальное
несанкционированное проникновение». Поэтому используется узкая проверяемая
proxy-цель:

> На следующем календарном дне есть тревожное событие охранной подсистемы со
> значением `Обнаружено движение` или `Не замкнут`.

`Неисправен` и `Отключено устройство` не превращаются в проникновения: они
остаются техническими признаками. В интерфейсе результат должен называться
«риск физической охранной тревоги», пока не появятся подтверждённые инциденты.

Единица прогноза первого уровня — `site_raw`, то есть префикс тега инженерной
системы. Второй уровень возвращает `zone_key`. В обновлённом справочнике каналов
появился внешний ключ `ид_объект`, поэтому оба уровня теперь дополнительно
возвращают ID и человекочитаемые названия связанных объектов диспетчеризации.
Это надёжный join из данных организаторов, но не адрес и не подтверждённая
физическая критичность помещения.

## Что изменили организаторы

Сравнение `/Users/dinvinch/Downloads/dataset.zip` и
`/Users/dinvinch/Downloads/dataset (1).zip` показало:

- все восемь архивов журналов 2019–2026 имеют одинаковый SHA-256;
- пример журнала и справочник объектов не изменились;
- изменён только `справочник_каналов_датчиков.csv`: добавлен `ид_объект`, а у
  364 каналов уточнено название датчика;
- все 11 485 каналов сопоставлены объектам; для охранной подсистемы покрыты все
  2 211 каналов и 56 объектов;
- новых наблюдений, дат или целевых меток нет.

Новые признаки иерархии были проверены только на development-окнах. Они не дали
устойчивого прироста ни site-модели, ни zone-ranking, поэтому в ML-признаки не
приняты. Сопоставление используется в выходном контракте и интерфейсе — там оно
реально улучшает решение, не создавая вымышленный рост метрик.

## Что построено

1. Защитное чтение журналов 2019–2026, включая повтор заголовка внутри файла
   2025 года и два формата булевой тревоги (`t/f` и `true/false`).
2. Удаление только полных логических дублей. Одинаковый `ид_события` сам по себе
   не считается дублем, потому что в 2021–2022 один ID встречается у разных
   событий.
3. Causal-признаки объекта: лаги, окна 3–365 дней, недельная сезонность,
   рабочие/праздничные дни РФ, состояния охраны, технические сигналы, контекст
   остальных инженерных подсистем и признаки 30-минутных alarm-эпизодов.
4. Ансамбль риска объекта из LightGBM-вариантов. CatBoost был честно проверен,
   но получил нулевой вес при подборе и не нужен в минимальном runtime.
5. Условная локализация зоны: LightGBM classifier + LambdaRank, ранги смешиваются
   весами, выбранными только на 2025 году.
6. Четыре режима решения: рекомендуемый `operational_recall_80`, диагностический
   `balanced_f1`, а также `high_precision_75` и `high_recall_90`.
7. Batch-инференс с вероятностью объекта, top-зонами, направленными локальными
   объяснениями, `model_disagreement`, уровнем неопределённости и предупреждением
   о доступности event-сигнала.
8. Безопасный контур реагирования: forecast создаёт только превентивную задачу
   `FORECAST_RISK / P4`; эскалация требует независимых фактических сигналов.

## Честная валидация

Используются только временные разбиения:

- обучение до 2024 → валидация на 2024;
- обучение до 2025 → валидация на 2025;
- обучение до 2026 → финальный holdout 2026H1.

На 2026H1 не подбирались веса, пороги или количество итераций. Для финального
holdout число деревьев фиксировалось по development-фолдам, без early stopping
на тесте.

Основные результаты 2026H1:

| Компонент | Метрика | Результат |
|---|---:|---:|
| Site-risk | ROC-AUC | 0.8461 |
| Site-risk | PR-AUC | 0.7490 |
| Site-risk, operational | F1 | 0.6952 |
| Site-risk, operational | Precision / Recall | 0.6092 / 0.8096 |
| Site-risk | Precision@5 объектов в день | 0.7017 |
| 28-day baseline | PR-AUC | 0.6104 |
| Zone localisation | MRR | 0.6749 |
| Zone localisation | Hit-rate@1 | 0.5453 |
| Zone localisation | Hit-rate@3 | 0.7546 |
| Zone localisation | Hit-rate@5 | 0.8366 |
| Zone localisation | Hit-rate@10 | 0.9337 |
| Zone 90-day baseline | Hit-rate@5 | 0.7853 |
| Site + zone, operational + top-5 | End-to-end hit | 0.6963 |

Порог `0.35188` режима `operational_recall_80` выбран только на 2024–2025:
максимизируется худшая precision при recall не ниже 0.80 в каждом из двух окон.
На 2026H1 он применяется без изменения.

В исходном ТЗ нет числового минимума Precision/Recall: он должен определяться на
этапе проектирования по качеству данных. Проверяемые требования model-layer —
горизонт не менее 24 часов и inference до 300 секунд — выполнены. Внутренний
shadow-mode gate по proxy-цели также пройден полностью; gate качества именно по
подтверждённым вторжениям пока не вычислим без outcome-разметки. Подробности:
[ACCEPTANCE_REPORT.md](reports/updated_dataset/ACCEPTANCE_REPORT.md).

Нюанс: point-estimate gate пройден, но 95%-интервал calendar-day bootstrap для
recall равен 0.7756–0.8386. Поэтому recall 0.8096 — честная оценка holdout, но не
гарантированный production SLA ≥ 0.80.

Полный отчёт по обновлению:
[UPDATED_DATASET_REPORT.md](reports/UPDATED_DATASET_REPORT.md). Машинные метрики:
[validation_metrics.json](reports/updated_dataset/validation_metrics.json).
Аудит источника: [data_audit.json](reports/data_audit.json). Объяснение модели и
ограничений: [MODEL_CARD.md](reports/MODEL_CARD.md). Отдельно доступны
[отчёт об улучшениях](reports/IMPROVEMENT_REPORT.md) и
[машинный robustness-аудит](reports/updated_dataset/robustness_audit.json). Побайтовая
воспроизводимость зафиксирована в
[reproducibility_check.json](reports/reproducibility_check.json).
Bootstrap-интервалы метрик находятся в
[metric_uncertainty.json](reports/updated_dataset/metric_uncertainty.json).
Проверка файла-примера организаторов сохранена в
[input_example_validation.json](reports/input_example_validation.json).

## Структура проекта

```text
configs/model3_updated.yaml        конфигурация обновлённого датасета и моделей
src/lct26_access/data.py           чтение, нормализация и аудит источника
src/lct26_access/features.py       causal-витрины объекта, контекста и зоны
src/lct26_access/models.py         параметры моделей и кодирование категорий
src/lct26_access/metrics.py        site- и ranking-метрики, выбор порогов
src/lct26_access/episodes.py       объединение тревог в эпизоды
src/lct26_access/inference.py      повторно используемый inference-layer
src/lct26_access/response.py       состояния P4→P1 и словарь feedback
scripts/prepare_model3.py          извлечение архива и построение витрин
scripts/train_site_models.py       temporal validation и обучение site-моделей
scripts/train_zone_models.py       обучение zone classifier + LambdaRank
scripts/predict_model3.py          прогноз объекта и top-зон в CSV
scripts/audit_model3_robustness.py leakage/cold-start/drift/workload-аудит
scripts/bootstrap_metric_uncertainty.py block-bootstrap интервалов holdout
scripts/check_model3_acceptance.py официальный и внутренний acceptance-check
scripts/build_validation_summary.py единая машинная сводка метрик
scripts/experiment_site_variants.py проверенные model ablations
scripts/audit_dataset_update.py    точное сравнение архивов организаторов
scripts/paired_zone_bootstrap.py   парное сравнение zone-ranking
scripts/benchmark_model3_inference.py повторный latency benchmark
scripts/build_final_package.py     воспроизводимая сборка финального архива
schemas/incident_card.schema.json  машинный контракт карточки инцидента
tests/                             проверки семантики цели и контракта
reports/                            аудит, метрики и model card
```

Большие данные и Parquet-витрины исключены из Git. Проверенные модели нового
набора находятся в `artifacts/candidates/updated_dataset/`; прежний champion
сохранён в `artifacts/dev/models/` для воспроизводимого сравнения.

## Окружение

Требуется Python 3.11+ и примерно 18–20 ГБ свободного места для распакованных
журналов и промежуточных файлов.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Для установки точных версий прямых зависимостей проверенного запуска можно
вместо диапазонов использовать `requirements.lock` (CPython 3.12.14).
Для inference без обучения и без CatBoost с нулевым весом можно использовать
минимальный `requirements-runtime.txt`.

Команды ниже запускаются из корня проекта с `PYTHONPATH=src`.

## Полное воспроизведение

### 1. Извлечь данные и построить признаки

```bash
PYTHONPATH=src python scripts/prepare_model3.py \
  --dataset-zip "/Users/dinvinch/Downloads/dataset (1).zip" \
  --work-dir /private/tmp/lct26_model3_updated
```

Создаются:

- `features/daily_site_features.parquet`;
- `features/daily_family_context.parquet`;
- `features/daily_zone_features.parquet`;
- `cache/data_audit.json`;
- `prepare_summary.json`.

В site- и zone-витринах последний доступный день сохраняется с `target = null`.
Это строка для настоящего прогноза D+1; train-скрипты автоматически исключают
её из обучения.

### 2. Обучить риск объекта

```bash
PYTHONPATH=src python scripts/train_site_models.py \
  --site-features /private/tmp/lct26_model3_updated/features/daily_site_features.parquet \
  --context-features /private/tmp/lct26_model3_updated/features/daily_family_context.parquet \
  --feature-manifest artifacts/dev/models/site/site_model_metadata.json \
  --model-version model3-site-v2.1-updated-catalog \
  --output-dir artifacts/candidates/updated_dataset/site
```

### 3. Обучить локализацию зоны

```bash
PYTHONPATH=src python scripts/train_zone_models.py \
  --zone-features /private/tmp/lct26_model3_updated/features/daily_zone_features.parquet \
  --feature-manifest artifacts/dev/models/zone/zone_model_metadata.json \
  --model-version model3-zone-v1.1-updated-catalog \
  --output-dir artifacts/candidates/updated_dataset/zone
```

### 4. Сформировать next-day прогноз

```bash
PYTHONPATH=src python scripts/predict_model3.py \
  --site-features /private/tmp/lct26_model3_updated/features/daily_site_features.parquet \
  --context-features /private/tmp/lct26_model3_updated/features/daily_family_context.parquet \
  --zone-features /private/tmp/lct26_model3_updated/features/daily_zone_features.parquet \
  --site-model-dir artifacts/candidates/updated_dataset/site \
  --zone-model-dir artifacts/candidates/updated_dataset/zone \
  --output-dir artifacts/candidates/updated_dataset/predictions/latest \
  --threshold-mode operational_recall_80 \
  --top-zones 5
```

Выход:

- `site_risk_forecast.csv` — вероятность риска и решение по каждому объекту;
- `zone_ranking_forecast.csv` — top-зоны каждого объекта;
- `prediction_run.json` — дата прогноза, количество строк и latency.

Повторный benchmark: семь измеренных прогонов после warm-up на 30 объектах и
1 031 зоне дали median 2.08 с, p95 2.47 с и max 2.50 с, включая чтение
подготовленных витрин, загрузку моделей и объяснения LightGBM. Выходы всех
прогонов идентичны. Это model-serving latency, а не время полного пересчёта
многолетнего архива.

## Проверки качества кода

```bash
PYTHONPATH=src python -m pytest -q
ruff check src scripts tests
```

На финальном состоянии проходят 26 тестов и все проверки Ruff.

Проверка входного файла и разрыва дат:

```bash
PYTHONPATH=src python scripts/validate_input_journal.py \
  --journal /path/to/incoming.csv \
  --channel-catalog-dir /path/to/catalog_dir \
  --previous-history-max-date 2026-06-30
```

Проверка сформированных прогнозов:

```bash
PYTHONPATH=src python scripts/validate_predictions.py \
  --site artifacts/candidates/updated_dataset/predictions/latest/site_risk_forecast.csv \
  --zone artifacts/candidates/updated_dataset/predictions/latest/zone_ranking_forecast.csv \
  --max-zone-rank 5
```

Пересчёт bootstrap-интервалов и отчёта допуска после нового model-run:

```bash
PYTHONPATH=src python scripts/bootstrap_metric_uncertainty.py \
  --site-oof artifacts/candidates/updated_dataset/site/site_oof_predictions.parquet \
  --site-metadata artifacts/candidates/updated_dataset/site/site_model_metadata.json \
  --zone-oof artifacts/candidates/updated_dataset/zone/zone_oof_predictions.parquet \
  --config configs/model3_updated.yaml \
  --draws 2000 \
  --seed 2603 \
  --output reports/updated_dataset/metric_uncertainty.json

PYTHONPATH=src python scripts/check_model3_acceptance.py \
  --config configs/model3_updated.yaml \
  --site-metadata artifacts/candidates/updated_dataset/site/site_model_metadata.json \
  --zone-metadata artifacts/candidates/updated_dataset/zone/zone_model_metadata.json \
  --robustness-audit reports/updated_dataset/robustness_audit.json \
  --metric-uncertainty reports/updated_dataset/metric_uncertainty.json \
  --prediction-run artifacts/candidates/updated_dataset/predictions/latest/prediction_run.json \
  --output reports/updated_dataset/acceptance_check.json \
  --markdown-output reports/updated_dataset/ACCEPTANCE_REPORT.md
```

## Файл-пример от организаторов

`журнал_событий_пример.csv` содержит только 2026-08-01, тогда как исторический
архив заканчивается 2026-06-30. Между ними отсутствует весь июль. Поэтому пример
используется для проверки схемы и ingestion-контракта, а не как размеченный
test-set. Склеивать его с историей и молча считать июль нулевым нельзя.

Подробный контракт для backend-команды находится в
[INTEGRATION_CONTRACT.md](docs/INTEGRATION_CONTRACT.md), а состояния и безопасная
эскалация описаны в [RESPONSE_PLAYBOOK.md](docs/RESPONSE_PLAYBOOK.md).
